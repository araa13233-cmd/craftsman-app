import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, StyleSheet, ScrollView, Pressable,
  Dimensions, ActivityIndicator, Alert, Linking,
} from 'react-native';
import { useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import * as Location from 'expo-location';
import { Colors, FontSize, FontWeight, Radius, Spacing, Shadow } from '@/constants/theme';
import { serviceCategories, craftsmen } from '@/constants/mockData';
import { ARAB_COUNTRIES } from '@/constants/arabCountries';
import { useApp } from '@/hooks/useApp';
import { getSupabaseClient, useAuth } from '@/template';

const { width } = Dimensions.get('window');

// ─── CLIENT HOME ──────────────────────────────────────────────────────────────
function ClientHome() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { toggleFavorite, isFavorite } = useApp();
  const { user } = useAuth();
  const supabase = getSupabaseClient();

  const [unreadCount, setUnreadCount] = useState(0);
  const topCraftsmen = craftsmen.filter(c => c.available).slice(0, 5);

  const fetchUnreadCount = useCallback(async () => {
    if (!user) { setUnreadCount(0); return; }
    try {
      const { count } = await supabase
        .from('notifications')
        .select('id', { count: 'exact', head: true })
        .eq('user_id', user.id)
        .eq('is_read', false);
      setUnreadCount(count ?? 0);
    } catch { /* silent */ }
  }, [user]);

  useEffect(() => {
    fetchUnreadCount();
    const interval = setInterval(fetchUnreadCount, 15000);
    return () => clearInterval(interval);
  }, [fetchUnreadCount]);

  const displayName = user
    ? (user.username || user.email?.split('@')[0] || 'المستخدم')
    : 'ضيف';

  const avatarUrl = `https://ui-avatars.com/api/?name=${encodeURIComponent(displayName)}&background=D4A017&color=0D1B3E&size=200`;

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <StatusBar style="light" />
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 20 }}>

        {/* Header */}
        <View style={styles.header}>
          <Pressable style={styles.notifBtn} onPress={() => router.push('/(tabs)/chats' as any)}>
            {({ pressed }) => (
              <View style={[styles.notifBtnInner, pressed && { opacity: 0.8 }]}>
                <MaterialIcons name="chat" size={22} color={Colors.text} />
              </View>
            )}
          </Pressable>
          <Pressable style={styles.notifBtn} onPress={() => router.push('/notifications' as any)}>
            {({ pressed }) => (
              <View style={[styles.notifBtnInner, pressed && { opacity: 0.8 }]}>
                <MaterialIcons name="notifications-none" size={24} color={Colors.text} />
                {unreadCount > 0 && (
                  <View style={styles.notifBadge}>
                    <Text style={styles.notifBadgeText}>{unreadCount > 99 ? '99+' : unreadCount}</Text>
                  </View>
                )}
              </View>
            )}
          </Pressable>
          <View style={styles.headerText}>
            <Text style={styles.greeting}>مرحباً 👋</Text>
            <Text style={styles.userName}>{displayName}</Text>
          </View>
          <Pressable onPress={() => router.push('/(tabs)/profile' as any)}>
            <Image source={{ uri: avatarUrl }} style={styles.avatar} contentFit="cover" />
          </Pressable>
        </View>

        {/* Search Bar */}
        <View style={styles.searchContainer}>
          <Pressable style={styles.searchBar} onPress={() => router.push('/craftsmen/index' as any)}>
            <MaterialIcons name="search" size={22} color={Colors.textMuted} />
            <Text style={styles.searchPlaceholder}>ما الخدمة التي تبحث عنها؟</Text>
            <View style={styles.searchFilter}>
              <MaterialIcons name="tune" size={18} color={Colors.gold} />
            </View>
          </Pressable>
        </View>

        {/* Banner */}
        <View style={styles.bannerContainer}>
          <Pressable style={styles.banner} onPress={() => router.push('/craftsman-register' as any)}>
            {({ pressed }) => (
              <>
                <View style={styles.bgCircle1} />
                <View style={styles.bgCircle2} />
                <View style={[styles.bannerContent, pressed && { opacity: 0.92 }]}>
                  <Text style={styles.bannerTag}>للحرفيين</Text>
                  <Text style={styles.bannerTitle}>هل تبحث عن{'\n'}فرص عمل قريبة؟</Text>
                  <View style={styles.bannerBtn}>
                    <MaterialIcons name="arrow-back" size={14} color={Colors.primary} />
                    <Text style={styles.bannerBtnText}>سجّل كحرفي الآن</Text>
                  </View>
                </View>
                <View style={styles.bannerIconArea}>
                  <MaterialIcons name="home-repair-service" size={70} color="rgba(212,160,23,0.3)" />
                </View>
              </>
            )}
          </Pressable>
        </View>

        {/* Service Categories */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Pressable onPress={() => router.push('/craftsmen/index' as any)}>
              <Text style={styles.seeAll}>عرض الكل</Text>
            </Pressable>
            <Text style={styles.sectionTitle}>الخدمات</Text>
          </View>
          <View style={styles.categoriesGrid}>
            {serviceCategories.map(cat => (
              <Pressable key={cat.id} style={styles.categoryCard} onPress={() => router.push('/craftsmen/index' as any)}>
                {({ pressed }) => (
                  <View style={[styles.categoryCardInner, pressed && { opacity: 0.85 }]}>
                    <View style={[styles.catIconBg, { backgroundColor: cat.color + '20' }]}>
                      <MaterialIcons name={cat.icon as any} size={28} color={cat.color} />
                    </View>
                    <Text style={styles.catName}>{cat.name}</Text>
                    <Text style={styles.catCount}>{cat.count} حرفي</Text>
                  </View>
                )}
              </Pressable>
            ))}
          </View>
        </View>

        {/* Top Craftsmen */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Pressable onPress={() => router.push('/craftsmen/index' as any)}>
              <Text style={styles.seeAll}>عرض الكل</Text>
            </Pressable>
            <Text style={styles.sectionTitle}>الحرفيون المميزون</Text>
          </View>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}
            contentContainerStyle={{ paddingHorizontal: Spacing.lg, gap: Spacing.md }}>
            {topCraftsmen.map(craftsman => (
              <Pressable key={craftsman.id} style={styles.craftsmanCard}
                onPress={() => router.push(`/craftsmen/${craftsman.id}` as any)}>
                {({ pressed }) => (
                  <View style={[styles.craftsmanCardInner, pressed && { opacity: 0.9 }]}>
                    <View style={styles.cardImageWrapper}>
                      <Image source={{ uri: craftsman.image }} style={styles.craftsmanImg} contentFit="cover" />
                      <View style={styles.availBadge}>
                        <View style={styles.availDot} />
                        <Text style={styles.availText}>متاح</Text>
                      </View>
                      <Pressable style={styles.favBtn} onPress={() => toggleFavorite(craftsman.id)}>
                        <MaterialIcons
                          name={isFavorite(craftsman.id) ? 'favorite' : 'favorite-border'}
                          size={18}
                          color={isFavorite(craftsman.id) ? '#E74C3C' : Colors.text}
                        />
                      </Pressable>
                    </View>
                    <View style={styles.craftsmanInfo}>
                      <Text style={styles.craftsmanName} numberOfLines={1}>
                        {craftsman.name.split(' ').slice(0, 2).join(' ')}
                      </Text>
                      <Text style={styles.craftsmanSpec}>{craftsman.specialty}</Text>
                      <View style={styles.ratingRow}>
                        <Text style={styles.ratingDist}>{craftsman.distance}</Text>
                        <View style={styles.ratingBadge}>
                          <Text style={styles.ratingNum}>{craftsman.rating}</Text>
                          <MaterialIcons name="star" size={12} color={Colors.gold} />
                        </View>
                      </View>
                    </View>
                  </View>
                )}
              </Pressable>
            ))}
          </ScrollView>
        </View>

        {/* Craftsmen by Country */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Pressable onPress={() => router.push('/craftsmen/index' as any)}>
              <Text style={styles.seeAll}>عرض الكل</Text>
            </Pressable>
            <Text style={styles.sectionTitle}>الحرفيون حسب الدولة</Text>
          </View>
          <View style={styles.countryBarOuter}>
            <ScrollView horizontal showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.countryBarInner}>
              {ARAB_COUNTRIES.map(country => (
                <Pressable key={country.name} style={styles.countryBtn}
                  onPress={() => router.push(`/craftsmen/index?country=${encodeURIComponent(country.name)}` as any)}>
                  {({ pressed }) => (
                    <View style={[styles.countryBtnInner, pressed && { opacity: 0.8, transform: [{ scale: 0.95 }] }]}>
                      <Text style={styles.countryFlag}>{country.flag}</Text>
                      <Text style={styles.countryName} numberOfLines={1}>{country.name}</Text>
                    </View>
                  )}
                </Pressable>
              ))}
            </ScrollView>
          </View>
        </View>

        {/* Quick Stats */}
        <View style={styles.statsRow}>
          {[
            { icon: 'verified', label: 'حرفي موثق', value: '500+', color: Colors.gold },
            { icon: 'thumb-up', label: 'رضا العملاء', value: '98%', color: Colors.success },
            { icon: 'location-on', label: 'مدينة', value: '12+', color: Colors.info },
          ].map((s, i) => (
            <View key={i} style={styles.statCard}>
              <MaterialIcons name={s.icon as any} size={24} color={s.color} />
              <Text style={styles.statValue}>{s.value}</Text>
              <Text style={styles.statLabel}>{s.label}</Text>
            </View>
          ))}
        </View>
      </ScrollView>
    </View>
  );
}

// ─── CRAFTSMAN HOME ───────────────────────────────────────────────────────────
function CraftsmanHome() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const {
    availableJobs, availableJobsLoading, fetchAvailableJobs,
    assignedJobs, fetchAssignedJobs, acceptJob,
    craftsmanProfileId, craftsmanLocation, updateCraftsmanLocation,
  } = useApp();
  const supabase = getSupabaseClient();

  const [accepting, setAccepting] = useState<string | null>(null);
  const [craftsmanName, setCraftsmanName] = useState('');
  const [updatingLoc, setUpdatingLoc] = useState(false);

  const updateMyLocation = useCallback(async () => {
    setUpdatingLoc(true);
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') return;
      const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      await updateCraftsmanLocation(loc.coords.latitude, loc.coords.longitude);
    } catch { /* silent */ }
    finally { setUpdatingLoc(false); }
  }, [updateCraftsmanLocation]);

  useEffect(() => {
    const loadCraftsman = async () => {
      if (!craftsmanProfileId) return;
      const { data } = await supabase.from('craftsmen').select('name').eq('id', craftsmanProfileId).single();
      if (data) setCraftsmanName(data.name);
    };
    loadCraftsman();
    fetchAvailableJobs();
    fetchAssignedJobs();
    updateMyLocation();
    const interval = setInterval(() => {
      fetchAvailableJobs();
      fetchAssignedJobs();
    }, 20000);
    return () => clearInterval(interval);
  }, [craftsmanProfileId, fetchAvailableJobs, fetchAssignedJobs, updateMyLocation]);

  const handleAccept = async (orderId: string) => {
    setAccepting(orderId);
    const success = await acceptJob(orderId);
    setAccepting(null);
    if (!success) Alert.alert('تنبيه', 'تم قبول هذا الطلب من حرفي آخر');
  };

  const callCustomer = (phone: string) => {
    if (!phone) return;
    Linking.openURL(`tel:${phone}`);
  };

  const displayName = craftsmanName || user?.username || user?.email?.split('@')[0] || 'الحرفي';

  const activeJobs = assignedJobs.filter(j => ['accepted','on_the_way','in_progress'].includes(j.status));
  const completedJobs = assignedJobs.filter(j => j.status === 'completed');

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <StatusBar style="light" />
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 30 }}>

        {/* Header */}
        <View style={styles.header}>
          <Pressable style={styles.notifBtn} onPress={() => router.push('/notifications' as any)}>
            {({ pressed }) => (
              <View style={[styles.notifBtnInner, pressed && { opacity: 0.8 }]}>
                <MaterialIcons name="notifications-none" size={24} color={Colors.text} />
              </View>
            )}
          </Pressable>
          {/* Location update button */}
          <Pressable style={styles.notifBtn} onPress={updateMyLocation} disabled={updatingLoc}>
            {({ pressed }) => (
              <View style={[styles.notifBtnInner, pressed && { opacity: 0.8 }]}>
                {updatingLoc
                  ? <ActivityIndicator size="small" color={Colors.gold} />
                  : <MaterialIcons
                      name="my-location"
                      size={22}
                      color={craftsmanLocation ? Colors.success : Colors.textMuted}
                    />
                }
              </View>
            )}
          </Pressable>
          <View style={styles.headerText}>
            <Text style={styles.greeting}>لوحة الحرفي 🔧</Text>
            <Text style={styles.userName}>{displayName}</Text>
          </View>
          <Pressable onPress={() => router.push('/craftsman-profile' as any)}>
            <View style={styles.craftsmanAvatarBg}>
              <MaterialIcons name="engineering" size={26} color={Colors.gold} />
            </View>
          </Pressable>
        </View>

        {/* Location status bar */}
        <View style={[styles.locStatusBar, craftsmanLocation ? styles.locStatusBarActive : styles.locStatusBarInactive]}>
          <MaterialIcons
            name={craftsmanLocation ? 'location-on' : 'location-off'}
            size={14}
            color={craftsmanLocation ? Colors.success : Colors.textMuted}
          />
          <Text style={[styles.locStatusText, craftsmanLocation && { color: Colors.success }]}>
            {craftsmanLocation
              ? `موقعك محدد — الطلبات مرتبة بالأقرب إليك`
              : 'اضغط على أيقونة الموقع لتحديد موقعك وعرض أقرب الطلبات'}
          </Text>
        </View>

        {/* Stats Row */}
        <View style={styles.cStatsRow}>
          {[
            { icon: 'pending-actions', value: availableJobs.length, label: 'متاحة',      color: Colors.gold },
            { icon: 'engineering',     value: activeJobs.length,    label: 'نشطة',       color: Colors.info },
            { icon: 'check-circle',    value: completedJobs.length, label: 'مكتملة',     color: Colors.success },
          ].map((s, i) => (
            <View key={i} style={[styles.cStatCard, { borderColor: s.color + '33' }]}>
              <MaterialIcons name={s.icon as any} size={22} color={s.color} />
              <Text style={[styles.cStatValue, { color: s.color }]}>{s.value}</Text>
              <Text style={styles.cStatLabel}>{s.label}</Text>
            </View>
          ))}
        </View>

        {/* Quick Actions */}
        <View style={styles.quickActionsRow}>
          <Pressable style={styles.quickActionBtn} onPress={() => router.push('/craftsman-profile' as any)}>
            <MaterialIcons name="manage-accounts" size={20} color={Colors.gold} />
            <Text style={styles.quickActionText}>ملفي المهني</Text>
          </Pressable>
          <Pressable style={styles.quickActionBtn} onPress={() => router.push('/(tabs)/chats' as any)}>
            <MaterialIcons name="chat" size={20} color={Colors.gold} />
            <Text style={styles.quickActionText}>المحادثات</Text>
          </Pressable>
          <Pressable style={styles.quickActionBtn} onPress={() => router.push('/(tabs)/profile' as any)}>
            <MaterialIcons name="settings" size={20} color={Colors.gold} />
            <Text style={styles.quickActionText}>الإعدادات</Text>
          </Pressable>
        </View>

        {/* Active Jobs */}
        {activeJobs.length > 0 && (
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <View style={styles.activeDot} />
              <Text style={styles.sectionTitle}>الطلبات النشطة</Text>
            </View>
            {activeJobs.map(job => (
              <JobCard key={job.id} job={job} type="active" router={router} />
            ))}
          </View>
        )}

        {/* Available Jobs */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Pressable onPress={() => { fetchAvailableJobs(); fetchAssignedJobs(); }}>
              <MaterialIcons name="refresh" size={18} color={Colors.gold} />
            </Pressable>
            <Text style={styles.sectionTitle}>
              الطلبات المتاحة ({availableJobs.length})
            </Text>
          </View>

          {availableJobsLoading ? (
            <View style={styles.loadingRow}>
              <ActivityIndicator color={Colors.gold} size="small" />
              <Text style={styles.loadingText}>جاري البحث عن طلبات...</Text>
            </View>
          ) : availableJobs.length === 0 ? (
            <View style={styles.emptyJobs}>
              <MaterialIcons name="inbox" size={44} color={Colors.textMuted} />
              <Text style={styles.emptyJobsTitle}>لا توجد طلبات متاحة الآن</Text>
              <Text style={styles.emptyJobsText}>سيتم إشعارك عند وصول طلبات جديدة</Text>
            </View>
          ) : (
            availableJobs.map(job => (
              <View key={job.id} style={styles.availJobCard}>
                <View style={styles.availJobTop}>
                  <View style={styles.availJobMeta}>
                    <Text style={styles.availJobDate}>{job.date}</Text>
                    {/* Distance badge when location is available */}
                    {job.distanceKm != null && job.distanceKm < 9999 && (
                      <View style={[styles.availJobBadge, styles.distanceBadge]}>
                        <MaterialIcons name="near-me" size={10} color={Colors.success} />
                        <Text style={[styles.availJobBadgeText, { color: Colors.success }]}>
                          {job.distanceKm < 1
                            ? `${Math.round(job.distanceKm * 1000)} م`
                            : `${job.distanceKm.toFixed(1)} كم`}
                        </Text>
                      </View>
                    )}
                    <View style={styles.availJobBadge}>
                      <View style={styles.availJobDot} />
                      <Text style={styles.availJobBadgeText}>جديد</Text>
                    </View>
                  </View>
                  <Text style={styles.availJobService}>{job.service}</Text>
                </View>

                {job.description ? (
                  <Text style={styles.availJobDesc} numberOfLines={2}>{job.description}</Text>
                ) : null}

                <View style={styles.availJobAddress}>
                  <MaterialIcons name="location-on" size={13} color={Colors.textMuted} />
                  <Text style={styles.availJobAddressText} numberOfLines={1}>{job.address || 'العنوان غير محدد'}</Text>
                </View>

                {job.price ? (
                  <View style={styles.availJobPrice}>
                    <MaterialIcons name="payments" size={14} color={Colors.success} />
                    <Text style={styles.availJobPriceText}>{job.price}</Text>
                  </View>
                ) : null}

                <Pressable
                  style={[styles.acceptBtn, accepting === job.id && { opacity: 0.7 }]}
                  onPress={() => handleAccept(job.id)}
                  disabled={accepting === job.id}
                >
                  {accepting === job.id ? (
                    <ActivityIndicator size="small" color={Colors.primary} />
                  ) : (
                    <>
                      <MaterialIcons name="check-circle" size={16} color={Colors.primary} />
                      <Text style={styles.acceptBtnText}>قبول الطلب</Text>
                    </>
                  )}
                </Pressable>
              </View>
            ))
          )}
        </View>
      </ScrollView>
    </View>
  );
}

// ─── Job Card (for active/assigned) ──────────────────────────────────────────
function JobCard({ job, type, router }: { job: any; type: 'active' | 'completed'; router: any }) {
  const statusColor = type === 'active' ? Colors.info : Colors.success;
  const statusLabel = type === 'active' ? 'جاري التنفيذ' : 'مكتمل';

  return (
    <Pressable style={styles.jobCard} onPress={() => router.push(`/orders/${job.id}` as any)}>
      {({ pressed }) => (
        <View style={[styles.jobCardInner, pressed && { opacity: 0.9 }, type === 'active' && styles.jobCardActive]}>
          <View style={styles.jobCardTop}>
            <View style={[styles.jobStatusBadge, { backgroundColor: statusColor + '20' }]}>
              <View style={[styles.jobStatusDot, { backgroundColor: statusColor }]} />
              <Text style={[styles.jobStatusText, { color: statusColor }]}>{statusLabel}</Text>
            </View>
            <Text style={styles.jobService} numberOfLines={1}>{job.service}</Text>
          </View>
          {job.address ? (
            <View style={styles.jobAddress}>
              <MaterialIcons name="location-on" size={12} color={Colors.textMuted} />
              <Text style={styles.jobAddressText} numberOfLines={1}>{job.address}</Text>
            </View>
          ) : null}
          <View style={styles.jobMeta}>
            {job.price ? <Text style={styles.jobPrice}>{job.price}</Text> : null}
            <Text style={styles.jobDate}>{job.date}</Text>
          </View>
          {type === 'active' && (
            <View style={styles.jobTrackHint}>
              <MaterialIcons name="map" size={12} color={Colors.gold} />
              <Text style={styles.jobTrackText}>اضغط لعرض تفاصيل الطلب</Text>
            </View>
          )}
        </View>
      )}
    </Pressable>
  );
}

// ─── Root Screen ──────────────────────────────────────────────────────────────
export default function HomeScreen() {
  const { userRole, roleLoading } = useApp();

  if (roleLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={Colors.gold} />
      </View>
    );
  }

  return userRole === 'craftsman' ? <CraftsmanHome /> : <ClientHome />;
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  loadingContainer: { flex: 1, backgroundColor: Colors.background, alignItems: 'center', justifyContent: 'center' },

  // Shared header
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: Spacing.lg, paddingVertical: Spacing.md,
  },
  notifBtn: {},
  notifBtnInner: {
    width: 44, height: 44, backgroundColor: Colors.surface, borderRadius: Radius.md,
    alignItems: 'center', justifyContent: 'center', position: 'relative',
  },
  notifBadge: {
    position: 'absolute', top: 6, right: 6, minWidth: 18, height: 18, borderRadius: 9,
    backgroundColor: Colors.error, borderWidth: 1.5, borderColor: Colors.background,
    alignItems: 'center', justifyContent: 'center', paddingHorizontal: 3,
  },
  notifBadgeText: { fontSize: 10, fontWeight: FontWeight.bold, color: Colors.text },
  headerText: { flex: 1, alignItems: 'flex-end', paddingHorizontal: Spacing.sm },
  greeting: { fontSize: FontSize.sm, color: Colors.textMuted },
  userName: { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: Colors.text },
  avatar: { width: 48, height: 48, borderRadius: 24, borderWidth: 2, borderColor: Colors.gold },
  craftsmanAvatarBg: {
    width: 48, height: 48, borderRadius: 24, borderWidth: 2, borderColor: Colors.gold,
    backgroundColor: Colors.goldSoft, alignItems: 'center', justifyContent: 'center',
  },

  // Location status bar
  locStatusBar: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    marginHorizontal: Spacing.lg, marginBottom: Spacing.sm,
    paddingVertical: 8, paddingHorizontal: 12,
    borderRadius: Radius.lg, borderWidth: 1,
  },
  locStatusBarActive: { backgroundColor: 'rgba(46,204,113,0.08)', borderColor: 'rgba(46,204,113,0.25)' },
  locStatusBarInactive: { backgroundColor: Colors.surface, borderColor: Colors.border },
  locStatusText: { fontSize: FontSize.xs, color: Colors.textMuted, flex: 1, textAlign: 'right' },

  // Search
  searchContainer: { paddingHorizontal: Spacing.lg, marginBottom: Spacing.lg },
  searchBar: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: Colors.surface, borderRadius: Radius.lg,
    borderWidth: 1, borderColor: Colors.border,
    paddingHorizontal: Spacing.md, paddingVertical: 13, gap: Spacing.sm,
  },
  searchPlaceholder: { flex: 1, color: Colors.textMuted, fontSize: FontSize.base, textAlign: 'right' },
  searchFilter: {
    width: 34, height: 34, borderRadius: Radius.sm,
    backgroundColor: Colors.goldSoft, alignItems: 'center', justifyContent: 'center',
  },

  // Banner
  bannerContainer: { paddingHorizontal: Spacing.lg, marginBottom: Spacing.lg },
  banner: {
    borderRadius: Radius.xl, backgroundColor: Colors.primarySurface,
    borderWidth: 1, borderColor: Colors.glassBorder,
    paddingVertical: Spacing.lg, paddingHorizontal: Spacing.lg,
    flexDirection: 'row', overflow: 'hidden', ...Shadow.md,
  },
  bgCircle1: { position: 'absolute', width: 100, height: 100, borderRadius: 50, backgroundColor: 'rgba(212,160,23,0.08)', top: -20, left: -20 },
  bgCircle2: { position: 'absolute', width: 80, height: 80, borderRadius: 40, backgroundColor: 'rgba(212,160,23,0.05)', bottom: -10, right: 60 },
  bannerContent: { flex: 1 },
  bannerTag: {
    fontSize: FontSize.xs, color: Colors.gold, fontWeight: FontWeight.semibold,
    backgroundColor: Colors.goldSoft, paddingHorizontal: 8, paddingVertical: 3,
    borderRadius: Radius.full, alignSelf: 'flex-end', marginBottom: 8,
  },
  bannerTitle: { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: Colors.text, textAlign: 'right', lineHeight: 26, marginBottom: Spacing.md },
  bannerBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: Colors.gold, borderRadius: Radius.full,
    paddingVertical: 9, paddingHorizontal: Spacing.md, alignSelf: 'flex-end',
  },
  bannerBtnText: { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: Colors.primary },
  bannerIconArea: { justifyContent: 'center', paddingLeft: Spacing.sm },

  // Section
  section: { marginBottom: Spacing.lg, paddingHorizontal: Spacing.lg },
  sectionHeader: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    marginBottom: Spacing.md,
  },
  sectionTitle: { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: Colors.text },
  seeAll: { fontSize: FontSize.sm, color: Colors.gold, fontWeight: FontWeight.medium },
  activeDot: { width: 10, height: 10, borderRadius: 5, backgroundColor: Colors.info },

  // Categories
  categoriesGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm },
  categoryCard: { width: (width - Spacing.lg * 2 - Spacing.sm * 3) / 4 },
  categoryCardInner: {
    backgroundColor: Colors.surface, borderRadius: Radius.lg,
    paddingVertical: Spacing.md, alignItems: 'center', gap: Spacing.xs,
    borderWidth: 1, borderColor: Colors.border, ...Shadow.sm,
  },
  catIconBg: { width: 52, height: 52, borderRadius: Radius.md, alignItems: 'center', justifyContent: 'center' },
  catName: { fontSize: FontSize.xs, color: Colors.text, fontWeight: FontWeight.semibold, textAlign: 'center' },
  catCount: { fontSize: 10, color: Colors.textMuted, textAlign: 'center' },

  // Craftsman cards
  craftsmanCard: { width: 170 },
  craftsmanCardInner: { backgroundColor: Colors.surface, borderRadius: Radius.xl, overflow: 'hidden', borderWidth: 1, borderColor: Colors.border, ...Shadow.md },
  cardImageWrapper: { position: 'relative' },
  craftsmanImg: { width: '100%', height: 170 },
  availBadge: {
    position: 'absolute', bottom: 8, right: 8, flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: 'rgba(0,0,0,0.6)', borderRadius: Radius.full, paddingVertical: 4, paddingHorizontal: 8,
  },
  availDot: { width: 7, height: 7, borderRadius: 3.5, backgroundColor: Colors.success },
  availText: { fontSize: 10, color: Colors.text, fontWeight: FontWeight.medium },
  favBtn: {
    position: 'absolute', top: 8, left: 8, width: 32, height: 32, borderRadius: 16,
    backgroundColor: 'rgba(0,0,0,0.5)', alignItems: 'center', justifyContent: 'center',
  },
  craftsmanInfo: { padding: Spacing.sm, gap: 3 },
  craftsmanName: { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: Colors.text, textAlign: 'right' },
  craftsmanSpec: { fontSize: FontSize.xs, color: Colors.gold, textAlign: 'right' },
  ratingRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 2 },
  ratingBadge: { flexDirection: 'row', alignItems: 'center', gap: 2, backgroundColor: Colors.goldSoft, borderRadius: Radius.full, paddingHorizontal: 6, paddingVertical: 2 },
  ratingNum: { fontSize: 11, color: Colors.gold, fontWeight: FontWeight.semibold },
  ratingDist: { fontSize: 10, color: Colors.textMuted },

  // Stats
  statsRow: { flexDirection: 'row', paddingHorizontal: Spacing.lg, gap: Spacing.sm, marginBottom: Spacing.md },
  statCard: { flex: 1, backgroundColor: Colors.surface, borderRadius: Radius.lg, paddingVertical: Spacing.md, alignItems: 'center', gap: 4, borderWidth: 1, borderColor: Colors.border },
  statValue: { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: Colors.text },
  statLabel: { fontSize: FontSize.xs, color: Colors.textMuted, textAlign: 'center' },

  // Country section
  countryBarOuter: { height: 90 },
  countryBarInner: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: Spacing.lg, gap: Spacing.sm, height: 90 },
  countryBtn: {},
  countryBtnInner: {
    alignItems: 'center', gap: 5, backgroundColor: Colors.surface,
    borderRadius: Radius.xl, borderWidth: 1, borderColor: Colors.border,
    paddingVertical: Spacing.sm, paddingHorizontal: Spacing.md, minWidth: 68, ...Shadow.sm,
  },
  countryFlag: { fontSize: 26 },
  countryName: { fontSize: 10, color: Colors.textMuted, fontWeight: FontWeight.medium, textAlign: 'center', maxWidth: 60 },

  // Craftsman Home Stats
  cStatsRow: { flexDirection: 'row', paddingHorizontal: Spacing.lg, paddingVertical: Spacing.md, gap: Spacing.sm },
  cStatCard: {
    flex: 1, backgroundColor: Colors.surface, borderRadius: Radius.lg,
    paddingVertical: Spacing.md, alignItems: 'center', gap: 5,
    borderWidth: 1,
  },
  cStatValue: { fontSize: FontSize.xl, fontWeight: FontWeight.bold },
  cStatLabel: { fontSize: 10, color: Colors.textMuted, textAlign: 'center' },

  // Quick Actions
  quickActionsRow: { flexDirection: 'row', paddingHorizontal: Spacing.lg, gap: Spacing.sm, marginBottom: Spacing.md },
  quickActionBtn: {
    flex: 1, backgroundColor: Colors.surface, borderRadius: Radius.lg,
    paddingVertical: 12, alignItems: 'center', gap: 5,
    borderWidth: 1, borderColor: Colors.border,
  },
  quickActionText: { fontSize: FontSize.xs, color: Colors.gold, fontWeight: FontWeight.medium },

  // Available Jobs
  loadingRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, justifyContent: 'center', paddingVertical: Spacing.lg },
  loadingText: { color: Colors.textMuted, fontSize: FontSize.sm },
  emptyJobs: { alignItems: 'center', paddingVertical: Spacing.xl, gap: Spacing.sm },
  emptyJobsTitle: { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: Colors.text },
  emptyJobsText: { fontSize: FontSize.sm, color: Colors.textMuted, textAlign: 'center' },

  availJobCard: {
    backgroundColor: Colors.surface, borderRadius: Radius.xl, padding: Spacing.md,
    borderWidth: 1, borderColor: Colors.border, marginBottom: Spacing.md, ...Shadow.sm,
    gap: Spacing.sm,
  },
  availJobTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  availJobService: { fontSize: FontSize.base, fontWeight: FontWeight.bold, color: Colors.text, textAlign: 'right', flex: 1 },
  availJobMeta: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, flexWrap: 'wrap' },
  availJobBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: 'rgba(212,160,23,0.15)', borderRadius: Radius.full,
    paddingHorizontal: 8, paddingVertical: 4,
  },
  distanceBadge: { backgroundColor: 'rgba(46,204,113,0.15)' },
  availJobDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: Colors.gold },
  availJobBadgeText: { fontSize: 10, color: Colors.gold, fontWeight: FontWeight.bold },
  availJobDate: { fontSize: 10, color: Colors.textMuted },
  availJobDesc: { fontSize: FontSize.sm, color: Colors.textMuted, textAlign: 'right', lineHeight: 20 },
  availJobAddress: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  availJobAddressText: { fontSize: FontSize.sm, color: Colors.textMuted, flex: 1, textAlign: 'right' },
  availJobPrice: { flexDirection: 'row', alignItems: 'center', gap: 4, alignSelf: 'flex-end' },
  availJobPriceText: { fontSize: FontSize.sm, color: Colors.success, fontWeight: FontWeight.semibold },
  acceptBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: Spacing.sm,
    backgroundColor: Colors.gold, borderRadius: Radius.lg, paddingVertical: 12, ...Shadow.gold,
  },
  acceptBtnText: { fontSize: FontSize.base, fontWeight: FontWeight.bold, color: Colors.primary },

  // Job Card
  jobCard: { marginBottom: Spacing.md },
  jobCardInner: {
    backgroundColor: Colors.surface, borderRadius: Radius.xl, padding: Spacing.md,
    borderWidth: 1, borderColor: Colors.border, gap: Spacing.sm, ...Shadow.sm,
  },
  jobCardActive: { borderColor: Colors.info },
  jobCardTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  jobService: { fontSize: FontSize.base, fontWeight: FontWeight.bold, color: Colors.text, flex: 1, textAlign: 'right' },
  jobStatusBadge: { flexDirection: 'row', alignItems: 'center', gap: 4, borderRadius: Radius.full, paddingHorizontal: 8, paddingVertical: 4 },
  jobStatusDot: { width: 6, height: 6, borderRadius: 3 },
  jobStatusText: { fontSize: 10, fontWeight: FontWeight.bold },
  jobAddress: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  jobAddressText: { fontSize: FontSize.sm, color: Colors.textMuted, flex: 1, textAlign: 'right' },
  jobMeta: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  jobPrice: { fontSize: FontSize.sm, color: Colors.success, fontWeight: FontWeight.semibold },
  jobDate: { fontSize: FontSize.xs, color: Colors.textMuted },
  jobTrackHint: {
    flexDirection: 'row', alignItems: 'center', gap: 4, alignSelf: 'flex-end',
    backgroundColor: Colors.goldSoft, borderRadius: Radius.full, paddingHorizontal: 8, paddingVertical: 4,
  },
  jobTrackText: { fontSize: 10, color: Colors.gold, fontWeight: FontWeight.medium },
});
