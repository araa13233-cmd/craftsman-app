import React, {
  createContext, useState, useEffect, ReactNode,
  useCallback, useRef,
} from 'react';
import { getSupabaseClient, useAuth } from '@/template';

// ─── Types ─────────────────────────────────────────────────────────────────────
export type UserRole = 'customer' | 'craftsman';

export interface Craftsman {
  id: string;
  name: string;
  specialty: string;
  specialtyIcon: string;
  rating: number;
  reviewCount: number;
  distance: string;
  city: string;
  country: string;
  available: boolean;
  isOnline: boolean;
  isBusy: boolean;
  lastSeen: string | null;
  experience: number;
  price: string;
  image: string;
  phone: string;
  bio: string;
  completedJobs: number;
  skills: string[];
  portfolio: string[];
  latitude?: number | null;
  longitude?: number | null;
}

export type OrderStatus =
  | 'pending' | 'assigned' | 'accepted' | 'on_the_way'
  | 'in_progress' | 'completed' | 'cancelled';

export interface Order {
  id: string;
  craftsmanId?: string;
  craftsmanName: string;
  craftsmanImage: string;
  craftsmanPhone?: string;
  service: string;
  status: OrderStatus;
  date: string;
  price: string;
  address: string;
  description: string;
  userId?: string;
  latitude?: number | null;
  longitude?: number | null;
  distanceKm?: number;
}

export interface AutoAssignResult {
  success: boolean;
  craftsmanName?: string;
  distanceKm?: number;
  message: string;
}

interface AppContextType {
  // Role
  userRole: UserRole;
  craftsmanProfileId: string | null;
  roleLoading: boolean;
  refreshRole: () => Promise<void>;

  // Location
  craftsmanLocation: { latitude: number; longitude: number } | null;
  updateCraftsmanLocation: (lat: number, lng: number) => Promise<void>;

  // Online / busy status
  setOnlineStatus: (online: boolean) => Promise<void>;
  setCraftsmanBusy: (busy: boolean) => Promise<void>;

  // Craftsmen
  allCraftsmen: Craftsman[];
  craftsmenLoading: boolean;
  fetchCraftsmen: () => Promise<void>;

  // Orders (customer)
  orders: Order[];
  ordersLoading: boolean;
  addOrder: (order: Omit<Order, 'id' | 'date'> & { latitude?: number | null; longitude?: number | null; scheduledAt?: string }) => Promise<AutoAssignResult>;
  fetchOrders: () => Promise<void>;

  // Available Jobs (craftsman)
  availableJobs: Order[];
  availableJobsLoading: boolean;
  fetchAvailableJobs: () => Promise<void>;

  // Assigned Jobs (craftsman)
  assignedJobs: Order[];
  fetchAssignedJobs: () => Promise<void>;
  acceptJob: (orderId: string) => Promise<boolean>;
  updateJobStatus: (orderId: string, status: OrderStatus) => Promise<boolean>;

  // Favorites
  favorites: string[];
  toggleFavorite: (craftsmanId: string) => Promise<void>;
  isFavorite: (craftsmanId: string) => boolean;
  favoritesLoading: boolean;
}

export const AppContext = createContext<AppContextType | undefined>(undefined);

// ─── Mapper: DB row → Craftsman ───────────────────────────────────────────────
function mapCraftsman(row: any): Craftsman {
  return {
    id: row.id,
    name: row.name,
    specialty: row.specialty,
    specialtyIcon: row.specialty_icon ?? 'build',
    rating: parseFloat(row.rating) || 0,
    reviewCount: row.review_count ?? 0,
    distance: row.distance ?? '1 كم',
    city: row.city ?? 'الرياض',
    country: row.country ?? 'السعودية',
    available: row.available ?? true,
    isOnline: row.is_online ?? false,
    isBusy: row.is_busy ?? false,
    lastSeen: row.last_seen ?? null,
    experience: row.experience ?? 1,
    price: row.price_range ?? '50 - 150 ريال',
    image: row.image_url ?? 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400',
    phone: row.phone ?? '',
    bio: row.bio ?? '',
    completedJobs: row.completed_jobs ?? 0,
    skills: row.skills ?? [],
    portfolio: row.portfolio_urls ?? [],
    latitude: row.latitude ?? null,
    longitude: row.longitude ?? null,
  };
}

// ─── Haversine Distance (km) ─────────────────────────────────────────────────
export function haversineKm(
  lat1: number, lon1: number,
  lat2: number, lon2: number,
): number {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) *
    Math.cos((lat2 * Math.PI) / 180) *
    Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

// ─── Mapper: DB row → Order ───────────────────────────────────────────────────
function mapOrder(row: any): Order {
  return {
    id: row.id,
    craftsmanId: row.craftsman_id,
    craftsmanName: row.craftsman_name ?? 'حرفي',
    craftsmanImage:
      row.craftsman_image ??
      'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400',
    craftsmanPhone: row.craftsman_phone ?? '',
    service: row.service_type,
    status: row.status as OrderStatus,
    date: row.scheduled_at
      ? new Date(row.scheduled_at).toLocaleString('ar-SA')
      : new Date(row.created_at).toLocaleString('ar-SA'),
    price: row.price ?? '',
    address: row.address ?? '',
    description: row.description ?? '',
    userId: row.user_id,
    latitude: row.latitude ?? null,
    longitude: row.longitude ?? null,
  };
}

// ─── Auto-assign: find nearest available craftsman ───────────────────────────
async function autoAssignCraftsman(
  supabase: ReturnType<typeof getSupabaseClient>,
  orderId: string,
  serviceType: string,
  latitude: number | null,
  longitude: number | null,
): Promise<AutoAssignResult> {
  try {
    const { data: craftsmen, error } = await supabase
      .from('craftsmen')
      .select('id, name, image_url, phone, specialty, city, latitude, longitude, rating')
      .eq('is_active', true)
      .eq('available', true)
      .eq('is_busy', false);

    if (error || !craftsmen || craftsmen.length === 0) {
      return { success: false, message: 'لا يوجد حرفيون متاحون حالياً، سيتم البحث قريباً' };
    }

    type ScoredCraftsman = typeof craftsmen[0] & { score: number; distKm: number };
    const scored: ScoredCraftsman[] = craftsmen.map((c: any) => {
      let score = 0;
      let distKm = 9999;

      const specMatch =
        c.specialty?.toLowerCase().includes(serviceType.toLowerCase()) ||
        serviceType.toLowerCase().includes(c.specialty?.toLowerCase() ?? '');
      if (specMatch) score += 100;

      if (latitude && longitude && c.latitude && c.longitude) {
        distKm = haversineKm(latitude, longitude, c.latitude, c.longitude);
        score += Math.max(0, 50 - distKm);
      }

      score += (c.rating ?? 0) * 2;
      return { ...c, score, distKm };
    });

    scored.sort((a, b) => b.score - a.score);
    const best = scored[0];

    const { error: updateErr } = await supabase
      .from('orders')
      .update({
        craftsman_id: best.id,
        craftsman_name: best.name,
        craftsman_image: best.image_url ?? '',
        craftsman_phone: best.phone ?? '',
        status: 'assigned',
        updated_at: new Date().toISOString(),
      })
      .eq('id', orderId)
      .is('craftsman_id', null);

    if (updateErr) {
      return { success: false, message: 'حدث خطأ في التعيين، يرجى المحاولة مرة أخرى' };
    }

    await supabase
      .from('craftsmen')
      .update({ is_busy: true, updated_at: new Date().toISOString() })
      .eq('id', best.id);

    const distLabel = best.distKm < 9999
      ? `على بُعد ${best.distKm.toFixed(1)} كم`
      : `في ${best.city ?? 'منطقتك'}`;

    return {
      success: true,
      craftsmanName: best.name,
      distanceKm: best.distKm < 9999 ? best.distKm : undefined,
      message: `تم تعيين ${best.name} (${best.specialty ?? ''}) ${distLabel}`,
    };
  } catch (err) {
    console.error('[autoAssign] error:', err);
    return { success: false, message: 'حدث خطأ غير متوقع أثناء التعيين' };
  }
}

// ─── Provider ─────────────────────────────────────────────────────────────────
export function AppProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const supabase = getSupabaseClient();

  // Refs — avoid stale closures
  const roleLoadingRef = useRef(false);
  const onlineIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const craftsmanProfileIdRef = useRef<string | null>(null);
  const craftsmanLocationRef = useRef<{ latitude: number; longitude: number } | null>(null);

  // ── State ──────────────────────────────────────────────────────────────────
  const [userRole, setUserRole] = useState<UserRole>('customer');
  const [craftsmanProfileId, setCraftsmanProfileId] = useState<string | null>(null);
  const [roleLoading, setRoleLoading] = useState(true);
  const [craftsmanLocation, setCraftsmanLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [allCraftsmen, setAllCraftsmen] = useState<Craftsman[]>([]);
  const [craftsmenLoading, setCraftsmenLoading] = useState(false);
  const [orders, setOrders] = useState<Order[]>([]);
  const [ordersLoading, setOrdersLoading] = useState(false);
  const [availableJobs, setAvailableJobs] = useState<Order[]>([]);
  const [availableJobsLoading, setAvailableJobsLoading] = useState(false);
  const [assignedJobs, setAssignedJobs] = useState<Order[]>([]);
  const [favorites, setFavorites] = useState<string[]>([]);
  const [favoritesLoading, setFavoritesLoading] = useState(false);

  // Keep refs in sync
  useEffect(() => {
    craftsmanProfileIdRef.current = craftsmanProfileId;
  }, [craftsmanProfileId]);

  useEffect(() => {
    craftsmanLocationRef.current = craftsmanLocation;
  }, [craftsmanLocation]);

  // ── Online Status ──────────────────────────────────────────────────────────
  const setOnlineStatus = useCallback(async (online: boolean) => {
    const profileId = craftsmanProfileIdRef.current;
    if (!profileId) return;
    await supabase
      .from('craftsmen')
      .update({ is_online: online, last_seen: new Date().toISOString(), updated_at: new Date().toISOString() })
      .eq('id', profileId);
  }, [supabase]);

  // ── Busy Status ────────────────────────────────────────────────────────────
  const setCraftsmanBusy = useCallback(async (busy: boolean) => {
    const profileId = craftsmanProfileIdRef.current;
    if (!profileId) return;
    await supabase
      .from('craftsmen')
      .update({ is_busy: busy, updated_at: new Date().toISOString() })
      .eq('id', profileId);
  }, [supabase]);

  // Heartbeat
  useEffect(() => {
    if (userRole !== 'craftsman' || !craftsmanProfileId) return;
    setOnlineStatus(true);
    onlineIntervalRef.current = setInterval(() => setOnlineStatus(true), 120_000);
    return () => {
      if (onlineIntervalRef.current) clearInterval(onlineIntervalRef.current);
      setOnlineStatus(false).catch(() => {});
    };
  }, [userRole, craftsmanProfileId, setOnlineStatus]);

  // ── Update Location ────────────────────────────────────────────────────────
  const updateCraftsmanLocation = useCallback(async (lat: number, lng: number) => {
    const profileId = craftsmanProfileIdRef.current;
    if (!profileId) return;
    setCraftsmanLocation({ latitude: lat, longitude: lng });
    await supabase
      .from('craftsmen')
      .update({ latitude: lat, longitude: lng, updated_at: new Date().toISOString() })
      .eq('id', profileId);
  }, [supabase]);

  // ── Detect Role ────────────────────────────────────────────────────────────
  const refreshRole = useCallback(async () => {
    if (roleLoadingRef.current) return;
    roleLoadingRef.current = true;
    setRoleLoading(true);

    try {
      if (!user) {
        setUserRole('customer');
        setCraftsmanProfileId(null);
        craftsmanProfileIdRef.current = null;
        return;
      }

      const { data: craftsmanRow, error: craftsmanErr } = await supabase
        .from('craftsmen')
        .select('id, latitude, longitude, is_active, is_busy')
        .eq('user_id', user.id)
        .eq('is_active', true)
        .maybeSingle();

      if (!craftsmanErr && craftsmanRow) {
        setUserRole('craftsman');
        setCraftsmanProfileId(craftsmanRow.id);
        craftsmanProfileIdRef.current = craftsmanRow.id;
        if (craftsmanRow.latitude && craftsmanRow.longitude) {
          const loc = { latitude: craftsmanRow.latitude, longitude: craftsmanRow.longitude };
          setCraftsmanLocation(loc);
          craftsmanLocationRef.current = loc;
        }
        supabase.from('user_profiles').update({ role: 'craftsman' }).eq('id', user.id).then(() => {});
      } else {
        const { data: profile } = await supabase
          .from('user_profiles').select('role').eq('id', user.id).maybeSingle();

        if (profile?.role === 'craftsman') {
          const { data: inactiveCraftsman } = await supabase
            .from('craftsmen').select('id, latitude, longitude').eq('user_id', user.id).maybeSingle();

          if (inactiveCraftsman) {
            setUserRole('craftsman');
            setCraftsmanProfileId(inactiveCraftsman.id);
            craftsmanProfileIdRef.current = inactiveCraftsman.id;
            if (inactiveCraftsman.latitude && inactiveCraftsman.longitude) {
              const loc = { latitude: inactiveCraftsman.latitude, longitude: inactiveCraftsman.longitude };
              setCraftsmanLocation(loc);
              craftsmanLocationRef.current = loc;
            }
          } else {
            setUserRole('customer');
            setCraftsmanProfileId(null);
            craftsmanProfileIdRef.current = null;
            supabase.from('user_profiles').update({ role: 'customer' }).eq('id', user.id).then(() => {});
          }
        } else {
          setUserRole('customer');
          setCraftsmanProfileId(null);
          craftsmanProfileIdRef.current = null;
        }
      }
    } catch (err) {
      console.error('[AppContext] refreshRole error:', err);
    } finally {
      setRoleLoading(false);
      roleLoadingRef.current = false;
    }
  }, [user, supabase]);

  // ── Fetch Craftsmen (public) ─────────────────────────────────────────────
  const fetchCraftsmen = useCallback(async () => {
    setCraftsmenLoading(true);
    try {
      const { data, error } = await supabase
        .from('craftsmen').select('*').eq('is_active', true).order('rating', { ascending: false });
      if (!error && data) setAllCraftsmen(data.map(mapCraftsman));
    } finally {
      setCraftsmenLoading(false);
    }
  }, [supabase]);

  // ── Fetch Customer Orders ─────────────────────────────────────────────────
  const fetchOrders = useCallback(async () => {
    if (!user) { setOrders([]); return; }
    setOrdersLoading(true);
    try {
      const { data, error } = await supabase
        .from('orders').select('*').eq('user_id', user.id).order('created_at', { ascending: false });
      if (!error && data) setOrders(data.map(mapOrder));
    } finally {
      setOrdersLoading(false);
    }
  }, [user, supabase]);

  // ── Fetch Available Jobs (craftsman) ─────────────────────────────────────
  const fetchAvailableJobs = useCallback(async () => {
    if (!user) return;
    const profileId = craftsmanProfileIdRef.current;
    setAvailableJobsLoading(true);
    try {
      // Get unassigned pending jobs
      const { data: pendingJobs } = await supabase
        .from('orders')
        .select('*')
        .eq('status', 'pending')
        .is('craftsman_id', null)
        .order('created_at', { ascending: false });

      // Get assigned-to-me jobs not yet accepted
      let assignedToMe: any[] = [];
      if (profileId) {
        const { data: myAssigned } = await supabase
          .from('orders')
          .select('*')
          .eq('craftsman_id', profileId)
          .eq('status', 'assigned')
          .order('created_at', { ascending: false });
        assignedToMe = myAssigned ?? [];
      }

      const allJobs = [...(pendingJobs ?? []), ...assignedToMe];
      const uniqueJobs = allJobs.filter(
        (job, idx, arr) => arr.findIndex(j => j.id === job.id) === idx
      );

      let jobs = uniqueJobs.map(mapOrder);
      const loc = craftsmanLocationRef.current;
      if (loc) {
        jobs = jobs
          .map(job => ({
            ...job,
            distanceKm: job.latitude && job.longitude
              ? haversineKm(loc.latitude, loc.longitude, job.latitude, job.longitude)
              : 9999,
          }))
          .sort((a, b) => (a.distanceKm ?? 9999) - (b.distanceKm ?? 9999));
      }
      setAvailableJobs(jobs);
    } finally {
      setAvailableJobsLoading(false);
    }
  }, [user, supabase]);

  // ── Fetch Assigned Jobs (craftsman) — core refresh function ──────────────
  const fetchAssignedJobs = useCallback(async () => {
    const profileId = craftsmanProfileIdRef.current;
    if (!profileId) return;
    try {
      const { data, error } = await supabase
        .from('orders')
        .select('*')
        .eq('craftsman_id', profileId)
        .order('created_at', { ascending: false });

      if (!error && data) {
        setAssignedJobs(data.map(mapOrder));
        // Auto-release busy if no active jobs
        const activeStatuses = ['assigned', 'accepted', 'on_the_way', 'in_progress'];
        const hasActive = data.some(o => activeStatuses.includes(o.status));
        if (!hasActive) {
          supabase.from('craftsmen').update({ is_busy: false }).eq('id', profileId).then(() => {});
        }
      }
    } catch (err) {
      console.error('[fetchAssignedJobs] error:', err);
    }
  }, [supabase]);

  // ── Accept Job ─────────────────────────────────────────────────────────────
  // Handles both: manually claiming unassigned orders AND confirming auto-assigned ones
  const acceptJob = useCallback(async (orderId: string): Promise<boolean> => {
    const profileId = craftsmanProfileIdRef.current;
    if (!profileId || !user) {
      console.error('[acceptJob] Missing profileId or user');
      return false;
    }

    try {
      // 1. Fetch craftsman metadata
      const { data: craftsmanData, error: craftsmanErr } = await supabase
        .from('craftsmen')
        .select('id, name, image_url, phone')
        .eq('id', profileId)
        .single();

      if (craftsmanErr || !craftsmanData) {
        console.error('[acceptJob] Could not fetch craftsman:', craftsmanErr);
        return false;
      }

      // 2. Check current order state
      const { data: currentOrder, error: orderErr } = await supabase
        .from('orders')
        .select('id, status, craftsman_id')
        .eq('id', orderId)
        .single();

      if (orderErr || !currentOrder) {
        console.error('[acceptJob] Order not found:', orderId, orderErr);
        return false;
      }

      // 3. Prevent double-accept
      if (currentOrder.status === 'accepted' && currentOrder.craftsman_id === profileId) {
        console.warn('[acceptJob] Already accepted');
        await fetchAssignedJobs();
        return true;
      }

      // 4. Build update payload
      const updatePayload: Record<string, any> = {
        craftsman_id: profileId,
        craftsman_name: craftsmanData.name ?? '',
        craftsman_image: craftsmanData.image_url ?? '',
        craftsman_phone: craftsmanData.phone ?? '',
        status: 'accepted',
        updated_at: new Date().toISOString(),
      };

      // 5. Execute update — no extra filters beyond orderId
      // RLS policy 'craftsman_update_assigned_orders' handles security
      // RLS policy 'craftsman_claim_pending_orders' handles unassigned claims
      const { data: updatedRows, error: updateErr } = await supabase
        .from('orders')
        .update(updatePayload)
        .eq('id', orderId)
        .select('id, status, craftsman_id');

      if (updateErr) {
        console.error('[acceptJob] Update error:', updateErr);
        return false;
      }

      if (!updatedRows || updatedRows.length === 0) {
        console.warn('[acceptJob] No rows updated — possible RLS block or race condition');
        // Verify if already accepted by this craftsman
        const { data: verify } = await supabase
          .from('orders')
          .select('status, craftsman_id')
          .eq('id', orderId)
          .single();
        if (verify?.status === 'accepted' && verify?.craftsman_id === profileId) {
          await fetchAssignedJobs();
          return true;
        }
        return false;
      }

      // 6. Mark craftsman as busy
      await supabase
        .from('craftsmen')
        .update({ is_busy: true, updated_at: new Date().toISOString() })
        .eq('id', profileId);

      // 7. Update local state
      setAvailableJobs(prev => prev.filter(j => j.id !== orderId));

      // 8. Refresh from DB (source of truth)
      await fetchAssignedJobs();
      setTimeout(() => fetchAvailableJobs(), 600);

      return true;
    } catch (err) {
      console.error('[acceptJob] Exception:', err);
      return false;
    }
  }, [user, supabase, fetchAssignedJobs, fetchAvailableJobs]);

  // ── Update Job Status ─────────────────────────────────────────────────────
  const updateJobStatus = useCallback(
    async (orderId: string, status: OrderStatus): Promise<boolean> => {
      const profileId = craftsmanProfileIdRef.current;
      if (!profileId) {
        console.error('[updateJobStatus] No craftsman profile');
        return false;
      }

      // 'assigned' → 'accepted' goes through acceptJob for full metadata update
      if (status === 'accepted') {
        return acceptJob(orderId);
      }

      // Optimistic UI update
      setAssignedJobs(prev =>
        prev.map(j => (j.id === orderId ? { ...j, status } : j))
      );

      try {
        const { data: updatedRows, error } = await supabase
          .from('orders')
          .update({ status, updated_at: new Date().toISOString() })
          .eq('id', orderId)
          .eq('craftsman_id', profileId)
          .select('id, status');

        if (error) {
          console.error('[updateJobStatus] DB error:', error);
          await fetchAssignedJobs(); // revert
          return false;
        }

        if (!updatedRows || updatedRows.length === 0) {
          console.warn('[updateJobStatus] No rows updated');
          await fetchAssignedJobs(); // revert
          return false;
        }

        // Release busy on completion/cancellation
        if (status === 'completed' || status === 'cancelled') {
          const { data: otherActive } = await supabase
            .from('orders')
            .select('id')
            .eq('craftsman_id', profileId)
            .in('status', ['assigned', 'accepted', 'on_the_way', 'in_progress'])
            .neq('id', orderId);

          if (!otherActive?.length) {
            await supabase
              .from('craftsmen')
              .update({ is_busy: false, updated_at: new Date().toISOString() })
              .eq('id', profileId);
          }
        }

        // Confirm from DB
        await fetchAssignedJobs();
        return true;
      } catch (err) {
        console.error('[updateJobStatus] Exception:', err);
        await fetchAssignedJobs(); // revert
        return false;
      }
    },
    [supabase, acceptJob, fetchAssignedJobs],
  );

  // ── Fetch Favorites ───────────────────────────────────────────────────────
  const fetchFavorites = useCallback(async () => {
    if (!user) { setFavorites([]); return; }
    setFavoritesLoading(true);
    try {
      const { data, error } = await supabase.from('favorites').select('craftsman_id');
      if (!error && data) setFavorites(data.map((r: any) => r.craftsman_id));
    } finally {
      setFavoritesLoading(false);
    }
  }, [user, supabase]);

  // ── Add Order (with auto-assignment) ─────────────────────────────────────
  const addOrder = useCallback(
    async (
      order: Omit<Order, 'id' | 'date'> & { latitude?: number | null; longitude?: number | null; scheduledAt?: string }
    ): Promise<AutoAssignResult> => {
      if (!user) return { success: false, message: 'يجب تسجيل الدخول أولاً' };

      const { data, error } = await supabase
        .from('orders')
        .insert({
          user_id: user.id,
          craftsman_id: null,
          craftsman_name: 'جاري البحث عن حرفي...',
          craftsman_image: '',
          service_type: order.service,
          status: 'pending',
          price: order.price || 'سيتم التحديد',
          address: order.address,
          description: order.description,
          latitude: order.latitude ?? null,
          longitude: order.longitude ?? null,
          scheduled_at: (order as any).scheduledAt ?? null,
        })
        .select()
        .single();

      if (error || !data) {
        return { success: false, message: 'حدث خطأ أثناء إنشاء الطلب' };
      }

      setOrders(prev => [mapOrder(data), ...prev]);

      const assignResult = await autoAssignCraftsman(
        supabase, data.id, order.service, order.latitude ?? null, order.longitude ?? null,
      );

      await fetchOrders();
      return assignResult;
    },
    [user, supabase, fetchOrders],
  );

  // ── Toggle Favorite ───────────────────────────────────────────────────────
  const toggleFavorite = useCallback(async (craftsmanId: string) => {
    if (!user) return;
    const isFav = favorites.includes(craftsmanId);
    if (isFav) {
      setFavorites(prev => prev.filter(id => id !== craftsmanId));
      await supabase.from('favorites').delete().eq('craftsman_id', craftsmanId).eq('user_id', user.id);
    } else {
      setFavorites(prev => [...prev, craftsmanId]);
      await supabase.from('favorites').insert({ user_id: user.id, craftsman_id: craftsmanId });
    }
  }, [user, favorites, supabase]);

  const isFavorite = useCallback(
    (craftsmanId: string) => favorites.includes(craftsmanId),
    [favorites],
  );

  // ── Effects ───────────────────────────────────────────────────────────────
  useEffect(() => { refreshRole(); }, [refreshRole]);
  useEffect(() => { fetchCraftsmen(); }, [fetchCraftsmen]);

  useEffect(() => {
    if (user) {
      fetchOrders();
      fetchFavorites();
    } else {
      setOrders([]);
      setFavorites([]);
      setAssignedJobs([]);
      setAvailableJobs([]);
    }
  }, [user, fetchOrders, fetchFavorites]);

  // Craftsman polling
  useEffect(() => {
    if (userRole !== 'craftsman' || roleLoading) return;

    fetchAvailableJobs();
    fetchAssignedJobs();

    const interval = setInterval(() => {
      fetchAvailableJobs();
      fetchAssignedJobs();
    }, 15_000);

    return () => clearInterval(interval);
  }, [userRole, roleLoading, fetchAvailableJobs, fetchAssignedJobs]);

  // ── Context Value ─────────────────────────────────────────────────────────
  return (
    <AppContext.Provider
      value={{
        userRole, craftsmanProfileId, roleLoading, refreshRole,
        craftsmanLocation, updateCraftsmanLocation,
        setOnlineStatus, setCraftsmanBusy,
        allCraftsmen, craftsmenLoading, fetchCraftsmen,
        orders, ordersLoading, addOrder, fetchOrders,
        availableJobs, availableJobsLoading, fetchAvailableJobs,
        assignedJobs, fetchAssignedJobs, acceptJob, updateJobStatus,
        favorites, toggleFavorite, isFavorite, favoritesLoading,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}
