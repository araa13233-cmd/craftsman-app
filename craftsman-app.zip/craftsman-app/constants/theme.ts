// Muallim App Theme - معلم
export const Colors = {
  // Core Palette
  primary: '#0D1B3E',       // Navy Dark
  primaryLight: '#132040',  // Navy Light
  primaryMid: '#1A2B4A',    // Navy Mid
  primarySurface: '#1E3055',// Surface cards

  // Gold Accent
  gold: '#D4A017',
  goldLight: '#F5C842',
  goldDim: '#A07810',
  goldSoft: 'rgba(212,160,23,0.15)',

  // Backgrounds
  background: '#080F20',
  surface: '#101D35',
  surface2: '#162236',
  cardBg: 'rgba(20, 35, 65, 0.9)',
  glass: 'rgba(255,255,255,0.05)',
  glassBorder: 'rgba(212,160,23,0.2)',

  // Text
  text: '#F0F4FF',
  textMuted: '#7A90BB',
  textLight: '#FFFFFF',
  textDark: '#3A4A6A',

  // Status
  success: '#2ECC71',
  error: '#E74C3C',
  warning: '#F39C12',
  info: '#3498DB',

  // Misc
  border: 'rgba(212,160,23,0.15)',
  divider: 'rgba(255,255,255,0.07)',
  overlay: 'rgba(8,15,32,0.85)',
  available: '#2ECC71',
  unavailable: '#E74C3C',
  pending: '#F39C12',
};

export const Spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
};

export const Radius = {
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  xxl: 32,
  full: 999,
};

export const FontSize = {
  xs: 11,
  sm: 13,
  md: 15,
  base: 16,
  lg: 18,
  xl: 20,
  xxl: 24,
  xxxl: 30,
  giant: 38,
};

export const FontWeight = {
  regular: '400' as const,
  medium: '500' as const,
  semibold: '600' as const,
  bold: '700' as const,
  extrabold: '800' as const,
};

export const Shadow = {
  sm: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 3,
  },
  md: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 6,
  },
  lg: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.4,
    shadowRadius: 16,
    elevation: 10,
  },
  gold: {
    shadowColor: '#D4A017',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    elevation: 8,
  },
};
