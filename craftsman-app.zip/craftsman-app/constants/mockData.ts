export interface Craftsman {
  id: string;
  name: string;
  specialty: string;
  specialtyIcon: string;
  rating: number;
  reviewCount: number;
  distance: string;
  city: string;
  available: boolean;
  experience: number;
  price: string;
  image: string;
  phone: string;
  bio: string;
  completedJobs: number;
  skills: string[];
  portfolio: string[];
  reviews: Review[];
}

export interface Review {
  id: string;
  userName: string;
  rating: number;
  comment: string;
  date: string;
}

export interface ServiceCategory {
  id: string;
  name: string;
  icon: string;
  color: string;
  count: number;
}

export interface Order {
  id: string;
  craftsmanName: string;
  craftsmanImage: string;
  service: string;
  status: 'pending' | 'in_progress' | 'completed' | 'cancelled';
  date: string;
  price: string;
  address: string;
  description: string;
}

export const serviceCategories: ServiceCategory[] = [
  { id: '1', name: 'كهربائي', icon: 'flash', color: '#F5C842', count: 45 },
  { id: '2', name: 'سباك', icon: 'water', color: '#3498DB', count: 38 },
  { id: '3', name: 'نجار', icon: 'build', color: '#8B4513', count: 22 },
  { id: '4', name: 'دهان', icon: 'brush', color: '#E74C3C', count: 31 },
  { id: '5', name: 'صيانة أجهزة', icon: 'settings', color: '#9B59B6', count: 27 },
  { id: '6', name: 'مكيفات', icon: 'ac-unit', color: '#1ABC9C', count: 19 },
  { id: '7', name: 'ألمنيوم', icon: 'grid-on', color: '#95A5A6', count: 14 },
  { id: '8', name: 'طاقة شمسية', icon: 'wb-sunny', color: '#F39C12', count: 12 },
];

export const craftsmen: Craftsman[] = [
  {
    id: '1',
    name: 'أحمد محمد الزهراني',
    specialty: 'كهربائي معتمد',
    specialtyIcon: 'flash',
    rating: 4.9,
    reviewCount: 127,
    distance: '0.8 كم',
    city: 'الرياض',
    available: true,
    experience: 12,
    price: '80 - 200 ريال',
    image: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400',
    phone: '+966501234567',
    bio: 'كهربائي معتمد بخبرة 12 سنة في الأعمال الكهربائية السكنية والتجارية. متخصص في تركيب لوحات الكهرباء والإضاءة وصيانة الأجهزة الكهربائية.',
    completedJobs: 543,
    skills: ['لوحات كهربائية', 'إضاءة LED', 'تمديدات كهربائية', 'صيانة مولدات'],
    portfolio: [
      'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400',
      'https://images.unsplash.com/photo-1621905251189-08b45d6a269e?w=400',
      'https://images.unsplash.com/photo-1581094794329-c8112a89af12?w=400',
    ],
    reviews: [
      { id: '1', userName: 'محمد العتيبي', rating: 5, comment: 'خدمة ممتازة وسريعة، عمل نظيف واحترافي للغاية', date: '2024-01-15' },
      { id: '2', userName: 'فهد الغامدي', rating: 5, comment: 'أنصح به بشدة، محترف ومتقن في عمله', date: '2024-01-10' },
      { id: '3', userName: 'عبدالله السهلي', rating: 4, comment: 'عمل جيد والأسعار معقولة', date: '2024-01-05' },
    ],
  },
  {
    id: '2',
    name: 'خالد عبدالرحمن العسيري',
    specialty: 'سباك محترف',
    specialtyIcon: 'water',
    rating: 4.7,
    reviewCount: 89,
    distance: '1.2 كم',
    city: 'الرياض',
    available: true,
    experience: 8,
    price: '60 - 150 ريال',
    image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400',
    phone: '+966509876543',
    bio: 'سباك محترف متخصص في إصلاح تسريبات المياه وتركيب الأدوات الصحية وصيانة شبكات الصرف الصحي.',
    completedJobs: 312,
    skills: ['إصلاح تسريبات', 'تركيب أدوات صحية', 'صرف صحي', 'سخانات مياه'],
    portfolio: [
      'https://images.unsplash.com/photo-1585771724684-38269d6639fd?w=400',
      'https://images.unsplash.com/photo-1594736797933-d0401ba2b65a?w=400',
      'https://images.unsplash.com/photo-1604754742629-3e5728249d73?w=400',
    ],
    reviews: [
      { id: '1', userName: 'سعد المالكي', rating: 5, comment: 'حل المشكلة بسرعة فائقة، شخص أمين ونظيف في العمل', date: '2024-01-18' },
      { id: '2', userName: 'تركي الدوسري', rating: 4, comment: 'خدمة جيدة، ينصح به', date: '2024-01-12' },
    ],
  },
  {
    id: '3',
    name: 'عمر سليمان البلوي',
    specialty: 'نجار وأثاث',
    specialtyIcon: 'build',
    rating: 4.8,
    reviewCount: 64,
    distance: '2.1 كم',
    city: 'الرياض',
    available: false,
    experience: 15,
    price: '100 - 300 ريال',
    image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400',
    phone: '+966555667788',
    bio: 'نجار ذو خبرة 15 سنة في تصنيع وتركيب الأثاث والأبواب والنوافذ الخشبية.',
    completedJobs: 245,
    skills: ['تركيب أثاث', 'صيانة أبواب', 'تصنيع مطابخ', 'باركيه وديكور'],
    portfolio: [
      'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=400',
      'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=400',
      'https://images.unsplash.com/photo-1567538096630-e0c55bd6374c?w=400',
    ],
    reviews: [
      { id: '1', userName: 'نواف العنزي', rating: 5, comment: 'فنان في عمله! المطبخ طلع رائع جداً', date: '2024-01-20' },
    ],
  },
  {
    id: '4',
    name: 'يوسف إبراهيم القحطاني',
    specialty: 'دهان وديكور',
    specialtyIcon: 'brush',
    rating: 4.6,
    reviewCount: 92,
    distance: '1.5 كم',
    city: 'الرياض',
    available: true,
    experience: 10,
    price: '70 - 250 ريال',
    image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400',
    phone: '+966544332211',
    bio: 'متخصص في أعمال الدهان والديكور الداخلي بأحدث الأساليب وأفضل الخامات.',
    completedJobs: 389,
    skills: ['دهان داخلي', 'دهان خارجي', 'ورق جدران', 'جبس وديكور'],
    portfolio: [
      'https://images.unsplash.com/photo-1562663474-6cbb3eaa4d14?w=400',
      'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400',
      'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?w=400',
    ],
    reviews: [
      { id: '1', userName: 'راشد الشمري', rating: 5, comment: 'شغل نظيف وألوان جميلة، ممتاز', date: '2024-01-22' },
      { id: '2', userName: 'بندر الحربي', rating: 4, comment: 'محترف في عمله', date: '2024-01-15' },
    ],
  },
  {
    id: '5',
    name: 'علي حسن المطيري',
    specialty: 'صيانة مكيفات',
    specialtyIcon: 'ac-unit',
    rating: 4.9,
    reviewCount: 156,
    distance: '0.5 كم',
    city: 'الرياض',
    available: true,
    experience: 9,
    price: '80 - 200 ريال',
    image: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=400',
    phone: '+966533221100',
    bio: 'متخصص في صيانة وتركيب جميع أنواع المكيفات السبليت والمركزية.',
    completedJobs: 621,
    skills: ['صيانة سبليت', 'مكيفات مركزية', 'شحن غاز', 'تنظيف فلاتر'],
    portfolio: [
      'https://images.unsplash.com/photo-1504328345606-18bbc8c9d7d1?w=400',
      'https://images.unsplash.com/photo-1581578731548-c64695cc6952?w=400',
      'https://images.unsplash.com/photo-1540497077202-7c8a3999166f?w=400',
    ],
    reviews: [
      { id: '1', userName: 'وليد الرشيدي', rating: 5, comment: 'خبرة عالية وأمانة في التعامل', date: '2024-01-25' },
      { id: '2', userName: 'مشاري العجمي', rating: 5, comment: 'أسرع من المتوقع وبسعر مناسب', date: '2024-01-20' },
    ],
  },
  {
    id: '6',
    name: 'فارس ناصر الوذيناني',
    specialty: 'طاقة شمسية',
    specialtyIcon: 'wb-sunny',
    rating: 4.8,
    reviewCount: 43,
    distance: '3.2 كم',
    city: 'الرياض',
    available: true,
    experience: 6,
    price: '200 - 500 ريال',
    image: 'https://images.unsplash.com/photo-1566492031773-4f4e44671857?w=400',
    phone: '+966522334455',
    bio: 'متخصص في تركيب وصيانة أنظمة الطاقة الشمسية للمنازل والمنشآت التجارية.',
    completedJobs: 128,
    skills: ['ألواح شمسية', 'بطاريات طاقة', 'أنظمة مستقلة', 'شبكة الكهرباء'],
    portfolio: [
      'https://images.unsplash.com/photo-1509391366360-2e959784a276?w=400',
      'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400',
      'https://images.unsplash.com/photo-1497435334941-8c899ee9e8e9?w=400',
    ],
    reviews: [
      { id: '1', userName: 'حمد السبيعي', rating: 5, comment: 'محترف جداً في مجال الطاقة الشمسية', date: '2024-01-10' },
    ],
  },
];

export const mockOrders: Order[] = [
  {
    id: '1',
    craftsmanName: 'أحمد الزهراني',
    craftsmanImage: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400',
    service: 'إصلاح كهربائي',
    status: 'in_progress',
    date: '2024-01-25 10:00',
    price: '150 ريال',
    address: 'حي النرجس، الرياض',
    description: 'إصلاح لوحة كهربائية رئيسية',
  },
  {
    id: '2',
    craftsmanName: 'علي المطيري',
    craftsmanImage: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=400',
    service: 'صيانة مكيف',
    status: 'completed',
    date: '2024-01-20 14:00',
    price: '120 ريال',
    address: 'حي الياسمين، الرياض',
    description: 'تنظيف وشحن غاز مكيف سبليت 2.5 طن',
  },
  {
    id: '3',
    craftsmanName: 'خالد العسيري',
    craftsmanImage: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400',
    service: 'إصلاح تسريب',
    status: 'completed',
    date: '2024-01-15 09:00',
    price: '90 ريال',
    address: 'حي العليا، الرياض',
    description: 'إصلاح تسريب في الحمام',
  },
  {
    id: '4',
    craftsmanName: 'يوسف القحطاني',
    craftsmanImage: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400',
    service: 'دهان غرفة',
    status: 'pending',
    date: '2024-01-28 11:00',
    price: '200 ريال',
    address: 'حي الملقا، الرياض',
    description: 'دهان غرفة نوم بلونين',
  },
  {
    id: '5',
    craftsmanName: 'عمر البلوي',
    craftsmanImage: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400',
    service: 'تركيب أثاث',
    status: 'cancelled',
    date: '2024-01-12 16:00',
    price: '180 ريال',
    address: 'حي الروضة، الرياض',
    description: 'تركيب خزانة ملابس',
  },
];

export const chatMessages = [
  { id: '1', text: 'السلام عليكم، متى يمكنك الحضور؟', sender: 'user', time: '10:15' },
  { id: '2', text: 'وعليكم السلام، يمكنني الحضور بعد ساعتين إن شاء الله', sender: 'craftsman', time: '10:18' },
  { id: '3', text: 'ممتاز، العنوان: حي النرجس شارع الأمير محمد', sender: 'user', time: '10:20' },
  { id: '4', text: 'تمام، سأكون عندك الساعة 12:30', sender: 'craftsman', time: '10:22' },
  { id: '5', text: 'شكراً، في انتظارك', sender: 'user', time: '10:23' },
];
