import MapView, { Marker, PROVIDER_DEFAULT } from 'react-native-maps';
export type { Region } from 'react-native-maps';

export { Marker, PROVIDER_DEFAULT };
export const MapViewComponent = MapView;
