import React, { useEffect, useRef } from 'react';
import {
  View, Text, StyleSheet, Animated, Pressable, Platform,
} from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Colors, FontSize, FontWeight, Radius, Shadow, Spacing } from '@/constants/theme';

export interface InAppNotif {
  id: string;
  title: string;
  body: string;
  type?: 'order' | 'info' | 'success' | 'warning';
  icon?: string;
}

interface Props {
  notification: InAppNotif | null;
  onDismiss: () => void;
  onPress?: () => void;
}

const TYPE_CONFIG = {
  order:   { color: Colors.info,    bg: 'rgba(52,152,219,0.12)',  border: 'rgba(52,152,219,0.4)', icon: 'engineering' },
  success: { color: Colors.success, bg: 'rgba(46,204,113,0.12)', border: 'rgba(46,204,113,0.4)', icon: 'check-circle' },
  warning: { color: Colors.warning, bg: 'rgba(243,156,18,0.12)',  border: 'rgba(243,156,18,0.4)', icon: 'notifications' },
  info:    { color: Colors.gold,    bg: 'rgba(212,160,23,0.1)',   border: 'rgba(212,160,23,0.35)', icon: 'notifications' },
};

export default function InAppNotificationBanner({ notification, onDismiss, onPress }: Props) {
  const insets = useSafeAreaInsets();
  const translateY = useRef(new Animated.Value(-140)).current;
  const opacity    = useRef(new Animated.Value(0)).current;
  const scale      = useRef(new Animated.Value(0.95)).current;
  const timerRef   = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (!notification) return;

    // Clear any previous auto-dismiss timer
    if (timerRef.current) clearTimeout(timerRef.current);

    // Slide in
    Animated.parallel([
      Animated.spring(translateY, { toValue: 0, useNativeDriver: true, damping: 18, stiffness: 200 }),
      Animated.timing(opacity,    { toValue: 1, duration: 220, useNativeDriver: true }),
      Animated.spring(scale,      { toValue: 1, useNativeDriver: true, damping: 18, stiffness: 200 }),
    ]).start();

    // Auto-dismiss after 5 s
    timerRef.current = setTimeout(() => dismiss(), 5000);

    return () => { if (timerRef.current) clearTimeout(timerRef.current); };
  }, [notification]);

  const dismiss = () => {
    Animated.parallel([
      Animated.timing(translateY, { toValue: -140, duration: 300, useNativeDriver: true }),
      Animated.timing(opacity,    { toValue: 0,    duration: 300, useNativeDriver: true }),
      Animated.timing(scale,      { toValue: 0.95, duration: 300, useNativeDriver: true }),
    ]).start(() => onDismiss());
  };

  if (!notification) return null;

  const cfg = TYPE_CONFIG[notification.type ?? 'info'];
  const iconName = (notification.icon ?? cfg.icon) as any;

  return (
    <Animated.View
      style={[
        styles.wrapper,
        {
          top: insets.top + (Platform.OS === 'android' ? 8 : 6),
          transform: [{ translateY }, { scale }],
          opacity,
        },
      ]}
    >
      <Pressable
        onPress={() => { dismiss(); onPress?.(); }}
        style={({ pressed }) => [styles.card, { borderColor: cfg.border, backgroundColor: Colors.surface }, pressed && { opacity: 0.93 }]}
      >
        {/* Gold accent line on the right (RTL) */}
        <View style={[styles.accentBar, { backgroundColor: cfg.color }]} />

        <View style={styles.content}>
          {/* Icon */}
          <View style={[styles.iconCircle, { backgroundColor: cfg.bg }]}>
            <MaterialIcons name={iconName} size={22} color={cfg.color} />
          </View>

          {/* Text */}
          <View style={styles.textCol}>
            <Text style={styles.title} numberOfLines={1}>{notification.title}</Text>
            <Text style={styles.body} numberOfLines={2}>{notification.body}</Text>
          </View>

          {/* Close */}
          <Pressable style={styles.closeBtn} onPress={dismiss} hitSlop={10}>
            <MaterialIcons name="close" size={16} color={Colors.textMuted} />
          </Pressable>
        </View>

        {/* Progress bar (shrinks over 5 s) */}
        <ProgressBar color={cfg.color} duration={5000} key={notification.id} />
      </Pressable>
    </Animated.View>
  );
}

// ── Inner progress bar ────────────────────────────────────────────────────────
function ProgressBar({ color, duration }: { color: string; duration: number }) {
  const width = useRef(new Animated.Value(100)).current;

  useEffect(() => {
    Animated.timing(width, {
      toValue: 0,
      duration,
      useNativeDriver: false,
    }).start();
  }, []);

  return (
    <View style={styles.progressTrack}>
      <Animated.View
        style={[
          styles.progressFill,
          { backgroundColor: color, width: width.interpolate({ inputRange: [0, 100], outputRange: ['0%', '100%'] }) },
        ]}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    position: 'absolute',
    left: Spacing.md,
    right: Spacing.md,
    zIndex: 9999,
    elevation: 30,
  },
  card: {
    borderRadius: Radius.xl,
    borderWidth: 1,
    overflow: 'hidden',
    ...Shadow.md,
  },
  accentBar: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    right: 0,
    width: 4,
    borderTopRightRadius: Radius.xl,
    borderBottomRightRadius: Radius.xl,
  },
  content: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.md,
    paddingVertical: 13,
    paddingRight: Spacing.lg,
    gap: Spacing.sm,
  },
  iconCircle: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: 'center',
    justifyContent: 'center',
    flexShrink: 0,
  },
  textCol: {
    flex: 1,
    alignItems: 'flex-end',
    gap: 3,
  },
  title: {
    fontSize: FontSize.base,
    fontWeight: FontWeight.bold,
    color: Colors.text,
    textAlign: 'right',
  },
  body: {
    fontSize: FontSize.sm,
    color: Colors.textMuted,
    textAlign: 'right',
    lineHeight: 20,
  },
  closeBtn: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: Colors.surface2,
    alignItems: 'center',
    justifyContent: 'center',
    flexShrink: 0,
  },
  progressTrack: {
    height: 3,
    backgroundColor: Colors.divider,
    width: '100%',
  },
  progressFill: {
    height: '100%',
    borderRadius: 2,
  },
});
