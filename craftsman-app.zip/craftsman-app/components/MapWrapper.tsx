// Platform-specific map wrapper
// Metro automatically resolves MapWrapper.native.tsx on native and MapWrapper.web.tsx on web
// This file provides TypeScript types for non-platform-specific imports

export { MapViewComponent, Marker, PROVIDER_DEFAULT } from './MapWrapper.web';
export type { Region } from './MapWrapper.web';
