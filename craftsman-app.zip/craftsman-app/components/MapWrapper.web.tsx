import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { Colors, FontSize, Radius, Spacing } from '@/constants/theme';

export type Region = {
  latitude: number;
  longitude: number;
  latitudeDelta: number;
  longitudeDelta: number;
};

export const PROVIDER_DEFAULT = null;

interface MapViewProps {
  style?: any;
  initialRegion?: Region;
  region?: Region;
  onRegionChangeComplete?: (region: Region) => void;
  onPress?: (event: any) => void;
  showsUserLocation?: boolean;
  showsMyLocationButton?: boolean;
  scrollEnabled?: boolean;
  zoomEnabled?: boolean;
  pitchEnabled?: boolean;
  rotateEnabled?: boolean;
  provider?: any;
  children?: React.ReactNode;
  ref?: any;
}

export const MapViewComponent = React.forwardRef<any, MapViewProps>(
  ({ style, children, onPress, region }, ref) => {
    return (
      <View style={[styles.container, style]}>
        <View style={styles.placeholder}>
          <MaterialIcons name="map" size={48} color={Colors.textMuted} />
          <Text style={styles.title}>الخريطة التفاعلية</Text>
          <Text style={styles.subtitle}>متاحة على تطبيق الجوال</Text>
          {region ? (
            <View style={styles.coordBadge}>
              <MaterialIcons name="location-on" size={14} color={Colors.gold} />
              <Text style={styles.coordText}>
                {region.latitude.toFixed(4)}, {region.longitude.toFixed(4)}
              </Text>
            </View>
          ) : null}
        </View>
        {children}
      </View>
    );
  }
);

MapViewComponent.displayName = 'MapViewComponent';

export const Marker = ({ coordinate, title }: { coordinate?: any; title?: string }) => null;

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#0a1628',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: Radius.xl,
    overflow: 'hidden',
  },
  placeholder: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    gap: Spacing.sm,
    padding: Spacing.xl,
  },
  title: {
    fontSize: FontSize.base,
    color: Colors.textMuted,
    fontWeight: '600',
  },
  subtitle: {
    fontSize: FontSize.xs,
    color: Colors.textMuted,
  },
  coordBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: Colors.goldSoft,
    borderRadius: Radius.full,
    paddingHorizontal: 10,
    paddingVertical: 4,
    marginTop: 4,
  },
  coordText: {
    fontSize: FontSize.xs,
    color: Colors.gold,
  },
});
