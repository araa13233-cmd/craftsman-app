import React, { useState } from 'react';
import {
  View, Text, StyleSheet, Pressable, TextInput,
  ScrollView, KeyboardAvoidingView, Platform, ActivityIndicator,
} from 'react-native';
import { useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';
import { Colors, FontSize, FontWeight, Radius, Spacing, Shadow } from '@/constants/theme';
import { useAuth, useAlert } from '@/template';

export default function LoginScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { signInWithPassword, sendOTP, verifyOTPAndLogin, operationLoading } = useAuth();
  const { showAlert } = useAlert();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [step, setStep] = useState<'login' | 'otp'>('login');
  const [otp, setOtp] = useState('');

  const handleLogin = async () => {
    if (!email || !password) {
      showAlert('تنبيه', 'يرجى إدخال البريد الإلكتروني وكلمة المرور');
      return;
    }
    const { error } = await signInWithPassword(email, password);
    if (error) {
      showAlert('خطأ', error);
      return;
    }
    router.replace('/(tabs)');
  };

  const handleSendOTP = async () => {
    if (!email) {
      showAlert('تنبيه', 'يرجى إدخال البريد الإلكتروني');
      return;
    }
    const { error } = await sendOTP(email);
    if (error) { showAlert('خطأ', error); return; }
    setStep('otp');
    showAlert('تم الإرسال', 'تم إرسال رمز التحقق إلى بريدك الإلكتروني');
  };

  const handleVerifyOTP = async () => {
    if (!otp) { showAlert('تنبيه', 'يرجى إدخال رمز التحقق'); return; }
    const { error } = await verifyOTPAndLogin(email, otp);
    if (error) { showAlert('خطأ', error); return; }
    router.replace('/(tabs)');
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <View style={[styles.container, { paddingTop: insets.top }]}>
        <StatusBar style="light" />
        <View style={styles.bgCircle1} />
        <View style={styles.bgCircle2} />

        <ScrollView
          contentContainerStyle={[styles.scroll, { paddingBottom: insets.bottom + 32 }]}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          <View style={styles.header}>
            <Pressable style={styles.backBtn} onPress={() => router.back()}>
              <MaterialIcons name="arrow-forward" size={24} color={Colors.text} />
            </Pressable>
          </View>

          <View style={styles.logoArea}>
            <View style={styles.logoCircle}>
              <MaterialIcons name="home-repair-service" size={40} color={Colors.gold} />
            </View>
            <Text style={styles.appName}>معلم</Text>
            <Text style={styles.welcomeText}>
              {step === 'otp' ? 'أدخل رمز التحقق' : 'مرحباً بك مجدداً'}
            </Text>
            <Text style={styles.subText}>
              {step === 'otp'
                ? `تم إرسال الرمز إلى ${email}`
                : 'سجّل دخولك للوصول إلى الحرفيين'}
            </Text>
          </View>

          {step === 'login' ? (
            <View style={styles.form}>
              {/* Email */}
              <View style={styles.inputGroup}>
                <Text style={styles.label}>البريد الإلكتروني</Text>
                <View style={styles.inputWrapper}>
                  <TextInput
                    style={styles.input}
                    value={email}
                    onChangeText={setEmail}
                    placeholder="example@email.com"
                    placeholderTextColor={Colors.textMuted}
                    keyboardType="email-address"
                    autoCapitalize="none"
                    textAlign="right"
                  />
                  <MaterialIcons name="email" size={20} color={Colors.textMuted} />
                </View>
              </View>

              {/* Password */}
              <View style={styles.inputGroup}>
                <Text style={styles.label}>كلمة المرور</Text>
                <View style={styles.inputWrapper}>
                  <TextInput
                    style={styles.input}
                    value={password}
                    onChangeText={setPassword}
                    placeholder="••••••••"
                    placeholderTextColor={Colors.textMuted}
                    secureTextEntry={!showPass}
                    textAlign="right"
                  />
                  <Pressable onPress={() => setShowPass(!showPass)}>
                    <MaterialIcons
                      name={showPass ? 'visibility-off' : 'visibility'}
                      size={20}
                      color={Colors.textMuted}
                    />
                  </Pressable>
                </View>
              </View>

              <Pressable style={styles.forgotBtn} onPress={handleSendOTP}>
                <Text style={styles.forgotText}>الدخول برمز OTP بدلاً من كلمة المرور</Text>
              </Pressable>

              <Pressable
                style={[styles.loginBtn, operationLoading && styles.disabledBtn]}
                onPress={handleLogin}
                disabled={operationLoading}
              >
                {operationLoading ? (
                  <ActivityIndicator color={Colors.primary} />
                ) : (
                  <Text style={styles.loginBtnText}>تسجيل الدخول</Text>
                )}
              </Pressable>

              <View style={styles.dividerRow}>
                <View style={styles.dividerLine} />
                <Text style={styles.dividerText}>أو</Text>
                <View style={styles.dividerLine} />
              </View>

              <Pressable style={styles.otpBtn} onPress={handleSendOTP} disabled={operationLoading}>
                {operationLoading ? (
                  <ActivityIndicator color={Colors.gold} />
                ) : (
                  <>
                    <MaterialIcons name="mail" size={20} color={Colors.gold} />
                    <Text style={styles.otpBtnText}>الدخول بكود البريد الإلكتروني</Text>
                  </>
                )}
              </Pressable>
            </View>
          ) : (
            <View style={styles.form}>
              <View style={styles.otpInfo}>
                <MaterialIcons name="mark-email-read" size={32} color={Colors.gold} />
                <Text style={styles.otpInfoText}>أدخل الرمز المكون من 4 أرقام المرسل إلى بريدك</Text>
              </View>
              <View style={styles.inputGroup}>
                <Text style={styles.label}>رمز التحقق</Text>
                <View style={[styles.inputWrapper, { justifyContent: 'center' }]}>
                  <TextInput
                    style={[styles.input, styles.otpInput]}
                    value={otp}
                    onChangeText={setOtp}
                    placeholder="- - - -"
                    placeholderTextColor={Colors.textMuted}
                    keyboardType="number-pad"
                    maxLength={4}
                    textAlign="center"
                  />
                </View>
              </View>
              <Pressable
                style={[styles.loginBtn, operationLoading && styles.disabledBtn]}
                onPress={handleVerifyOTP}
                disabled={operationLoading}
              >
                {operationLoading ? (
                  <ActivityIndicator color={Colors.primary} />
                ) : (
                  <Text style={styles.loginBtnText}>تأكيد الرمز</Text>
                )}
              </Pressable>
              <Pressable style={styles.forgotBtn} onPress={() => setStep('login')}>
                <Text style={styles.forgotText}>العودة لتسجيل الدخول</Text>
              </Pressable>
            </View>
          )}

          <View style={styles.registerRow}>
            <Pressable onPress={() => router.push('/auth/register')}>
              <Text style={styles.registerLink}>إنشاء حساب جديد</Text>
            </Pressable>
            <Text style={styles.registerText}>ليس لديك حساب؟ </Text>
          </View>
        </ScrollView>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  bgCircle1: {
    position: 'absolute', width: 280, height: 280, borderRadius: 140,
    backgroundColor: 'rgba(212,160,23,0.05)', top: -60, left: -80,
  },
  bgCircle2: {
    position: 'absolute', width: 200, height: 200, borderRadius: 100,
    backgroundColor: 'rgba(13,27,62,0.5)', bottom: 50, right: -50,
  },
  scroll: { paddingHorizontal: Spacing.lg },
  header: { paddingTop: Spacing.md, marginBottom: Spacing.sm },
  backBtn: {
    width: 44, height: 44, borderRadius: Radius.md,
    backgroundColor: Colors.surface, alignItems: 'center', justifyContent: 'center',
    alignSelf: 'flex-end',
  },
  logoArea: { alignItems: 'center', marginBottom: Spacing.xl },
  logoCircle: {
    width: 80, height: 80, borderRadius: 40,
    backgroundColor: 'rgba(212,160,23,0.12)',
    borderWidth: 1.5, borderColor: 'rgba(212,160,23,0.4)',
    alignItems: 'center', justifyContent: 'center', marginBottom: Spacing.md,
  },
  appName: { fontSize: 32, fontWeight: FontWeight.extrabold, color: Colors.gold, marginBottom: 6 },
  welcomeText: { fontSize: FontSize.xl, fontWeight: FontWeight.bold, color: Colors.text, marginBottom: 6 },
  subText: { fontSize: FontSize.sm, color: Colors.textMuted, textAlign: 'center' },
  form: { gap: Spacing.md },
  inputGroup: { gap: Spacing.sm },
  label: { fontSize: FontSize.sm, color: Colors.textMuted, fontWeight: FontWeight.medium, textAlign: 'right' },
  inputWrapper: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: Colors.surface, borderRadius: Radius.md,
    borderWidth: 1, borderColor: Colors.border,
    paddingHorizontal: Spacing.md, paddingVertical: 14, gap: Spacing.sm,
  },
  input: { flex: 1, color: Colors.text, fontSize: FontSize.base },
  otpInput: {
    fontSize: FontSize.xxl, fontWeight: FontWeight.bold, letterSpacing: 8,
    textAlign: 'center',
  },
  otpInfo: {
    alignItems: 'center', gap: Spacing.sm, backgroundColor: Colors.goldSoft,
    borderRadius: Radius.lg, padding: Spacing.md,
  },
  otpInfoText: { fontSize: FontSize.sm, color: Colors.text, textAlign: 'center', lineHeight: 22 },
  forgotBtn: { alignSelf: 'flex-start' },
  forgotText: { color: Colors.gold, fontSize: FontSize.sm, fontWeight: FontWeight.medium },
  loginBtn: {
    backgroundColor: Colors.gold, borderRadius: Radius.lg,
    paddingVertical: 16, alignItems: 'center', marginTop: Spacing.sm, ...Shadow.gold,
  },
  disabledBtn: { opacity: 0.7 },
  loginBtnText: { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: Colors.primary },
  dividerRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md, marginVertical: Spacing.xs },
  dividerLine: { flex: 1, height: 1, backgroundColor: Colors.divider },
  dividerText: { color: Colors.textMuted, fontSize: FontSize.sm },
  otpBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: Spacing.sm,
    backgroundColor: Colors.surface, borderRadius: Radius.md,
    paddingVertical: 13, borderWidth: 1, borderColor: Colors.glassBorder,
  },
  otpBtnText: { color: Colors.gold, fontSize: FontSize.sm, fontWeight: FontWeight.medium },
  registerRow: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', marginTop: Spacing.xl },
  registerText: { color: Colors.textMuted, fontSize: FontSize.sm },
  registerLink: { color: Colors.gold, fontSize: FontSize.sm, fontWeight: FontWeight.semibold },
});
