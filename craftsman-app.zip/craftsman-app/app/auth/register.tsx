import React, { useState } from 'react';
import {
  View, Text, StyleSheet, Pressable, TextInput,
  ScrollView, KeyboardAvoidingView, Platform, ActivityIndicator,
} from 'react-native';
import { useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';
import { Colors, FontSize, FontWeight, Radius, Spacing, Shadow } from '@/constants/theme';
import { useAuth, useAlert } from '@/template';

export default function RegisterScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { sendOTP, verifyOTPAndLogin, operationLoading } = useAuth();
  const { showAlert } = useAlert();

  const [step, setStep] = useState<'form' | 'otp'>('form');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [otp, setOtp] = useState('');
  const [accountType, setAccountType] = useState<'client' | 'craftsman'>('client');

  const handleSendOTP = async () => {
    if (!name || !email || !password) {
      showAlert('تنبيه', 'يرجى تعبئة الاسم والبريد وكلمة المرور');
      return;
    }
    if (password !== confirmPassword) {
      showAlert('خطأ', 'كلمة المرور وتأكيدها غير متطابقتين');
      return;
    }
    if (password.length < 6) {
      showAlert('خطأ', 'يجب أن تكون كلمة المرور 6 أحرف على الأقل');
      return;
    }
    const { error } = await sendOTP(email);
    if (error) { showAlert('خطأ', error); return; }
    setStep('otp');
    showAlert('تم الإرسال', 'تم إرسال رمز التحقق إلى بريدك الإلكتروني');
  };

  const handleVerifyAndRegister = async () => {
    if (!otp) { showAlert('تنبيه', 'يرجى إدخال رمز التحقق'); return; }
    const { error } = await verifyOTPAndLogin(email, otp, { password });
    if (error) { showAlert('خطأ', error); return; }
    router.replace('/(tabs)');
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <View style={[styles.container, { paddingTop: insets.top }]}>
        <StatusBar style="light" />
        <View style={styles.bgCircle} />

        <ScrollView
          contentContainerStyle={[styles.scroll, { paddingBottom: insets.bottom + 32 }]}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          <View style={styles.header}>
            <Pressable style={styles.backBtn} onPress={() => step === 'otp' ? setStep('form') : router.back()}>
              <MaterialIcons name="arrow-forward" size={24} color={Colors.text} />
            </Pressable>
            <Text style={styles.headerTitle}>{step === 'otp' ? 'التحقق من البريد' : 'إنشاء حساب'}</Text>
            <View style={{ width: 44 }} />
          </View>

          {step === 'form' ? (
            <>
              {/* Account Type */}
              <Text style={styles.sectionLabel}>نوع الحساب</Text>
              <View style={styles.typeRow}>
                {[
                  { key: 'client', label: 'عميل', icon: 'person' },
                  { key: 'craftsman', label: 'حرفي', icon: 'build' },
                ].map(t => (
                  <Pressable
                    key={t.key}
                    style={[styles.typeBtn, accountType === t.key && styles.typeBtnActive]}
                    onPress={() => setAccountType(t.key as any)}
                  >
                    <MaterialIcons
                      name={t.icon as any}
                      size={22}
                      color={accountType === t.key ? Colors.primary : Colors.textMuted}
                    />
                    <Text style={[styles.typeLabel, accountType === t.key && styles.typeLabelActive]}>
                      {t.label}
                    </Text>
                  </Pressable>
                ))}
              </View>

              {/* Form */}
              <View style={styles.form}>
                {[
                  { label: 'الاسم الكامل', value: name, set: setName, icon: 'person', placeholder: 'محمد عبدالله', type: 'default', secure: false },
                  { label: 'البريد الإلكتروني', value: email, set: setEmail, icon: 'email', placeholder: 'example@email.com', type: 'email-address', secure: false },
                  { label: 'رقم الجوال', value: phone, set: setPhone, icon: 'phone', placeholder: '+966 5XX XXX XXX', type: 'phone-pad', secure: false },
                  { label: 'كلمة المرور', value: password, set: setPassword, icon: 'lock', placeholder: '••••••••', type: 'default', secure: true },
                  { label: 'تأكيد كلمة المرور', value: confirmPassword, set: setConfirmPassword, icon: 'lock', placeholder: '••••••••', type: 'default', secure: true },
                ].map((f, i) => (
                  <View key={i} style={styles.inputGroup}>
                    <Text style={styles.label}>{f.label}</Text>
                    <View style={styles.inputWrapper}>
                      <TextInput
                        style={styles.input}
                        value={f.value}
                        onChangeText={f.set}
                        placeholder={f.placeholder}
                        placeholderTextColor={Colors.textMuted}
                        keyboardType={f.type as any}
                        secureTextEntry={f.secure}
                        textAlign="right"
                        autoCapitalize="none"
                      />
                      <MaterialIcons name={f.icon as any} size={20} color={Colors.textMuted} />
                    </View>
                  </View>
                ))}

                <View style={styles.termsRow}>
                  <Pressable>
                    <Text style={styles.termsLink}>الشروط والأحكام</Text>
                  </Pressable>
                  <Text style={styles.termsText}> بالتسجيل أنت توافق على </Text>
                </View>

                <Pressable
                  style={[styles.registerBtn, operationLoading && { opacity: 0.7 }]}
                  onPress={handleSendOTP}
                  disabled={operationLoading}
                >
                  {operationLoading ? (
                    <ActivityIndicator color={Colors.primary} />
                  ) : (
                    <Text style={styles.registerBtnText}>إرسال رمز التحقق</Text>
                  )}
                </Pressable>
              </View>
            </>
          ) : (
            <View style={styles.form}>
              <View style={styles.otpInfo}>
                <MaterialIcons name="mark-email-read" size={48} color={Colors.gold} />
                <Text style={styles.otpTitle}>تحقق من بريدك الإلكتروني</Text>
                <Text style={styles.otpSubtext}>تم إرسال رمز التحقق إلى{'\n'}{email}</Text>
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.label}>رمز التحقق (4 أرقام)</Text>
                <View style={[styles.inputWrapper, { justifyContent: 'center' }]}>
                  <TextInput
                    style={[styles.input, styles.otpInput]}
                    value={otp}
                    onChangeText={setOtp}
                    placeholder="- - - -"
                    placeholderTextColor={Colors.textMuted}
                    keyboardType="number-pad"
                    maxLength={4}
                    textAlign="center"
                    autoFocus
                  />
                </View>
              </View>

              <Pressable
                style={[styles.registerBtn, operationLoading && { opacity: 0.7 }]}
                onPress={handleVerifyAndRegister}
                disabled={operationLoading}
              >
                {operationLoading ? (
                  <ActivityIndicator color={Colors.primary} />
                ) : (
                  <Text style={styles.registerBtnText}>إنشاء الحساب</Text>
                )}
              </Pressable>

              <Pressable style={styles.resendRow} onPress={handleSendOTP} disabled={operationLoading}>
                <Text style={styles.resendText}>لم تستلم الرمز؟ </Text>
                <Text style={styles.resendLink}>إعادة الإرسال</Text>
              </Pressable>
            </View>
          )}

          <View style={styles.loginRow}>
            <Pressable onPress={() => router.push('/auth/login')}>
              <Text style={styles.loginLink}>تسجيل الدخول</Text>
            </Pressable>
            <Text style={styles.loginText}>لديك حساب بالفعل؟ </Text>
          </View>
        </ScrollView>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  bgCircle: {
    position: 'absolute', width: 300, height: 300, borderRadius: 150,
    backgroundColor: 'rgba(212,160,23,0.04)', top: -80, right: -80,
  },
  scroll: { paddingHorizontal: Spacing.lg },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingVertical: Spacing.md, marginBottom: Spacing.lg,
  },
  backBtn: {
    width: 44, height: 44, borderRadius: Radius.md,
    backgroundColor: Colors.surface, alignItems: 'center', justifyContent: 'center',
  },
  headerTitle: { fontSize: FontSize.xl, fontWeight: FontWeight.bold, color: Colors.text },
  sectionLabel: { fontSize: FontSize.sm, color: Colors.textMuted, textAlign: 'right', fontWeight: FontWeight.medium, marginBottom: Spacing.sm },
  typeRow: { flexDirection: 'row', gap: Spacing.md, marginBottom: Spacing.lg },
  typeBtn: {
    flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    gap: Spacing.sm, backgroundColor: Colors.surface, borderRadius: Radius.md,
    paddingVertical: 14, borderWidth: 1.5, borderColor: Colors.border,
  },
  typeBtnActive: { backgroundColor: Colors.gold, borderColor: Colors.gold },
  typeLabel: { fontSize: FontSize.base, color: Colors.textMuted, fontWeight: FontWeight.semibold },
  typeLabelActive: { color: Colors.primary },
  form: { gap: Spacing.md },
  inputGroup: { gap: Spacing.sm },
  label: { fontSize: FontSize.sm, color: Colors.textMuted, textAlign: 'right', fontWeight: FontWeight.medium },
  inputWrapper: {
    flexDirection: 'row', alignItems: 'center', backgroundColor: Colors.surface,
    borderRadius: Radius.md, borderWidth: 1, borderColor: Colors.border,
    paddingHorizontal: Spacing.md, paddingVertical: 14, gap: Spacing.sm,
  },
  input: { flex: 1, color: Colors.text, fontSize: FontSize.base },
  otpInput: { fontSize: FontSize.xxl, fontWeight: FontWeight.bold, letterSpacing: 8, textAlign: 'center' },
  otpInfo: { alignItems: 'center', gap: Spacing.md, paddingVertical: Spacing.lg },
  otpTitle: { fontSize: FontSize.xl, fontWeight: FontWeight.bold, color: Colors.text, textAlign: 'center' },
  otpSubtext: { fontSize: FontSize.sm, color: Colors.textMuted, textAlign: 'center', lineHeight: 22 },
  termsRow: { flexDirection: 'row', justifyContent: 'flex-end', alignItems: 'center' },
  termsText: { color: Colors.textMuted, fontSize: FontSize.xs },
  termsLink: { color: Colors.gold, fontSize: FontSize.xs, fontWeight: FontWeight.medium },
  registerBtn: {
    backgroundColor: Colors.gold, borderRadius: Radius.lg, paddingVertical: 16,
    alignItems: 'center', marginTop: Spacing.sm, ...Shadow.gold,
  },
  registerBtnText: { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: Colors.primary },
  resendRow: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center' },
  resendText: { color: Colors.textMuted, fontSize: FontSize.sm },
  resendLink: { color: Colors.gold, fontSize: FontSize.sm, fontWeight: FontWeight.semibold },
  loginRow: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', marginTop: Spacing.xl },
  loginText: { color: Colors.textMuted, fontSize: FontSize.sm },
  loginLink: { color: Colors.gold, fontSize: FontSize.sm, fontWeight: FontWeight.semibold },
});
