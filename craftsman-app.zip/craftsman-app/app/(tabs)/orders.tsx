import React, { useEffect, useCallback, useState } from 'react';
import {
  View, Text, StyleSheet, FlatList, Pressable,
  ActivityIndicator, Linking, Alert,
} from 'react-native';
import { useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import { Colors, FontSize, FontWeight, Radius, Spacing, Shadow } from '@/constants/theme';
import { useApp } from '@/hooks/useApp';
import { useAuth } from '@/template';
import type { Order, OrderStatus } from '@/contexts/AppContext';

const STATUS_CONFIG: Record<OrderStatus, { color: string; label: string; bg: string; icon: string }> = {
  pending:    { color: Colors.warning, label: 'قيد الانتظار',   bg: 'rgba(243,156,18,0.12)',  icon: 'hourglass-empty' },
  assigned:   { color: Colors.gold,    label: 'تعيين تلقائي',   bg: 'rgba(212,160,23,0.12)', icon: 'auto-fix-high' },
  accepted:   { color: Colors.info,    label: 'تم القبول',      bg: 'rgba(52,152,219,0.12)',  icon: 'check-circle-outline' },
  on_the_way: { color: '#9B59B6',      label: 'الحرفي في الطريق', bg: 'rgba(155,89,182,0.12)', icon: 'directions-car' },
  in_progress:{ color: Colors.info,    label: 'جاري التنفيذ',  bg: 'rgba(52,152,219,0.12)',  icon: 'engineering' },
  completed:  { color: Colors.success, label: 'مكتمل',          bg: 'rgba(46,204,113,0.12)', icon: 'check-circle' },
  cancelled:  { color: Colors.error,   label: 'ملغي',           bg: 'rgba(231,76,60,0.12)',  icon: 'cancel' },
};

const ACTIVE_STATUSES: OrderStatus[] = ['assigned', 'accepted', 'on_the_way', 'in_progress'];

export default function OrdersScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { orders, ordersLoading, fetchOrders } = useApp();
  const { user } = useAuth();
  const [filter, setFilter] = useState<'all' | 'active' | 'completed'>('all');

  // Auto-refresh every 15 seconds for status changes
  useEffect(() => {
    fetchOrders();
    const interval = setInterval(fetchOrders, 15000);
    return () => clearInterval(interval);
  }, [fetchOrders]);

  const callCraftsman = (phone: string) => {
    if (!phone) { Alert.alert('تنبيه', 'رقم الحرفي غير متوفر'); return; }
    Linking.openURL(`tel:${phone}`);
  };

  if (!user) {
    return (
      <View style={[styles.container, { paddingTop: insets.top }]}>
        <StatusBar style="light" />
        <View style={styles.header}>
          <Text style={styles.headerTitle}>طلباتي</Text>
        </View>
        <View style={styles.emptyState}>
          <MaterialIcons name="login" size={56} color={Colors.textMuted} />
          <Text style={styles.emptyTitle}>يجب تسجيل الدخول</Text>
          <Text style={styles.emptyText}>سجّل دخولك لعرض طلباتك</Text>
          <Pressable style={styles.loginBtn} onPress={() => router.push('/auth/login')}>
            <Text style={styles.loginBtnText}>تسجيل الدخول</Text>
          </Pressable>
        </View>
      </View>
    );
  }

  const activeOrders = orders.filter(o => ACTIVE_STATUSES.includes(o.status));
  const pendingOrders = orders.filter(o => o.status === 'pending');
  const completedOrders = orders.filter(o => o.status === 'completed');
  const cancelledOrders = orders.filter(o => o.status === 'cancelled');

  const filteredOrders = (() => {
    if (filter === 'active') return [...activeOrders, ...pendingOrders];
    if (filter === 'completed') return [...completedOrders, ...cancelledOrders];
    return [...activeOrders, ...pendingOrders, ...completedOrders, ...cancelledOrders];
  })();

  const renderOrder = ({ item }: { item: Order }) => {
    const sc = STATUS_CONFIG[item.status] ?? STATUS_CONFIG.pending;
    const isActive = ACTIVE_STATUSES.includes(item.status);
    const hasPhone = !!(item as any).craftsmanPhone;

    return (
      <Pressable
        style={styles.orderCard}
        onPress={() => router.push(`/orders/${item.id}` as any)}
      >
        {({ pressed }) => (
          <View style={[
            styles.orderCardInner,
            pressed && { opacity: 0.9 },
            isActive && styles.orderCardActive,
          ]}>
            <Image
              source={{ uri: item.craftsmanImage }}
              style={styles.craftsmanImg}
              contentFit="cover"
            />
            <View style={styles.orderInfo}>
              <View style={styles.orderTop}>
                <View style={[styles.statusBadge, { backgroundColor: sc.bg }]}>
                  <MaterialIcons name={sc.icon as any} size={12} color={sc.color} />
                  <Text style={[styles.statusText, { color: sc.color }]}>{sc.label}</Text>
                </View>
                <Text style={styles.orderService} numberOfLines={1}>{item.service}</Text>
              </View>

              <Text style={styles.craftsmanName}>{item.craftsmanName}</Text>

              <View style={styles.orderMeta}>
                {item.price ? <Text style={styles.orderPrice}>{item.price}</Text> : null}
                <Text style={styles.orderDate}>{item.date}</Text>
              </View>

              {item.address ? (
                <Text style={styles.orderAddress} numberOfLines={1}>
                  📍 {item.address}
                </Text>
              ) : null}

              {/* Action buttons for active orders */}
              {isActive && (
                <View style={styles.actionRow}>
                  {/* Track on map */}
                  <Pressable
                    style={styles.trackBtn}
                    onPress={() => router.push(`/orders/${item.id}` as any)}
                  >
                    <MaterialIcons name="my-location" size={13} color={Colors.gold} />
                    <Text style={styles.trackText}>تتبع</Text>
                  </Pressable>

                  {/* Chat */}
                  <Pressable
                    style={styles.chatQuickBtn}
                    onPress={() => item.craftsmanId
                      ? router.push(`/chat/${item.craftsmanId}?orderId=${item.id}` as any)
                      : null
                    }
                  >
                    <MaterialIcons name="chat" size={13} color={Colors.info} />
                    <Text style={[styles.trackText, { color: Colors.info }]}>دردشة</Text>
                  </Pressable>

                  {/* Call */}
                  <Pressable
                    style={[styles.callQuickBtn, !hasPhone && { opacity: 0.4 }]}
                    onPress={() => callCraftsman((item as any).craftsmanPhone)}
                    disabled={!hasPhone}
                  >
                    <MaterialIcons name="phone" size={13} color={Colors.success} />
                    <Text style={[styles.trackText, { color: Colors.success }]}>اتصال</Text>
                  </Pressable>
                </View>
              )}
            </View>
          </View>
        )}
      </Pressable>
    );
  };

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <StatusBar style="light" />

      <View style={styles.header}>
        <Text style={styles.headerTitle}>طلباتي</Text>
        <Text style={styles.headerCount}>{orders.length} طلب</Text>
      </View>

      {/* Summary Stats */}
      <View style={styles.statsRow}>
        {[
          { label: 'نشط', count: activeOrders.length, color: Colors.info },
          { label: 'انتظار', count: pendingOrders.length, color: Colors.warning },
          { label: 'مكتمل', count: completedOrders.length, color: Colors.success },
          { label: 'ملغي', count: cancelledOrders.length, color: Colors.error },
        ].map((s, i) => (
          <View key={i} style={styles.statCard}>
            <Text style={[styles.statCount, { color: s.color }]}>{s.count}</Text>
            <Text style={styles.statLabel}>{s.label}</Text>
          </View>
        ))}
      </View>

      {/* Filter Tabs */}
      <View style={styles.filterRow}>
        {([
          { key: 'all', label: 'الكل' },
          { key: 'active', label: 'النشطة' },
          { key: 'completed', label: 'المكتملة' },
        ] as const).map(f => (
          <Pressable
            key={f.key}
            style={[styles.filterTab, filter === f.key && styles.filterTabActive]}
            onPress={() => setFilter(f.key)}
          >
            <Text style={[styles.filterTabText, filter === f.key && styles.filterTabTextActive]}>
              {f.label}
            </Text>
          </Pressable>
        ))}
      </View>

      {ordersLoading && filteredOrders.length === 0 ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={Colors.gold} />
          <Text style={styles.loadingText}>جاري تحميل الطلبات...</Text>
        </View>
      ) : filteredOrders.length === 0 ? (
        <View style={styles.emptyState}>
          <MaterialIcons name="list-alt" size={64} color={Colors.textMuted} />
          <Text style={styles.emptyTitle}>لا توجد طلبات</Text>
          <Text style={styles.emptyText}>ابدأ بطلب خدمة من حرفي موثوق</Text>
          <Pressable style={styles.newOrderBtn} onPress={() => router.push('/request/new' as any)}>
            <Text style={styles.newOrderBtnText}>طلب خدمة جديد</Text>
          </Pressable>
        </View>
      ) : (
        <FlatList
          data={filteredOrders}
          keyExtractor={i => i.id}
          renderItem={renderOrder}
          contentContainerStyle={{ padding: Spacing.lg, gap: Spacing.md }}
          showsVerticalScrollIndicator={false}
          onRefresh={fetchOrders}
          refreshing={ordersLoading}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: Spacing.lg, paddingVertical: Spacing.md,
    borderBottomWidth: 1, borderBottomColor: Colors.divider,
  },
  headerTitle: { fontSize: FontSize.xxl, fontWeight: FontWeight.bold, color: Colors.text },
  headerCount: {
    fontSize: FontSize.sm, color: Colors.textMuted, backgroundColor: Colors.surface,
    paddingHorizontal: 12, paddingVertical: 5, borderRadius: Radius.full,
  },
  statsRow: { flexDirection: 'row', paddingHorizontal: Spacing.lg, paddingVertical: Spacing.md, gap: Spacing.sm },
  statCard: {
    flex: 1, backgroundColor: Colors.surface, borderRadius: Radius.lg,
    paddingVertical: Spacing.sm, alignItems: 'center', gap: 3,
    borderWidth: 1, borderColor: Colors.border,
  },
  statCount: { fontSize: FontSize.xl, fontWeight: FontWeight.bold },
  statLabel: { fontSize: 10, color: Colors.textMuted },

  filterRow: {
    flexDirection: 'row', paddingHorizontal: Spacing.lg, gap: Spacing.sm,
    marginBottom: Spacing.sm,
  },
  filterTab: {
    flex: 1, paddingVertical: 9, borderRadius: Radius.full,
    backgroundColor: Colors.surface, alignItems: 'center',
    borderWidth: 1, borderColor: Colors.border,
  },
  filterTabActive: { backgroundColor: Colors.gold, borderColor: Colors.gold },
  filterTabText: { fontSize: FontSize.sm, color: Colors.textMuted, fontWeight: FontWeight.medium },
  filterTabTextActive: { color: Colors.primary, fontWeight: FontWeight.bold },

  loadingContainer: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: Spacing.md },
  loadingText: { color: Colors.textMuted, fontSize: FontSize.base },
  emptyState: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: Spacing.xl, gap: Spacing.md },
  emptyTitle: { fontSize: FontSize.xl, fontWeight: FontWeight.bold, color: Colors.text, textAlign: 'center' },
  emptyText: { fontSize: FontSize.base, color: Colors.textMuted, textAlign: 'center', lineHeight: 24 },
  newOrderBtn: { backgroundColor: Colors.gold, borderRadius: Radius.lg, paddingVertical: 13, paddingHorizontal: Spacing.xl, ...Shadow.gold },
  newOrderBtnText: { color: Colors.primary, fontWeight: FontWeight.bold, fontSize: FontSize.base },
  loginBtn: { backgroundColor: Colors.gold, borderRadius: Radius.lg, paddingVertical: 13, paddingHorizontal: Spacing.xl, ...Shadow.gold },
  loginBtnText: { color: Colors.primary, fontWeight: FontWeight.bold, fontSize: FontSize.base },

  orderCard: { borderRadius: Radius.xl, overflow: 'hidden' },
  orderCardActive: { },
  orderCardInner: {
    flexDirection: 'row', gap: Spacing.md,
    backgroundColor: Colors.surface, borderRadius: Radius.xl,
    borderWidth: 1, borderColor: Colors.border, ...Shadow.sm, padding: Spacing.md,
  },
  craftsmanImg: { width: 68, height: 68, borderRadius: Radius.md },
  orderInfo: { flex: 1, gap: 5 },
  orderTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-end', gap: Spacing.sm },
  orderService: { fontSize: FontSize.base, fontWeight: FontWeight.bold, color: Colors.text, textAlign: 'right', flex: 1 },
  statusBadge: { flexDirection: 'row', alignItems: 'center', gap: 3, paddingHorizontal: 8, paddingVertical: 4, borderRadius: Radius.full },
  statusText: { fontSize: 10, fontWeight: FontWeight.bold },
  craftsmanName: { fontSize: FontSize.sm, color: Colors.gold, textAlign: 'right' },
  orderMeta: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  orderPrice: { fontSize: FontSize.base, fontWeight: FontWeight.bold, color: Colors.success },
  orderDate: { fontSize: FontSize.xs, color: Colors.textMuted },
  orderAddress: { fontSize: FontSize.xs, color: Colors.textMuted, textAlign: 'right' },

  actionRow: { flexDirection: 'row', gap: Spacing.sm, marginTop: 4 },
  trackBtn: {
    flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 4,
    backgroundColor: Colors.goldSoft, borderRadius: Radius.md, paddingVertical: 7,
    borderWidth: 1, borderColor: 'rgba(212,160,23,0.3)',
  },
  chatQuickBtn: {
    flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 4,
    backgroundColor: 'rgba(52,152,219,0.1)', borderRadius: Radius.md, paddingVertical: 7,
    borderWidth: 1, borderColor: 'rgba(52,152,219,0.3)',
  },
  callQuickBtn: {
    flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 4,
    backgroundColor: 'rgba(46,204,113,0.1)', borderRadius: Radius.md, paddingVertical: 7,
    borderWidth: 1, borderColor: 'rgba(46,204,113,0.3)',
  },
  trackText: { fontSize: 11, color: Colors.gold, fontWeight: FontWeight.semibold },
});
