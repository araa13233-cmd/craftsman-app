import React, { useEffect, useState } from 'react';
import {
  View, Text, StyleSheet, Pressable, ScrollView,
  ActivityIndicator, Linking, Alert,
} from 'react-native';
import { useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';
import { Colors, FontSize, FontWeight, Radius, Spacing, Shadow } from '@/constants/theme';
import { useApp } from '@/hooks/useApp';
import { useAuth, useAlert } from '@/template';
import type { Order, OrderStatus } from '@/contexts/AppContext';

const STATUS_CONFIG: Record<OrderStatus, { color: string; label: string; bg: string; icon: string }> = {
  pending:    { color: Colors.warning, label: 'انتظار',               bg: 'rgba(243,156,18,0.12)',  icon: 'hourglass-empty' },
  assigned:   { color: Colors.gold,    label: 'تعيين تلقائي',      bg: 'rgba(212,160,23,0.12)', icon: 'auto-fix-high' },
  accepted:   { color: Colors.info,    label: 'مقبول',              bg: 'rgba(52,152,219,0.12)',  icon: 'check-circle-outline' },
  on_the_way: { color: '#9B59B6',      label: 'في الطريق',          bg: 'rgba(155,89,182,0.12)', icon: 'directions-car' },
  in_progress:{ color: Colors.info,    label: 'جاري',               bg: 'rgba(52,152,219,0.12)',  icon: 'engineering' },
  completed:  { color: Colors.success, label: 'مكتمل',              bg: 'rgba(46,204,113,0.12)', icon: 'check-circle' },
  cancelled:  { color: Colors.error,   label: 'ملغي',               bg: 'rgba(231,76,60,0.12)',  icon: 'cancel' },
};

// ─── CLIENT / CUSTOMER VIEW ────────────────────────────────────────────────────
function CustomerRequestTab() {
  const router = useRouter();
  const insets = useSafeAreaInsets();

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <StatusBar style="light" />
      <View style={styles.header}>
        <Text style={styles.headerTitle}>طلب خدمة</Text>
      </View>
      <View style={styles.content}>
        <View style={styles.iconCircle}>
          <MaterialIcons name="home-repair-service" size={56} color={Colors.gold} />
        </View>
        <Text style={styles.title}>ابدأ طلب خدمة جديد</Text>
        <Text style={styles.subtitle}>صف مشكلتك وسنجد لك أفضل{'\n'}الحرفيين في منطقتك</Text>
        <Pressable style={styles.startBtn} onPress={() => router.push('/request/new' as any)}>
          {({ pressed }) => (
            <View style={[styles.startBtnInner, pressed && { opacity: 0.85 }]}>
              <Text style={styles.startBtnText}>ابدأ الطلب</Text>
              <MaterialIcons name="arrow-back" size={20} color={Colors.primary} />
            </View>
          )}
        </Pressable>
        <View style={styles.quickServices}>
          <Text style={styles.quickTitle}>الخدمات الشائعة</Text>
          <View style={styles.quickGrid}>
            {[
              { icon: 'flash-on',    label: 'كهربائي', color: '#F5C842' },
              { icon: 'water-drop',  label: 'سباك',    color: '#3498DB' },
              { icon: 'ac-unit',     label: 'مكيفات',  color: '#1ABC9C' },
              { icon: 'brush',       label: 'دهان',    color: '#E74C3C' },
            ].map((s, i) => (
              <Pressable key={i} style={styles.quickCard} onPress={() => router.push('/request/new' as any)}>
                {({ pressed }) => (
                  <View style={[styles.quickCardInner, pressed && { opacity: 0.8 }]}>
                    <View style={[styles.quickIcon, { backgroundColor: s.color + '20' }]}>
                      <MaterialIcons name={s.icon as any} size={26} color={s.color} />
                    </View>
                    <Text style={styles.quickLabel}>{s.label}</Text>
                  </View>
                )}
              </Pressable>
            ))}
          </View>
        </View>
      </View>
    </View>
  );
}

// ─── CRAFTSMAN JOBS VIEW ───────────────────────────────────────────────────────
function CraftsmanJobsTab() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { assignedJobs, fetchAssignedJobs, updateJobStatus, availableJobs, acceptJob } = useApp();
  const { showAlert } = useAlert();
  const [updatingId, setUpdatingId] = useState<string | null>(null);

  useEffect(() => {
    fetchAssignedJobs();
    const interval = setInterval(fetchAssignedJobs, 15000);
    return () => clearInterval(interval);
  }, [fetchAssignedJobs]);

  // Accept auto-assigned job (assigned → accepted)
  const handleAcceptJob = async (jobId: string) => {
    setUpdatingId(jobId);
    try {
      const success = await acceptJob(jobId);
      if (!success) {
        showAlert('خطأ', 'لم يتم قبول الطلب، يرجى المحاولة مرة أخرى');
      }
    } catch {
      showAlert('خطأ', 'حدث خطأ غير متوقع، حاول مرة أخرى');
    } finally {
      setUpdatingId(null);
    }
  };

  const handleStatusUpdate = async (jobId: string, status: OrderStatus) => {
    setUpdatingId(jobId);
    try {
      const success = await updateJobStatus(jobId, status);
      if (!success) {
        showAlert('خطأ في التحديث', 'لم يتم تحديث حالة الطلب، يرجى المحاولة مرة أخرى');
      }
    } catch {
      showAlert('خطأ', 'حدث خطأ غير متوقع');
    } finally {
      setUpdatingId(null);
    }
  };

  const callCustomer = (phone: string) => {
    if (!phone) { Alert.alert('تنبيه', 'رقم العميل غير متوفر'); return; }
    Linking.openURL(`tel:${phone}`);
  };

  const activeJobs = assignedJobs.filter(j =>
    ['assigned', 'accepted', 'on_the_way', 'in_progress'].includes(j.status)
  );
  const pendingJobs = assignedJobs.filter(j => j.status === 'pending');
  const completedJobs = assignedJobs.filter(j => j.status === 'completed');
  const allJobs = [...activeJobs, ...pendingJobs, ...completedJobs];

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <StatusBar style="light" />

      <View style={styles.header}>
        <Text style={styles.headerCount}>{assignedJobs.length} طلب</Text>
        <Text style={styles.headerTitle}>طلبات العمل</Text>
        <Pressable onPress={fetchAssignedJobs}>
          <MaterialIcons name="refresh" size={22} color={Colors.gold} />
        </Pressable>
      </View>

      {/* Summary */}
      <View style={styles.cSummaryRow}>
        {[
          { label: 'نشط',    count: activeJobs.length,    color: Colors.info },
          { label: 'انتظار', count: pendingJobs.length,   color: Colors.warning },
          { label: 'مكتمل',  count: completedJobs.length, color: Colors.success },
          { label: 'متاح',   count: availableJobs.length, color: Colors.gold },
        ].map((s, i) => (
          <View key={i} style={styles.cSummaryCard}>
            <Text style={[styles.cSummaryCount, { color: s.color }]}>{s.count}</Text>
            <Text style={styles.cSummaryLabel}>{s.label}</Text>
          </View>
        ))}
      </View>

      {allJobs.length === 0 ? (
        <View style={styles.emptyState}>
          <MaterialIcons name="engineering" size={64} color={Colors.textMuted} />
          <Text style={styles.emptyTitle}>لا توجد طلبات معيّنة</Text>
          <Text style={styles.emptyText}>اعثر على طلبات متاحة في الصفحة الرئيسية</Text>
          <Pressable style={styles.goHomeBtn} onPress={() => router.push('/(tabs)' as any)}>
            <MaterialIcons name="home" size={16} color={Colors.primary} />
            <Text style={styles.goHomeBtnText}>استعرض الطلبات المتاحة</Text>
          </Pressable>
        </View>
      ) : (
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ padding: Spacing.lg, gap: Spacing.md }}
          onScrollBeginDrag={fetchAssignedJobs}
        >
          {allJobs.map(job => {
            const sc = STATUS_CONFIG[job.status] ?? STATUS_CONFIG.pending;
            const isActive = ['assigned', 'accepted', 'on_the_way', 'in_progress'].includes(job.status);
            const isUpdating = updatingId === job.id;

            return (
              <Pressable key={job.id} onPress={() => router.push(`/orders/${job.id}` as any)}>
                {({ pressed }) => (
                  <View style={[
                    styles.assignedJobCard,
                    pressed && { opacity: 0.9 },
                    isActive && styles.assignedJobCardActive,
                  ]}>
                    {/* Status + Service */}
                    <View style={styles.assignedJobTop}>
                      <View style={[styles.statusBadge, { backgroundColor: sc.bg }]}>
                        <MaterialIcons name={sc.icon as any} size={12} color={sc.color} />
                        <Text style={[styles.statusText, { color: sc.color }]}>{sc.label}</Text>
                      </View>
                      <Text style={styles.assignedJobService} numberOfLines={1}>{job.service}</Text>
                    </View>

                    {job.description ? (
                      <Text style={styles.assignedJobDesc} numberOfLines={2}>{job.description}</Text>
                    ) : null}

                    <View style={styles.assignedJobMeta}>
                      {job.address ? (
                        <View style={styles.metaRow}>
                          <MaterialIcons name="location-on" size={12} color={Colors.textMuted} />
                          <Text style={styles.metaText} numberOfLines={1}>{job.address}</Text>
                        </View>
                      ) : null}
                      {job.price ? (
                        <Text style={styles.assignedJobPrice}>{job.price}</Text>
                      ) : null}
                    </View>

                    <Text style={styles.assignedJobDate}>{job.date}</Text>

                    {/* Status progression buttons */}
                    {(isActive || job.status === 'assigned') && (
                      <View style={styles.assignedJobActions}>
                        {/* Accept auto-assigned job */}
                        {job.status === 'assigned' && (
                          <Pressable
                            style={[styles.completeBtn, { backgroundColor: Colors.gold, flex: 3 }, isUpdating && { opacity: 0.6 }]}
                            onPress={() => handleAcceptJob(job.id)}
                            disabled={isUpdating}
                          >
                            {isUpdating ? (
                              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                                <ActivityIndicator size="small" color={Colors.primary} />
                                <Text style={styles.completeBtnText}>جاري القبول...</Text>
                              </View>
                            ) : (
                              <>
                                <MaterialIcons name="check-circle" size={16} color={Colors.primary} />
                                <Text style={styles.completeBtnText}>قبول الطلب</Text>
                              </>
                            )}
                          </Pressable>
                        )}

                        {/* Next status action */}
                        {job.status === 'accepted' && (
                          <Pressable
                            style={[styles.progressBtn, { backgroundColor: '#9B59B6' }, isUpdating && { opacity: 0.6 }]}
                            onPress={() => handleStatusUpdate(job.id, 'on_the_way')}
                            disabled={isUpdating}
                          >
                            {isUpdating ? (
                              <ActivityIndicator size="small" color={Colors.text} />
                            ) : (
                              <>
                                <MaterialIcons name="directions-car" size={14} color={Colors.text} />
                                <Text style={styles.progressBtnText}>في الطريق</Text>
                              </>
                            )}
                          </Pressable>
                        )}

                        {job.status === 'on_the_way' && (
                          <Pressable
                            style={[styles.progressBtn, { backgroundColor: Colors.info }, isUpdating && { opacity: 0.6 }]}
                            onPress={() => handleStatusUpdate(job.id, 'in_progress')}
                            disabled={isUpdating}
                          >
                            {isUpdating ? (
                              <ActivityIndicator size="small" color={Colors.text} />
                            ) : (
                              <>
                                <MaterialIcons name="engineering" size={14} color={Colors.text} />
                                <Text style={styles.progressBtnText}>بدأ التنفيذ</Text>
                              </>
                            )}
                          </Pressable>
                        )}

                        {job.status === 'in_progress' && (
                          <Pressable
                            style={[styles.completeBtn, isUpdating && { opacity: 0.6 }]}
                            onPress={() => handleStatusUpdate(job.id, 'completed')}
                            disabled={isUpdating}
                          >
                            {isUpdating ? (
                              <ActivityIndicator size="small" color={Colors.primary} />
                            ) : (
                              <>
                                <MaterialIcons name="check-circle" size={14} color={Colors.primary} />
                                <Text style={styles.completeBtnText}>إنهاء الطلب</Text>
                              </>
                            )}
                          </Pressable>
                        )}

                        {/* Chat */}
                        <Pressable
                          style={styles.chatBtn}
                          onPress={() => router.push(`/orders/${job.id}` as any)}
                        >
                          <MaterialIcons name="chat" size={14} color={Colors.gold} />
                          <Text style={styles.chatBtnText}>بطاقة الطلب</Text>
                        </Pressable>

                        {/* Call customer */}
                        <Pressable
                          style={styles.callBtn}
                          onPress={() => router.push(`/orders/${job.id}` as any)}
                        >
                          <MaterialIcons name="map" size={14} color={Colors.info} />
                          <Text style={[styles.chatBtnText, { color: Colors.info }]}>خريطة</Text>
                        </Pressable>
                      </View>
                    )}
                  </View>
                )}
              </Pressable>
            );
          })}
        </ScrollView>
      )}
    </View>
  );
}

// ─── Root ─────────────────────────────────────────────────────────────────────
export default function RequestTab() {
  const { userRole, roleLoading } = useApp();

  if (roleLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={Colors.gold} />
      </View>
    );
  }

  return userRole === 'craftsman' ? <CraftsmanJobsTab /> : <CustomerRequestTab />;
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  loadingContainer: { flex: 1, backgroundColor: Colors.background, alignItems: 'center', justifyContent: 'center' },

  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: Spacing.lg, paddingVertical: Spacing.md,
    borderBottomWidth: 1, borderBottomColor: Colors.divider,
  },
  headerTitle: { fontSize: FontSize.xxl, fontWeight: FontWeight.bold, color: Colors.text },
  headerCount: {
    fontSize: FontSize.sm, color: Colors.textMuted, backgroundColor: Colors.surface,
    paddingHorizontal: 12, paddingVertical: 5, borderRadius: Radius.full,
  },

  // Customer
  content: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: Spacing.xl, gap: Spacing.lg },
  iconCircle: { width: 110, height: 110, borderRadius: 55, backgroundColor: 'rgba(212,160,23,0.1)', borderWidth: 2, borderColor: 'rgba(212,160,23,0.3)', alignItems: 'center', justifyContent: 'center' },
  title: { fontSize: FontSize.xxl, fontWeight: FontWeight.bold, color: Colors.text, textAlign: 'center' },
  subtitle: { fontSize: FontSize.base, color: Colors.textMuted, textAlign: 'center', lineHeight: 26 },
  startBtn: { width: '100%', borderRadius: Radius.lg, overflow: 'hidden' },
  startBtnInner: { backgroundColor: Colors.gold, borderRadius: Radius.lg, paddingVertical: 16, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: Spacing.sm, ...Shadow.gold },
  startBtnText: { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: Colors.primary },
  quickServices: { width: '100%', gap: Spacing.md },
  quickTitle: { fontSize: FontSize.base, fontWeight: FontWeight.semibold, color: Colors.text, textAlign: 'right' },
  quickGrid: { flexDirection: 'row', gap: Spacing.sm },
  quickCard: { flex: 1 },
  quickCardInner: { backgroundColor: Colors.surface, borderRadius: Radius.lg, paddingVertical: Spacing.md, alignItems: 'center', gap: Spacing.sm, borderWidth: 1, borderColor: Colors.border },
  quickIcon: { width: 50, height: 50, borderRadius: Radius.md, alignItems: 'center', justifyContent: 'center' },
  quickLabel: { fontSize: FontSize.xs, color: Colors.text, fontWeight: FontWeight.medium },

  // Craftsman
  cSummaryRow: { flexDirection: 'row', paddingHorizontal: Spacing.lg, paddingVertical: Spacing.md, gap: Spacing.sm },
  cSummaryCard: { flex: 1, backgroundColor: Colors.surface, borderRadius: Radius.lg, paddingVertical: Spacing.sm, alignItems: 'center', gap: 3, borderWidth: 1, borderColor: Colors.border },
  cSummaryCount: { fontSize: FontSize.xl, fontWeight: FontWeight.bold },
  cSummaryLabel: { fontSize: 10, color: Colors.textMuted },

  emptyState: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: Spacing.xl, gap: Spacing.md },
  emptyTitle: { fontSize: FontSize.xl, fontWeight: FontWeight.bold, color: Colors.text, textAlign: 'center' },
  emptyText: { fontSize: FontSize.base, color: Colors.textMuted, textAlign: 'center', lineHeight: 24 },
  goHomeBtn: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, backgroundColor: Colors.gold, borderRadius: Radius.lg, paddingVertical: 13, paddingHorizontal: Spacing.xl, ...Shadow.gold },
  goHomeBtnText: { color: Colors.primary, fontWeight: FontWeight.bold, fontSize: FontSize.base },

  assignedJobCard: {
    backgroundColor: Colors.surface, borderRadius: Radius.xl, padding: Spacing.md,
    borderWidth: 1, borderColor: Colors.border, gap: Spacing.sm, ...Shadow.sm,
  },
  assignedJobCardActive: { borderColor: Colors.gold },
  assignedJobTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-end', gap: Spacing.sm },
  assignedJobService: { fontSize: FontSize.base, fontWeight: FontWeight.bold, color: Colors.text, flex: 1, textAlign: 'right' },
  statusBadge: { flexDirection: 'row', alignItems: 'center', gap: 3, paddingHorizontal: 8, paddingVertical: 4, borderRadius: Radius.full },
  statusText: { fontSize: 10, fontWeight: FontWeight.bold },
  assignedJobDesc: { fontSize: FontSize.sm, color: Colors.textMuted, textAlign: 'right', lineHeight: 20 },
  assignedJobMeta: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  metaRow: { flexDirection: 'row', alignItems: 'center', gap: 3, flex: 1 },
  metaText: { fontSize: FontSize.xs, color: Colors.textMuted, flex: 1, textAlign: 'right' },
  assignedJobPrice: { fontSize: FontSize.sm, color: Colors.success, fontWeight: FontWeight.semibold },
  assignedJobDate: { fontSize: FontSize.xs, color: Colors.textMuted, textAlign: 'right' },

  assignedJobActions: { flexDirection: 'row', gap: Spacing.sm, marginTop: 4, flexWrap: 'wrap' },
  progressBtn: { flex: 2, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 5, borderRadius: Radius.md, paddingVertical: 10 },
  progressBtnText: { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: Colors.text },
  completeBtn: { flex: 2, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 5, backgroundColor: Colors.gold, borderRadius: Radius.md, paddingVertical: 10, ...Shadow.gold },
  completeBtnText: { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: Colors.primary },
  chatBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 5, backgroundColor: Colors.goldSoft, borderRadius: Radius.md, paddingVertical: 10, borderWidth: 1, borderColor: 'rgba(212,160,23,0.3)' },
  chatBtnText: { fontSize: FontSize.sm, fontWeight: FontWeight.semibold, color: Colors.gold },
  callBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 5, backgroundColor: 'rgba(52,152,219,0.1)', borderRadius: Radius.md, paddingVertical: 10, borderWidth: 1, borderColor: 'rgba(52,152,219,0.25)' },
});
