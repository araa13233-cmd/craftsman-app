/**
 * Chats Tab - re-uses the full ChatsScreen
 */
import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, StyleSheet, FlatList, Pressable,
  ActivityIndicator, RefreshControl,
} from 'react-native';
import { useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import { getSupabaseClient, useAuth } from '@/template';
import { Colors, FontSize, FontWeight, Radius, Spacing, Shadow } from '@/constants/theme';

interface ConversationItem {
  craftsmanId: string;
  craftsmanName: string;
  craftsmanImage: string;
  craftsmanSpecialty: string;
  lastMessage: string;
  lastMessageTime: string;
  lastMessageTimestamp: string;
  unreadCount: number;
  isLastMine: boolean;
}

function formatTime(iso: string): string {
  const date = new Date(iso);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMs / 3600000);
  const diffDays = Math.floor(diffMs / 86400000);
  if (diffMins < 1) return 'الآن';
  if (diffMins < 60) return `منذ ${diffMins} د`;
  if (diffHours < 24) return `منذ ${diffHours} س`;
  if (diffDays < 7) return `منذ ${diffDays} ي`;
  return date.toLocaleDateString('ar-SA', { day: 'numeric', month: 'short' });
}

function truncate(text: string, max = 50): string {
  return text.length > max ? text.slice(0, max) + '...' : text;
}

export default function ChatsTab() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const supabase = getSupabaseClient();

  const [conversations, setConversations] = useState<ConversationItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [totalUnread, setTotalUnread] = useState(0);

  const fetchConversations = useCallback(async () => {
    if (!user) { setLoading(false); return; }
    try {
      const { data: messages, error } = await supabase
        .from('messages')
        .select('id, sender_id, receiver_id, craftsman_id, content, message_type, is_read, created_at')
        .or(`sender_id.eq.${user.id},receiver_id.eq.${user.id}`)
        .order('created_at', { ascending: false });

      if (error || !messages) return;

      const grouped: Record<string, typeof messages> = {};
      for (const msg of messages) {
        const key = msg.craftsman_id ?? 'unknown';
        if (!grouped[key]) grouped[key] = [];
        grouped[key].push(msg);
      }

      const craftsmanIds = Object.keys(grouped).filter(k => k !== 'unknown');
      if (craftsmanIds.length === 0) {
        setConversations([]);
        setTotalUnread(0);
        return;
      }

      const { data: craftsmen } = await supabase
        .from('craftsmen')
        .select('id, name, image_url, specialty')
        .in('id', craftsmanIds);

      const craftsmanMap: Record<string, { name: string; image: string; specialty: string }> = {};
      (craftsmen ?? []).forEach((c: any) => {
        craftsmanMap[c.id] = {
          name: c.name,
          image: c.image_url ?? 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400',
          specialty: c.specialty ?? '',
        };
      });

      let unreadTotal = 0;
      const convList: ConversationItem[] = craftsmanIds.map(craftsmanId => {
        const msgs = grouped[craftsmanId] ?? [];
        const latest = msgs[0];
        const unread = msgs.filter(m => !m.is_read && m.receiver_id === user.id).length;
        unreadTotal += unread;
        const info = craftsmanMap[craftsmanId];
        const lastMsgText = latest?.message_type === 'image' ? '📷 صورة' : (latest?.content ?? '');
        return {
          craftsmanId,
          craftsmanName: info?.name ?? 'حرفي',
          craftsmanImage: info?.image ?? 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400',
          craftsmanSpecialty: info?.specialty ?? '',
          lastMessage: truncate(lastMsgText),
          lastMessageTime: latest?.created_at ? formatTime(latest.created_at) : '',
          lastMessageTimestamp: latest?.created_at ?? '',
          unreadCount: unread,
          isLastMine: latest?.sender_id === user.id,
        };
      });

      convList.sort((a, b) =>
        new Date(b.lastMessageTimestamp).getTime() - new Date(a.lastMessageTimestamp).getTime()
      );

      setConversations(convList);
      setTotalUnread(unreadTotal);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [user]);

  useEffect(() => {
    fetchConversations();
    const interval = setInterval(fetchConversations, 10_000);
    return () => clearInterval(interval);
  }, [fetchConversations]);

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    fetchConversations();
  }, [fetchConversations]);

  if (!user) {
    return (
      <View style={[styles.container, { paddingTop: insets.top }]}>
        <StatusBar style="light" />
        <View style={styles.header}>
          <View style={styles.headerRight} />
          <Text style={styles.headerTitle}>المحادثات</Text>
          <View style={{ width: 40 }} />
        </View>
        <View style={styles.centerState}>
          <MaterialIcons name="login" size={56} color={Colors.textMuted} />
          <Text style={styles.emptyTitle}>يجب تسجيل الدخول</Text>
          <Text style={styles.emptyText}>سجّل دخولك لعرض محادثاتك</Text>
          <Pressable style={styles.actionBtn} onPress={() => router.push('/auth/login' as any)}>
            <Text style={styles.actionBtnText}>تسجيل الدخول</Text>
          </Pressable>
        </View>
      </View>
    );
  }

  if (loading) {
    return (
      <View style={[styles.container, { paddingTop: insets.top }]}>
        <StatusBar style="light" />
        <View style={styles.header}>
          <View style={styles.headerRight} />
          <Text style={styles.headerTitle}>المحادثات</Text>
          <View style={{ width: 40 }} />
        </View>
        <View style={styles.centerState}>
          <ActivityIndicator size="large" color={Colors.gold} />
          <Text style={styles.loadingText}>جاري تحميل المحادثات...</Text>
        </View>
      </View>
    );
  }

  const renderItem = ({ item }: { item: ConversationItem }) => (
    <Pressable
      onPress={() => router.push(`/chat/${item.craftsmanId}` as any)}
      style={({ pressed }) => [styles.convRow, pressed && { opacity: 0.88 }]}
    >
      <View style={styles.avatarContainer}>
        <Image source={{ uri: item.craftsmanImage }} style={styles.avatar} contentFit="cover" transition={200} />
        <View style={styles.onlineDot} />
      </View>

      <View style={styles.convContent}>
        <View style={styles.convTop}>
          <Text style={[styles.convTime, item.unreadCount > 0 && styles.convTimeUnread]}>
            {item.lastMessageTime}
          </Text>
          <Text style={[styles.convName, item.unreadCount > 0 && styles.convNameUnread]}>
            {item.craftsmanName}
          </Text>
        </View>

        <View style={styles.convBottom}>
          {item.unreadCount > 0 ? (
            <View style={styles.unreadBadge}>
              <Text style={styles.unreadBadgeText}>{item.unreadCount > 99 ? '99+' : item.unreadCount}</Text>
            </View>
          ) : item.isLastMine ? (
            <MaterialIcons name="done-all" size={16} color={Colors.info} />
          ) : null}
          <View style={styles.convMsgRow}>
            {item.isLastMine && <Text style={styles.convMsgPrefix}>أنت: </Text>}
            <Text style={[styles.convMsg, item.unreadCount > 0 && styles.convMsgUnread]} numberOfLines={1}>
              {item.lastMessage || 'لا توجد رسائل'}
            </Text>
          </View>
        </View>

        {item.craftsmanSpecialty ? (
          <Text style={styles.specialty} numberOfLines={1}>{item.craftsmanSpecialty}</Text>
        ) : null}
      </View>
    </Pressable>
  );

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <StatusBar style="light" />

      <View style={styles.header}>
        <View style={styles.headerRight}>
          {totalUnread > 0 && (
            <View style={styles.totalUnreadBadge}>
              <Text style={styles.totalUnreadText}>{totalUnread}</Text>
            </View>
          )}
        </View>
        <Text style={styles.headerTitle}>المحادثات</Text>
        <View style={{ width: 40 }} />
      </View>

      <View style={styles.searchHint}>
        <MaterialIcons name="chat" size={15} color={Colors.textMuted} />
        <Text style={styles.searchHintText}>
          {conversations.length > 0
            ? `${conversations.length} محادثة${totalUnread > 0 ? ` · ${totalUnread} غير مقروءة` : ''}`
            : 'لا توجد محادثات'}
        </Text>
      </View>

      {conversations.length === 0 ? (
        <View style={styles.centerState}>
          <View style={styles.emptyIconCircle}>
            <MaterialIcons name="chat-bubble-outline" size={48} color={Colors.textMuted} />
          </View>
          <Text style={styles.emptyTitle}>لا توجد محادثات بعد</Text>
          <Text style={styles.emptyText}>
            تواصل مع الحرفيين مباشرة من صفحاتهم أو من تفاصيل الطلب
          </Text>
          <Pressable style={styles.actionBtn} onPress={() => router.push('/craftsmen/index' as any)}>
            <MaterialIcons name="search" size={16} color={Colors.primary} />
            <Text style={styles.actionBtnText}>تصفح الحرفيين</Text>
          </Pressable>
        </View>
      ) : (
        <FlatList
          data={conversations}
          keyExtractor={item => item.craftsmanId}
          renderItem={renderItem}
          contentContainerStyle={{ paddingBottom: insets.bottom + 24 }}
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={Colors.gold} colors={[Colors.gold]} />
          }
          ItemSeparatorComponent={() => <View style={styles.separator} />}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: Spacing.md, paddingVertical: Spacing.md,
    borderBottomWidth: 1, borderBottomColor: Colors.divider,
  },
  headerTitle: { fontSize: FontSize.xl, fontWeight: FontWeight.bold, color: Colors.text },
  headerRight: { flexDirection: 'row', alignItems: 'center', minWidth: 40 },
  totalUnreadBadge: {
    backgroundColor: Colors.error, borderRadius: Radius.full,
    minWidth: 24, height: 24, paddingHorizontal: 6,
    alignItems: 'center', justifyContent: 'center',
  },
  totalUnreadText: { fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: Colors.text },
  searchHint: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    paddingHorizontal: Spacing.lg, paddingVertical: Spacing.sm,
    justifyContent: 'flex-end',
  },
  searchHintText: { fontSize: FontSize.xs, color: Colors.textMuted },
  convRow: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.md,
    paddingHorizontal: Spacing.lg, paddingVertical: Spacing.md,
    backgroundColor: Colors.background,
  },
  separator: { height: 1, backgroundColor: Colors.divider, marginHorizontal: Spacing.lg },
  avatarContainer: { position: 'relative', flexShrink: 0 },
  avatar: { width: 58, height: 58, borderRadius: 29, borderWidth: 2, borderColor: Colors.glassBorder },
  onlineDot: {
    position: 'absolute', bottom: 1, right: 1,
    width: 13, height: 13, borderRadius: 6.5,
    backgroundColor: Colors.success, borderWidth: 2, borderColor: Colors.background,
  },
  convContent: { flex: 1, gap: 4, alignItems: 'flex-end' },
  convTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', width: '100%' },
  convName: { fontSize: FontSize.base, fontWeight: FontWeight.semibold, color: Colors.text },
  convNameUnread: { fontWeight: FontWeight.bold, color: Colors.text },
  convTime: { fontSize: FontSize.xs, color: Colors.textMuted },
  convTimeUnread: { color: Colors.gold, fontWeight: FontWeight.semibold },
  convBottom: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', width: '100%' },
  convMsgRow: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-end' },
  convMsg: { fontSize: FontSize.sm, color: Colors.textMuted, textAlign: 'right', flex: 1 },
  convMsgUnread: { color: Colors.text, fontWeight: FontWeight.medium },
  convMsgPrefix: { fontSize: FontSize.sm, color: Colors.textMuted },
  unreadBadge: {
    backgroundColor: Colors.gold, borderRadius: Radius.full,
    minWidth: 22, height: 22, paddingHorizontal: 5,
    alignItems: 'center', justifyContent: 'center', flexShrink: 0, marginLeft: 6,
  },
  unreadBadgeText: { fontSize: 11, fontWeight: FontWeight.bold, color: Colors.primary },
  specialty: { fontSize: 11, color: Colors.gold, opacity: 0.8 },
  centerState: {
    flex: 1, alignItems: 'center', justifyContent: 'center',
    paddingHorizontal: Spacing.xl, gap: Spacing.md,
  },
  loadingText: { fontSize: FontSize.base, color: Colors.textMuted },
  emptyIconCircle: {
    width: 100, height: 100, borderRadius: 50,
    backgroundColor: Colors.surface, alignItems: 'center', justifyContent: 'center',
    borderWidth: 1, borderColor: Colors.border,
  },
  emptyTitle: { fontSize: FontSize.xl, fontWeight: FontWeight.bold, color: Colors.text },
  emptyText: { fontSize: FontSize.base, color: Colors.textMuted, textAlign: 'center', lineHeight: 24 },
  actionBtn: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.sm,
    backgroundColor: Colors.gold, borderRadius: Radius.lg,
    paddingVertical: 13, paddingHorizontal: Spacing.xl, ...Shadow.gold,
  },
  actionBtnText: { color: Colors.primary, fontWeight: FontWeight.bold, fontSize: FontSize.base },
});
