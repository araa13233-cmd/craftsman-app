import { MaterialIcons } from '@expo/vector-icons';
import { Tabs } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Platform, View, Text, StyleSheet } from 'react-native';
import { Colors, FontSize, FontWeight, Radius } from '@/constants/theme';
import { useApp } from '@/hooks/useApp';

export default function TabLayout() {
  const insets = useSafeAreaInsets();
  const { userRole } = useApp();
  const isCraftsman = userRole === 'craftsman';

  const tabBarStyle = {
    height: Platform.select({
      ios: insets.bottom + 65,
      android: insets.bottom + 65,
      default: 75,
    }),
    paddingTop: 10,
    paddingBottom: Platform.select({
      ios: insets.bottom + 8,
      android: insets.bottom + 10,
      default: 12,
    }),
    paddingHorizontal: 8,
    backgroundColor: Colors.surface,
    borderTopWidth: 1,
    borderTopColor: Colors.glassBorder,
  };

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarStyle,
        tabBarActiveTintColor: Colors.gold,
        tabBarInactiveTintColor: Colors.textMuted,
        tabBarLabelStyle: {
          fontSize: 11,
          fontWeight: FontWeight.medium,
          marginTop: 2,
        },
        tabBarHideOnKeyboard: true,
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: 'الرئيسية',
          tabBarIcon: ({ color, size }) => (
            <MaterialIcons name="home" size={size} color={color} />
          ),
        }}
      />
      <Tabs.Screen
        name="favorites"
        options={{
          title: 'المفضلة',
          tabBarIcon: ({ color, size }) => (
            <MaterialIcons name="favorite" size={size} color={color} />
          ),
        }}
      />
      <Tabs.Screen
        name="request"
        options={{
          title: isCraftsman ? 'طلباتي' : 'طلب خدمة',
          tabBarIcon: ({ color, focused }) => (
            <View style={[styles.requestIcon, focused && styles.requestIconActive]}>
              <MaterialIcons
                name={isCraftsman ? 'work' : 'add'}
                size={isCraftsman ? 24 : 28}
                color={focused ? Colors.primary : Colors.text}
              />
            </View>
          ),
          tabBarLabel: () => (
            <Text style={styles.requestLabel}>{isCraftsman ? 'طلباتي' : 'طلب خدمة'}</Text>
          ),
        }}
      />
      <Tabs.Screen
        name="orders"
        options={{
          title: isCraftsman ? 'مهامي' : 'طلباتي',
          tabBarIcon: ({ color, size }) => (
            <MaterialIcons name="list-alt" size={size} color={color} />
          ),
        }}
      />
      <Tabs.Screen
        name="chats"
        options={{
          title: 'الدردشات',
          tabBarIcon: ({ color, size }) => (
            <MaterialIcons name="chat" size={size} color={color} />
          ),
        }}
      />
      <Tabs.Screen
        name="profile"
        options={{
          title: 'حسابي',
          tabBarIcon: ({ color, size }) => (
            <MaterialIcons name="person" size={size} color={color} />
          ),
        }}
      />
    </Tabs>
  );
}

const styles = StyleSheet.create({
  requestIcon: {
    width: 52,
    height: 52,
    borderRadius: 26,
    backgroundColor: Colors.primarySurface,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: -16,
    borderWidth: 3,
    borderColor: Colors.background,
  },
  requestIconActive: {
    backgroundColor: Colors.gold,
  },
  requestLabel: {
    fontSize: 10,
    color: Colors.gold,
    fontWeight: FontWeight.medium,
    marginTop: 2,
  },
});
