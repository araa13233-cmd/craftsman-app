import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, StyleSheet, ScrollView, Pressable,
  Switch, ActivityIndicator, Alert,
} from 'react-native';
import { useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import * as ImagePicker from 'expo-image-picker';
import { Colors, FontSize, FontWeight, Radius, Spacing, Shadow } from '@/constants/theme';
import { useApp } from '@/hooks/useApp';
import { useAuth, useAlert, getSupabaseClient } from '@/template';

export default function ProfileScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { orders, userRole } = useApp();
  const { user, logout } = useAuth();
  const { showAlert } = useAlert();
  const supabase = getSupabaseClient();

  const [darkMode, setDarkMode] = useState(true);
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);
  const [uploadingAvatar, setUploadingAvatar] = useState(false);
  const [craftsmanAvailable, setCraftsmanAvailable] = useState(false);

  const isCraftsman = userRole === 'craftsman';
  const completedOrders = orders.filter(o => o.status === 'completed').length;

  // ── Fetch Avatar ────────────────────────────────────────────────────────────
  const fetchAvatar = useCallback(async () => {
    if (!user) return;
    const { data } = await supabase
      .from('user_profiles')
      .select('avatar_url')
      .eq('id', user.id)
      .single();
    if (data?.avatar_url) setAvatarUrl(data.avatar_url);
  }, [user]);

  const checkCraftsmanStatus = useCallback(async () => {
    if (!user) return;
    try {
      const { data } = await supabase
        .from('craftsmen')
        .select('id, available')
        .eq('user_id', user.id)
        .maybeSingle();
      if (data) setCraftsmanAvailable(data.available ?? false);
    } catch { /* silent */ }
  }, [user]);

  useEffect(() => {
    fetchAvatar();
    checkCraftsmanStatus();
  }, [fetchAvatar, checkCraftsmanStatus]);

  // ── Upload Avatar ───────────────────────────────────────────────────────────
  const pickAndUploadAvatar = async (source: 'camera' | 'gallery') => {
    if (!user) return;
    let result: ImagePicker.ImagePickerResult;

    if (source === 'camera') {
      const { status } = await ImagePicker.requestCameraPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('الكاميرا', 'يرجى السماح للتطبيق باستخدام الكاميرا');
        return;
      }
      result = await ImagePicker.launchCameraAsync({
        mediaTypes: 'images', quality: 0.8, allowsEditing: true, aspect: [1, 1],
      });
    } else {
      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('المعرض', 'يرجى السماح للتطبيق بالوصول إلى معرض الصور');
        return;
      }
      result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: 'images', quality: 0.8, allowsEditing: true, aspect: [1, 1],
      });
    }

    if (result.canceled || !result.assets?.[0]) return;
    const asset = result.assets[0];

    setUploadingAvatar(true);
    try {
      const ext = (asset.uri.split('.').pop() ?? 'jpg').toLowerCase().replace('jpeg', 'jpg');
      const fileName = `avatars/${user.id}-${Date.now()}.${ext}`;
      const response = await fetch(asset.uri);
      const blob = await response.blob();
      const arrayBuffer = await new Response(blob).arrayBuffer();

      const { error: uploadError } = await supabase.storage
        .from('profile-images')
        .upload(fileName, arrayBuffer, { contentType: `image/${ext}`, upsert: true });

      if (uploadError) throw new Error(uploadError.message);

      const { data: { publicUrl } } = supabase.storage
        .from('profile-images')
        .getPublicUrl(fileName);

      // Add cache-busting timestamp
      const freshUrl = `${publicUrl}?t=${Date.now()}`;

      // Update in database
      const { error: dbError } = await supabase
        .from('user_profiles')
        .update({ avatar_url: freshUrl })
        .eq('id', user.id);

      if (dbError) throw new Error(dbError.message);

      // Update UI immediately with fresh URL
      setAvatarUrl(freshUrl);
      showAlert('تم', 'تم تحديث صورتك الشخصية بنجاح');
      // Also refresh avatar from DB to confirm persistence
      setTimeout(() => fetchAvatar(), 1500);
    } catch (err: any) {
      Alert.alert('خطأ', 'لم يتم رفع الصورة. حاول مرة أخرى.');
    } finally {
      setUploadingAvatar(false);
    }
  };

  const showAvatarOptions = () => {
    Alert.alert('تغيير الصورة الشخصية', 'اختر المصدر', [
      { text: 'الكاميرا', onPress: () => pickAndUploadAvatar('camera') },
      { text: 'معرض الصور', onPress: () => pickAndUploadAvatar('gallery') },
      ...(avatarUrl ? [{
        text: 'حذف الصورة',
        style: 'destructive' as const,
        onPress: async () => {
          setUploadingAvatar(true);
          await supabase.from('user_profiles').update({ avatar_url: null }).eq('id', user!.id);
          setAvatarUrl(null);
          setUploadingAvatar(false);
        },
      }] : []),
      { text: 'إلغاء', style: 'cancel' },
    ]);
  };

  const handleLogout = () => {
    showAlert('تسجيل الخروج', 'هل تريد تسجيل الخروج؟', [
      { text: 'إلغاء', style: 'cancel' },
      {
        text: 'خروج', style: 'destructive', onPress: async () => {
          await logout();
          router.replace('/');
        },
      },
    ]);
  };

  if (!user) {
    return (
      <View style={[styles.container, { paddingTop: insets.top }]}>
        <StatusBar style="light" />
        <View style={styles.guestContainer}>
          <View style={styles.guestIcon}>
            <MaterialIcons name="person" size={56} color={Colors.textMuted} />
          </View>
          <Text style={styles.guestTitle}>ليس لديك حساب</Text>
          <Text style={styles.guestText}>سجّل دخولك للوصول إلى حسابك وطلباتك</Text>
          <Pressable style={styles.loginBtn} onPress={() => router.push('/auth/login')}>
            <Text style={styles.loginBtnText}>تسجيل الدخول</Text>
          </Pressable>
          <Pressable onPress={() => router.push('/auth/register')}>
            <Text style={styles.registerLink}>إنشاء حساب جديد</Text>
          </Pressable>
        </View>
      </View>
    );
  }

  const displayName = user.username || user.email?.split('@')[0] || 'المستخدم';
  const fallbackAvatar = `https://ui-avatars.com/api/?name=${encodeURIComponent(displayName)}&background=D4A017&color=0D1B3E&size=200`;
  const avatarSource = avatarUrl ?? fallbackAvatar;

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <StatusBar style="light" />
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 30 }}>

        {/* ── Profile Header ── */}
        <View style={styles.profileHeader}>
          <Pressable style={styles.avatarWrapper} onPress={showAvatarOptions} disabled={uploadingAvatar}>
            {uploadingAvatar ? (
              <View style={styles.avatarLoading}>
                <ActivityIndicator color={Colors.gold} size="large" />
              </View>
            ) : (
              <Image
                key={avatarSource}
                source={{ uri: avatarSource }}
                style={styles.avatar}
                contentFit="cover"
                transition={200}
                cachePolicy="none"
              />
            )}
            <View style={styles.cameraOverlay}>
              <MaterialIcons name="photo-camera" size={16} color={Colors.text} />
            </View>
            {!uploadingAvatar && (
              <View style={styles.verifiedBadge}>
                <MaterialIcons name="verified" size={18} color={Colors.gold} />
              </View>
            )}
          </Pressable>

          <Text style={styles.userName}>{displayName}</Text>
          <Text style={styles.userEmail}>{user.email}</Text>

          {/* Role badge */}
          <View style={[styles.roleBadge, isCraftsman && styles.roleBadgeCraftsman]}>
            <MaterialIcons
              name={isCraftsman ? 'engineering' : 'person'}
              size={13}
              color={isCraftsman ? Colors.primary : Colors.gold}
            />
            <Text style={[styles.roleText, isCraftsman && styles.roleTextCraftsman]}>
              {isCraftsman ? 'حرفي معتمد' : 'عميل'}
            </Text>
          </View>

          <Pressable style={styles.changePhotoBtn} onPress={showAvatarOptions} disabled={uploadingAvatar}>
            <MaterialIcons name="edit" size={14} color={Colors.gold} />
            <Text style={styles.changePhotoText}>
              {uploadingAvatar ? 'جاري الرفع...' : 'تغيير الصورة الشخصية'}
            </Text>
          </Pressable>
        </View>

        {/* Stats */}
        <View style={styles.statsRow}>
          {[
            { num: orders.length,     label: 'إجمالي الطلبات', icon: 'list-alt',    color: Colors.info },
            { num: completedOrders,   label: 'مكتملة',         icon: 'check-circle', color: Colors.success },
            { num: '4.8',             label: 'تقييمي',         icon: 'star',         color: Colors.gold },
          ].map((s, i) => (
            <View key={i} style={styles.statCard}>
              <MaterialIcons name={s.icon as any} size={20} color={s.color} />
              <Text style={[styles.statNum, { color: s.color }]}>{s.num}</Text>
              <Text style={styles.statLabel}>{s.label}</Text>
            </View>
          ))}
        </View>

        {/* ── Account Section ── */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>الحساب</Text>
          <View style={styles.menuGroup}>
            <MenuRow icon="person"       label="الملف الشخصي"  sub="تعديل الاسم والصورة"      onPress={() => router.push('/profile/edit' as any)} />
            <MenuRow icon="list-alt"     label="طلباتي"         sub={`${orders.length} طلب`}   onPress={() => router.push('/(tabs)/orders' as any)} />
            <MenuRow icon="favorite"     label="المفضلة"        sub="الحرفيون المحفوظون"       onPress={() => router.push('/(tabs)/favorites' as any)} />
            <MenuRow icon="chat"         label="المحادثات"      sub="كل رسائلك مع الحرفيين"   onPress={() => router.push('/(tabs)/chats' as any)} />
            <MenuRow icon="notifications" label="الإشعارات"                                    onPress={() => router.push('/notifications' as any)} last />
          </View>
        </View>

        {/* ── Settings Section ── */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>الإعدادات</Text>
          <View style={styles.menuGroup}>
            <MenuRow
              icon="dark-mode"
              label="الوضع الداكن"
              sub={darkMode ? 'مفعّل' : 'معطّل'}
              toggle toggleValue={darkMode}
              onToggle={val => setDarkMode(val)}
            />
            <MenuRow
              icon="notifications-active"
              label="الإشعارات"
              sub={notificationsEnabled ? 'مفعّلة' : 'معطّلة'}
              toggle toggleValue={notificationsEnabled}
              onToggle={setNotificationsEnabled}
            />
            <MenuRow
              icon="language"
              label="اللغة"
              value="العربية 🇸🇦"
              onPress={() => showAlert('اللغة', 'يدعم التطبيق اللغة العربية حالياً')}
              last
            />
          </View>
        </View>

        {/* ── Craftsman Section ── */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>للحرفيين</Text>
          <View style={styles.menuGroup}>
            {isCraftsman ? (
              <MenuRow
                icon="engineering"
                label="ملفي كحرفي"
                sub={craftsmanAvailable ? 'متاح الآن — إدارة ملفك المهني' : 'غير متاح — إدارة ملفك المهني'}
                highlight
                onPress={() => router.push('/craftsman-profile' as any)}
                last
              />
            ) : (
              <MenuRow
                icon="engineering"
                label="سجّل كحرفي معتمد"
                sub="انضم واعثر على عملاء في منطقتك"
                highlight
                onPress={() => router.push('/craftsman-register' as any)}
                last
              />
            )}
          </View>
        </View>

        {/* ── Admin Section ── */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>الإدارة</Text>
          <View style={styles.menuGroup}>
            <MenuRow icon="admin-panel-settings" label="لوحة التحكم" sub="إحصائيات وإدارة" onPress={() => router.push('/admin' as any)} last />
          </View>
        </View>

        {/* ── Support Section ── */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>الدعم والمساعدة</Text>
          <View style={styles.menuGroup}>
            <MenuRow icon="chat"       label="تواصل معنا"  sub="دعم، شكاوى، اقتراحات"                   onPress={() => router.push('/contact' as any)} />
            <MenuRow icon="star-rate"  label="قيّم التطبيق" sub="ساعدنا في التحسين"                      onPress={() => showAlert('شكراً!', 'نقدّر دعمك. يمكنك تقييمنا في متجر التطبيقات')} />
            <MenuRow icon="share"      label="شارك التطبيق"                                              onPress={() => showAlert('المشاركة', 'شارك التطبيق مع أصدقائك!')} />
            <MenuRow icon="info"       label="عن التطبيق"  value="v1.0"                                  onPress={() => showAlert('معلم - Muallim', 'الإصدار 1.0\nيربط العملاء بالحرفيين المعتمدين')} last />
          </View>
        </View>

        {/* ── Logout ── */}
        <View style={styles.section}>
          <View style={styles.menuGroup}>
            <Pressable style={styles.logoutBtn} onPress={handleLogout}>
              {({ pressed }) => (
                <View style={[styles.logoutBtnInner, pressed && { opacity: 0.85 }]}>
                  <Text style={styles.logoutText}>تسجيل الخروج</Text>
                  <MaterialIcons name="logout" size={20} color={Colors.error} />
                </View>
              )}
            </Pressable>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

// ─── Menu Row ─────────────────────────────────────────────────────────────────
function MenuRow({
  icon, label, sub, value, onPress,
  toggle, toggleValue, onToggle,
  highlight, last,
}: {
  icon: string; label: string; sub?: string; value?: string;
  onPress?: () => void;
  toggle?: boolean; toggleValue?: boolean; onToggle?: (v: boolean) => void;
  highlight?: boolean; last?: boolean;
}) {
  return (
    <Pressable
      style={[styles.menuItem, !last && styles.menuItemBorder]}
      onPress={!toggle ? onPress : undefined}
    >
      {({ pressed }) => (
        <View style={[styles.menuItemInner, pressed && !toggle && { opacity: 0.85 }]}>
          <View style={styles.menuAction}>
            {toggle ? (
              <Switch
                value={toggleValue}
                onValueChange={onToggle}
                trackColor={{ false: Colors.surface2, true: Colors.gold }}
                thumbColor={toggleValue ? Colors.primary : Colors.textMuted}
              />
            ) : (
              <>
                {value ? <Text style={styles.menuValue}>{value}</Text> : null}
                <MaterialIcons name="chevron-left" size={20} color={Colors.textMuted} />
              </>
            )}
          </View>
          <View style={styles.menuLeft}>
            <View style={styles.menuText}>
              <Text style={[styles.menuLabel, highlight && { color: Colors.gold }]}>{label}</Text>
              {sub ? <Text style={styles.menuSub}>{sub}</Text> : null}
            </View>
            <View style={[styles.menuIconBg, highlight && { backgroundColor: Colors.goldSoft }]}>
              <MaterialIcons name={icon as any} size={20} color={Colors.gold} />
            </View>
          </View>
        </View>
      )}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },

  guestContainer: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: Spacing.xl, gap: Spacing.md },
  guestIcon: { width: 100, height: 100, borderRadius: 50, backgroundColor: Colors.surface, alignItems: 'center', justifyContent: 'center' },
  guestTitle: { fontSize: FontSize.xxl, fontWeight: FontWeight.bold, color: Colors.text },
  guestText: { fontSize: FontSize.base, color: Colors.textMuted, textAlign: 'center', lineHeight: 24 },
  loginBtn: { backgroundColor: Colors.gold, borderRadius: Radius.lg, paddingVertical: 14, paddingHorizontal: 48, ...Shadow.gold },
  loginBtnText: { color: Colors.primary, fontWeight: FontWeight.bold, fontSize: FontSize.base },
  registerLink: { color: Colors.gold, fontSize: FontSize.sm, fontWeight: FontWeight.medium },

  profileHeader: {
    alignItems: 'center', paddingVertical: Spacing.xl,
    paddingHorizontal: Spacing.lg, backgroundColor: Colors.surface,
    marginBottom: Spacing.md, borderBottomWidth: 1, borderBottomColor: Colors.divider,
  },
  avatarWrapper: { position: 'relative', marginBottom: Spacing.sm },
  avatar: { width: 100, height: 100, borderRadius: 50, borderWidth: 3, borderColor: Colors.gold },
  avatarLoading: {
    width: 100, height: 100, borderRadius: 50,
    borderWidth: 3, borderColor: Colors.gold,
    backgroundColor: Colors.surface2, alignItems: 'center', justifyContent: 'center',
  },
  cameraOverlay: {
    position: 'absolute', bottom: 2, right: 2,
    width: 30, height: 30, borderRadius: 15,
    backgroundColor: Colors.gold, alignItems: 'center', justifyContent: 'center',
    borderWidth: 2, borderColor: Colors.background,
  },
  verifiedBadge: {
    position: 'absolute', top: 2, left: -2,
    backgroundColor: Colors.background, borderRadius: 10, padding: 1,
  },
  roleBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 5,
    backgroundColor: Colors.goldSoft, borderRadius: Radius.full,
    paddingHorizontal: 12, paddingVertical: 5,
    borderWidth: 1, borderColor: 'rgba(212,160,23,0.25)', marginTop: 6,
  },
  roleBadgeCraftsman: {
    backgroundColor: Colors.gold,
    borderColor: Colors.gold,
  },
  roleText: { fontSize: FontSize.xs, color: Colors.gold, fontWeight: FontWeight.semibold },
  roleTextCraftsman: { color: Colors.primary },
  changePhotoBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    backgroundColor: Colors.surface2, borderRadius: Radius.full,
    paddingHorizontal: 14, paddingVertical: 7,
    marginTop: Spacing.sm,
    borderWidth: 1, borderColor: Colors.border,
  },
  changePhotoText: { fontSize: FontSize.xs, color: Colors.gold, fontWeight: FontWeight.semibold },
  userName: { fontSize: FontSize.xxl, fontWeight: FontWeight.bold, color: Colors.text, marginBottom: 4 },
  userEmail: { fontSize: FontSize.sm, color: Colors.textMuted, marginBottom: 2 },

  statsRow: { flexDirection: 'row', paddingHorizontal: Spacing.lg, paddingVertical: Spacing.md, gap: Spacing.sm, marginBottom: Spacing.sm },
  statCard: {
    flex: 1, backgroundColor: Colors.surface, borderRadius: Radius.lg,
    paddingVertical: Spacing.md, alignItems: 'center', gap: 4,
    borderWidth: 1, borderColor: Colors.border,
  },
  statNum: { fontSize: FontSize.xl, fontWeight: FontWeight.bold },
  statLabel: { fontSize: 10, color: Colors.textMuted, textAlign: 'center' },

  section: { marginHorizontal: Spacing.lg, marginBottom: Spacing.md },
  sectionTitle: {
    fontSize: FontSize.sm, color: Colors.textMuted, fontWeight: FontWeight.semibold,
    marginBottom: Spacing.sm, textAlign: 'right',
  },
  menuGroup: {
    backgroundColor: Colors.surface, borderRadius: Radius.xl,
    overflow: 'hidden', borderWidth: 1, borderColor: Colors.border,
  },
  menuItem: {},
  menuItemBorder: { borderBottomWidth: 1, borderBottomColor: Colors.divider },
  menuItemInner: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: Spacing.md, paddingVertical: 13,
  },
  menuLeft: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md, flex: 1 },
  menuAction: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  menuIconBg: {
    width: 38, height: 38, borderRadius: Radius.sm,
    backgroundColor: Colors.goldSoft, alignItems: 'center', justifyContent: 'center',
  },
  menuText: { flex: 1, alignItems: 'flex-end' },
  menuLabel: { fontSize: FontSize.base, color: Colors.text, fontWeight: FontWeight.medium },
  menuSub: { fontSize: FontSize.xs, color: Colors.textMuted, marginTop: 2 },
  menuValue: { fontSize: FontSize.sm, color: Colors.textMuted },

  logoutBtn: { overflow: 'hidden' },
  logoutBtnInner: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: Spacing.sm,
    paddingVertical: 14, backgroundColor: 'rgba(231,76,60,0.06)',
  },
  logoutText: { fontSize: FontSize.base, fontWeight: FontWeight.bold, color: Colors.error },

  surface2: { backgroundColor: Colors.surface2 } as any,
});
