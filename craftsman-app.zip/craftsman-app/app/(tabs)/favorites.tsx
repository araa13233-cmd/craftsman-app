import React from 'react';
import { View, Text, StyleSheet, FlatList, Pressable } from 'react-native';
import { useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import { Colors, FontSize, FontWeight, Radius, Spacing, Shadow } from '@/constants/theme';
import { useApp } from '@/hooks/useApp';

export default function FavoritesScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { favorites, allCraftsmen, toggleFavorite } = useApp();

  const favCraftsmen = allCraftsmen.filter(c => favorites.includes(c.id));

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <StatusBar style="light" />

      <View style={styles.header}>
        <Text style={styles.headerTitle}>المفضلة</Text>
        <Text style={styles.headerCount}>{favCraftsmen.length} حرفي</Text>
      </View>

      {favCraftsmen.length === 0 ? (
        <View style={styles.emptyState}>
          <MaterialIcons name="favorite-border" size={64} color={Colors.textMuted} />
          <Text style={styles.emptyTitle}>قائمة المفضلة فارغة</Text>
          <Text style={styles.emptyText}>أضف الحرفيين المميزين إلى مفضلتك للوصول إليهم بسرعة</Text>
          <Pressable style={styles.browseBtn} onPress={() => router.push('/craftsmen/index' as any)}>
            <Text style={styles.browseBtnText}>تصفح الحرفيين</Text>
          </Pressable>
        </View>
      ) : (
        <FlatList
          data={favCraftsmen}
          keyExtractor={i => i.id}
          contentContainerStyle={{ padding: Spacing.lg, gap: Spacing.md }}
          showsVerticalScrollIndicator={false}
          renderItem={({ item }) => (
            <Pressable
              style={styles.card}
              onPress={() => router.push(`/craftsmen/${item.id}` as any)}
            >
              {({ pressed }) => (
                <View style={[styles.cardInner, pressed && { opacity: 0.9 }]}>
                  <Image
                    source={{ uri: item.image }}
                    style={styles.craftsmanImg}
                    contentFit="cover"
                  />
                  <View style={styles.info}>
                    <View style={styles.infoTop}>
                      <View style={[styles.availBadge, { backgroundColor: item.available ? 'rgba(46,204,113,0.15)' : 'rgba(231,76,60,0.15)' }]}>
                        <View style={[styles.availDot, { backgroundColor: item.available ? Colors.success : Colors.error }]} />
                        <Text style={[styles.availText, { color: item.available ? Colors.success : Colors.error }]}>
                          {item.available ? 'متاح' : 'مشغول'}
                        </Text>
                      </View>
                      <Text style={styles.name}>{item.name}</Text>
                    </View>
                    <Text style={styles.specialty}>{item.specialty}</Text>
                    <View style={styles.meta}>
                      <Text style={styles.metaText}>{item.distance}</Text>
                      <View style={styles.ratingRow}>
                        <MaterialIcons name="star" size={14} color={Colors.gold} />
                        <Text style={styles.rating}>{item.rating}</Text>
                        <Text style={styles.reviews}>({item.reviewCount})</Text>
                      </View>
                    </View>
                  </View>
                  <Pressable style={styles.removeBtn} onPress={() => toggleFavorite(item.id)}>
                    <MaterialIcons name="favorite" size={20} color="#E74C3C" />
                  </Pressable>
                </View>
              )}
            </Pressable>
          )}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: Spacing.lg, paddingVertical: Spacing.md,
    borderBottomWidth: 1, borderBottomColor: Colors.divider,
  },
  headerTitle: { fontSize: FontSize.xxl, fontWeight: FontWeight.bold, color: Colors.text },
  headerCount: { fontSize: FontSize.sm, color: Colors.textMuted, backgroundColor: Colors.surface, paddingHorizontal: 12, paddingVertical: 5, borderRadius: Radius.full },
  emptyState: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: Spacing.xl, gap: Spacing.md },
  emptyTitle: { fontSize: FontSize.xl, fontWeight: FontWeight.bold, color: Colors.text, textAlign: 'center' },
  emptyText: { fontSize: FontSize.base, color: Colors.textMuted, textAlign: 'center', lineHeight: 24 },
  browseBtn: { backgroundColor: Colors.gold, borderRadius: Radius.lg, paddingVertical: 13, paddingHorizontal: Spacing.xl },
  browseBtnText: { color: Colors.primary, fontWeight: FontWeight.bold, fontSize: FontSize.base },
  card: { borderRadius: Radius.xl, overflow: 'hidden' },
  cardInner: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: Colors.surface, borderRadius: Radius.xl,
    borderWidth: 1, borderColor: Colors.border, ...Shadow.sm,
  },
  craftsmanImg: { width: 90, height: 90, borderRadius: Radius.lg, margin: Spacing.sm },
  info: { flex: 1, paddingRight: Spacing.sm, gap: 4 },
  infoTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-end', gap: Spacing.sm },
  name: { fontSize: FontSize.base, fontWeight: FontWeight.bold, color: Colors.text, textAlign: 'right' },
  specialty: { fontSize: FontSize.sm, color: Colors.gold, textAlign: 'right' },
  availBadge: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 8, paddingVertical: 3, borderRadius: Radius.full },
  availDot: { width: 6, height: 6, borderRadius: 3 },
  availText: { fontSize: 10, fontWeight: FontWeight.semibold },
  meta: { flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-end', gap: Spacing.md, marginTop: 2 },
  metaText: { fontSize: FontSize.xs, color: Colors.textMuted },
  ratingRow: { flexDirection: 'row', alignItems: 'center', gap: 3 },
  rating: { fontSize: FontSize.sm, fontWeight: FontWeight.semibold, color: Colors.text },
  reviews: { fontSize: FontSize.xs, color: Colors.textMuted },
  removeBtn: { padding: Spacing.md, marginLeft: 4 },
});
