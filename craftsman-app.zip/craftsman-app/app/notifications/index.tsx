import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, StyleSheet, FlatList, Pressable, ActivityIndicator,
} from 'react-native';
import { useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';
import { Colors, FontSize, FontWeight, Radius, Spacing, Shadow } from '@/constants/theme';
import { getSupabaseClient, useAuth, useAlert } from '@/template';

// ─── Types ────────────────────────────────────────────────────────────────────
interface Notification {
  id: string;
  title: string;
  body: string;
  type: 'info' | 'order' | 'chat' | 'promo' | 'system';
  isRead: boolean;
  relatedId?: string;
  createdAt: string;
}

const TYPE_CONFIG = {
  info:   { icon: 'info',             color: Colors.info,      bg: 'rgba(52,152,219,0.12)'  },
  order:  { icon: 'receipt',          color: Colors.success,   bg: 'rgba(46,204,113,0.12)'  },
  chat:   { icon: 'chat-bubble',      color: Colors.gold,      bg: 'rgba(212,160,23,0.12)'  },
  promo:  { icon: 'local-offer',      color: '#E74C3C',        bg: 'rgba(231,76,60,0.12)'   },
  system: { icon: 'settings',         color: Colors.textMuted, bg: Colors.surface2          },
} as const;

// Demo notifications to show when no real ones exist
const DEMO_NOTIFICATIONS: Notification[] = [
  {
    id: 'demo-1',
    title: 'مرحباً بك في معلم!',
    body: 'يمكنك الآن طلب خدمات الحرفيين المعتمدين بسهولة وسرعة.',
    type: 'system',
    isRead: false,
    createdAt: new Date(Date.now() - 60000).toISOString(),
  },
  {
    id: 'demo-2',
    title: 'عروض حصرية لهذا الأسبوع',
    body: 'احصل على خصم 20% على خدمات الكهربائي والسباك هذا الأسبوع.',
    type: 'promo',
    isRead: false,
    createdAt: new Date(Date.now() - 3600000).toISOString(),
  },
  {
    id: 'demo-3',
    title: 'تم تأكيد طلبك',
    body: 'جاري تعيين أقرب حرفي متاح في منطقتك.',
    type: 'order',
    isRead: true,
    createdAt: new Date(Date.now() - 86400000).toISOString(),
  },
];

function formatTime(iso: string) {
  const d = new Date(iso);
  const now = new Date();
  const diffMs = now.getTime() - d.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  if (diffMins < 1) return 'الآن';
  if (diffMins < 60) return `منذ ${diffMins} دقيقة`;
  const diffHours = Math.floor(diffMins / 60);
  if (diffHours < 24) return `منذ ${diffHours} ساعة`;
  const diffDays = Math.floor(diffHours / 24);
  if (diffDays < 7) return `منذ ${diffDays} أيام`;
  return d.toLocaleDateString('ar-SA', { day: 'numeric', month: 'short' });
}

export default function NotificationsScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const { showAlert } = useAlert();
  const supabase = getSupabaseClient();

  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);
  const [markingAll, setMarkingAll] = useState(false);

  const fetchNotifications = useCallback(async () => {
    if (!user) {
      setNotifications(DEMO_NOTIFICATIONS);
      setLoading(false);
      return;
    }

    const { data, error } = await supabase
      .from('notifications')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });

    if (!error && data) {
      // If no notifications from DB, show demo ones
      const mapped: Notification[] = data.map((r: any) => ({
        id: r.id,
        title: r.title,
        body: r.body ?? '',
        type: r.type ?? 'info',
        isRead: r.is_read ?? false,
        relatedId: r.related_id,
        createdAt: r.created_at,
      }));
      setNotifications(mapped.length > 0 ? mapped : DEMO_NOTIFICATIONS);
    } else {
      setNotifications(DEMO_NOTIFICATIONS);
    }
    setLoading(false);
  }, [user]);

  useEffect(() => { fetchNotifications(); }, [fetchNotifications]);

  // Polling every 15s
  useEffect(() => {
    const interval = setInterval(() => fetchNotifications(), 15000);
    return () => clearInterval(interval);
  }, [fetchNotifications]);

  const markAsRead = async (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, isRead: true } : n));
    if (user && !id.startsWith('demo-')) {
      await supabase.from('notifications').update({ is_read: true }).eq('id', id);
    }
  };

  const markAllRead = async () => {
    if (markingAll) return;
    setMarkingAll(true);
    setNotifications(prev => prev.map(n => ({ ...n, isRead: true })));
    if (user) {
      await supabase
        .from('notifications')
        .update({ is_read: true })
        .eq('user_id', user.id)
        .eq('is_read', false);
    }
    setMarkingAll(false);
  };

  const deleteNotification = async (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
    if (user && !id.startsWith('demo-')) {
      await supabase.from('notifications').delete().eq('id', id);
    }
  };

  const clearAll = () => {
    showAlert('حذف الكل', 'هل تريد حذف جميع الإشعارات؟', [
      { text: 'إلغاء', style: 'cancel' },
      {
        text: 'حذف', style: 'destructive', onPress: async () => {
          setNotifications([]);
          if (user) {
            await supabase.from('notifications').delete().eq('user_id', user.id);
          }
        },
      },
    ]);
  };

  const handlePress = (n: Notification) => {
    if (!n.isRead) markAsRead(n.id);
    if (n.type === 'order' && n.relatedId) {
      router.push(`/orders/${n.relatedId}` as any);
    } else if (n.type === 'chat' && n.relatedId) {
      router.push(`/chat/${n.relatedId}` as any);
    }
  };

  const unreadCount = notifications.filter(n => !n.isRead).length;

  const renderItem = ({ item }: { item: Notification }) => {
    const cfg = TYPE_CONFIG[item.type] ?? TYPE_CONFIG.info;
    return (
      <Pressable onPress={() => handlePress(item)}>
        {({ pressed }) => (
          <View style={[
            styles.notifCard,
            !item.isRead && styles.notifCardUnread,
            pressed && { opacity: 0.88 },
          ]}>
            {!item.isRead && <View style={styles.unreadDot} />}

            <Pressable
              style={styles.deleteBtn}
              onPress={() => deleteNotification(item.id)}
              hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
            >
              <MaterialIcons name="close" size={16} color={Colors.textMuted} />
            </Pressable>

            <View style={styles.notifContent}>
              <View style={styles.notifText}>
                <Text style={[styles.notifTitle, !item.isRead && styles.notifTitleUnread]}>
                  {item.title}
                </Text>
                {item.body ? (
                  <Text style={styles.notifBody} numberOfLines={2}>{item.body}</Text>
                ) : null}
                <View style={styles.notifFooter}>
                  {!item.isRead && (
                    <Pressable
                      style={styles.readBtn}
                      onPress={() => markAsRead(item.id)}
                    >
                      <Text style={styles.readBtnText}>تحديد كمقروء</Text>
                    </Pressable>
                  )}
                  <Text style={styles.notifTime}>{formatTime(item.createdAt)}</Text>
                </View>
              </View>
              <View style={[styles.notifIconBg, { backgroundColor: cfg.bg }]}>
                <MaterialIcons name={cfg.icon as any} size={22} color={cfg.color} />
              </View>
            </View>
          </View>
        )}
      </Pressable>
    );
  };

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <StatusBar style="light" />

      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerActions}>
          {notifications.length > 0 && (
            <Pressable style={styles.clearBtn} onPress={clearAll}>
              <MaterialIcons name="delete-sweep" size={18} color={Colors.error} />
            </Pressable>
          )}
          <Pressable
            style={[styles.markAllBtn, (markingAll || unreadCount === 0) && { opacity: 0.45 }]}
            onPress={markAllRead}
            disabled={markingAll || unreadCount === 0}
          >
            <MaterialIcons name="done-all" size={16} color={Colors.gold} />
            <Text style={styles.markAllText}>قراءة الكل</Text>
          </Pressable>
        </View>

        <View style={styles.headerTitleRow}>
          <Text style={styles.headerTitle}>الإشعارات</Text>
          {unreadCount > 0 && (
            <View style={styles.headerBadge}>
              <Text style={styles.headerBadgeText}>{unreadCount > 99 ? '99+' : unreadCount}</Text>
            </View>
          )}
        </View>

        <Pressable style={styles.backBtn} onPress={() => router.back()}>
          <MaterialIcons name="arrow-forward" size={22} color={Colors.text} />
        </Pressable>
      </View>

      {/* Filter tabs */}
      {notifications.length > 0 && (
        <View style={styles.filterRow}>
          <View style={styles.filterStats}>
            <View style={styles.filterStat}>
              <Text style={[styles.filterStatNum, { color: Colors.error }]}>{unreadCount}</Text>
              <Text style={styles.filterStatLabel}>غير مقروء</Text>
            </View>
            <View style={styles.filterDivider} />
            <View style={styles.filterStat}>
              <Text style={[styles.filterStatNum, { color: Colors.textMuted }]}>{notifications.length - unreadCount}</Text>
              <Text style={styles.filterStatLabel}>مقروء</Text>
            </View>
            <View style={styles.filterDivider} />
            <View style={styles.filterStat}>
              <Text style={[styles.filterStatNum, { color: Colors.gold }]}>{notifications.length}</Text>
              <Text style={styles.filterStatLabel}>المجموع</Text>
            </View>
          </View>
        </View>
      )}

      {loading ? (
        <View style={styles.centered}>
          <ActivityIndicator size="large" color={Colors.gold} />
          <Text style={styles.loadingText}>جاري تحميل الإشعارات...</Text>
        </View>
      ) : notifications.length === 0 ? (
        <View style={styles.centered}>
          <View style={styles.emptyIcon}>
            <MaterialIcons name="notifications-none" size={52} color={Colors.textMuted} />
          </View>
          <Text style={styles.emptyTitle}>لا توجد إشعارات</Text>
          <Text style={styles.emptyText}>ستظهر هنا إشعارات طلباتك ومحادثاتك</Text>
          <Pressable style={styles.exploreBtn} onPress={() => router.push('/(tabs)' as any)}>
            <Text style={styles.exploreBtnText}>استكشف الخدمات</Text>
          </Pressable>
        </View>
      ) : (
        <FlatList
          data={notifications}
          keyExtractor={n => n.id}
          renderItem={renderItem}
          contentContainerStyle={{ padding: Spacing.md, gap: Spacing.sm, paddingBottom: insets.bottom + 30 }}
          showsVerticalScrollIndicator={false}
          onRefresh={fetchNotifications}
          refreshing={loading}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  centered: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: Spacing.md, padding: Spacing.xl },
  loadingText: { color: Colors.textMuted, fontSize: FontSize.base },

  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: Spacing.md, paddingVertical: Spacing.md,
    borderBottomWidth: 1, borderBottomColor: Colors.divider,
  },
  backBtn: {
    width: 44, height: 44, borderRadius: Radius.md,
    backgroundColor: Colors.surface, alignItems: 'center', justifyContent: 'center',
  },
  headerTitleRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  headerTitle: { fontSize: FontSize.xl, fontWeight: FontWeight.bold, color: Colors.text },
  headerBadge: {
    backgroundColor: Colors.error, borderRadius: Radius.full,
    minWidth: 22, height: 22, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 5,
  },
  headerBadgeText: { fontSize: 11, fontWeight: FontWeight.bold, color: Colors.text },
  headerActions: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  markAllBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 5,
    backgroundColor: Colors.goldSoft, borderRadius: Radius.full,
    paddingHorizontal: 10, paddingVertical: 7,
    borderWidth: 1, borderColor: 'rgba(212,160,23,0.25)',
  },
  markAllText: { fontSize: FontSize.xs, color: Colors.gold, fontWeight: FontWeight.semibold },
  clearBtn: {
    width: 36, height: 36, borderRadius: 18,
    backgroundColor: 'rgba(231,76,60,0.1)', alignItems: 'center', justifyContent: 'center',
    borderWidth: 1, borderColor: 'rgba(231,76,60,0.2)',
  },

  // Filter stats bar
  filterRow: {
    paddingHorizontal: Spacing.lg, paddingVertical: Spacing.sm,
    borderBottomWidth: 1, borderBottomColor: Colors.divider,
  },
  filterStats: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: Spacing.xl },
  filterStat: { alignItems: 'center', gap: 2 },
  filterStatNum: { fontSize: FontSize.lg, fontWeight: FontWeight.bold },
  filterStatLabel: { fontSize: 10, color: Colors.textMuted },
  filterDivider: { width: 1, height: 30, backgroundColor: Colors.divider },

  // Notification card
  notifCard: {
    backgroundColor: Colors.surface, borderRadius: Radius.xl,
    borderWidth: 1, borderColor: Colors.border,
    padding: Spacing.md, position: 'relative', overflow: 'hidden',
  },
  notifCardUnread: {
    borderColor: 'rgba(212,160,23,0.4)',
    backgroundColor: 'rgba(212,160,23,0.04)',
  },
  unreadDot: {
    position: 'absolute', top: Spacing.md, left: Spacing.md,
    width: 8, height: 8, borderRadius: 4, backgroundColor: Colors.gold,
  },
  deleteBtn: {
    position: 'absolute', top: Spacing.sm, right: Spacing.sm,
    width: 28, height: 28, borderRadius: 14,
    alignItems: 'center', justifyContent: 'center',
    backgroundColor: Colors.surface2,
  },
  notifContent: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md },
  notifIconBg: {
    width: 50, height: 50, borderRadius: Radius.md,
    alignItems: 'center', justifyContent: 'center', flexShrink: 0,
  },
  notifText: { flex: 1, gap: 5, alignItems: 'flex-end' },
  notifTitle: { fontSize: FontSize.base, color: Colors.textMuted, fontWeight: FontWeight.medium, textAlign: 'right' },
  notifTitleUnread: { color: Colors.text, fontWeight: FontWeight.bold },
  notifBody: { fontSize: FontSize.sm, color: Colors.textMuted, textAlign: 'right', lineHeight: 20 },
  notifFooter: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', width: '100%' },
  notifTime: { fontSize: FontSize.xs, color: Colors.textMuted },
  readBtn: {
    backgroundColor: Colors.goldSoft, borderRadius: Radius.full,
    paddingHorizontal: 8, paddingVertical: 3,
    borderWidth: 1, borderColor: 'rgba(212,160,23,0.25)',
  },
  readBtnText: { fontSize: 10, color: Colors.gold, fontWeight: FontWeight.semibold },

  emptyIcon: {
    width: 90, height: 90, borderRadius: 45,
    backgroundColor: Colors.surface, borderWidth: 1, borderColor: Colors.border,
    alignItems: 'center', justifyContent: 'center',
  },
  emptyTitle: { fontSize: FontSize.xl, fontWeight: FontWeight.bold, color: Colors.text },
  emptyText: { fontSize: FontSize.sm, color: Colors.textMuted, textAlign: 'center', lineHeight: 22 },
  exploreBtn: {
    backgroundColor: Colors.gold, borderRadius: Radius.lg,
    paddingVertical: 13, paddingHorizontal: Spacing.xl,
  },
  exploreBtnText: { color: Colors.primary, fontWeight: FontWeight.bold, fontSize: FontSize.base },
});
