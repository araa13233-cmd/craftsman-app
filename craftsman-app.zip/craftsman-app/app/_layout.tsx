import { AlertProvider, AuthProvider } from '@/template';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { Stack } from 'expo-router';
import { AppProvider } from '@/contexts/AppContext';
import { OrderNotificationProvider } from '@/contexts/OrderNotificationContext';
import { I18nManager, Platform } from 'react-native';
import * as WebBrowser from 'expo-web-browser';

// Fix: maybeCompleteAuthSession moved in newer expo-web-browser versions
if (typeof WebBrowser.maybeCompleteAuthSession !== 'function') {
  (WebBrowser as any).maybeCompleteAuthSession = () => ({ type: 'failed', message: 'Not supported' });
}
WebBrowser.maybeCompleteAuthSession();

// Force RTL for Arabic
if (Platform.OS !== 'web') {
  I18nManager.allowRTL(true);
  I18nManager.forceRTL(true);
}

export default function RootLayout() {
  return (
    <AlertProvider>
      <SafeAreaProvider>
        <AuthProvider>
          <AppProvider>
            <OrderNotificationProvider>
              <Stack screenOptions={{ headerShown: false }}>
                <Stack.Screen name="index" />
                <Stack.Screen name="(tabs)" />
                <Stack.Screen name="auth/login" />
                <Stack.Screen name="auth/register" />
                <Stack.Screen name="craftsmen/index" />
                <Stack.Screen name="craftsmen/[id]" />
                <Stack.Screen name="request/new" />
                <Stack.Screen name="admin/index" />
                <Stack.Screen name="chat/[id]" />
                <Stack.Screen name="notifications/index" />
                <Stack.Screen name="craftsman-register/index" />
                <Stack.Screen name="orders/[id]" />
                <Stack.Screen name="profile/edit" />
                <Stack.Screen name="contact" />
                <Stack.Screen name="chats/index" />
                <Stack.Screen name="craftsman-profile/index" />
              </Stack>
            </OrderNotificationProvider>
          </AppProvider>
        </AuthProvider>
      </SafeAreaProvider>
    </AlertProvider>
  );
}
