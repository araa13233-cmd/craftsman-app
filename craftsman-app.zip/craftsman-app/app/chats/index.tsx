/**
 * Redirect: /chats → /(tabs)/chats
 * Prevents 404 when navigating to /chats directly from external links or older routes.
 */
import { Redirect } from 'expo-router';

export default function ChatsRedirect() {
  return <Redirect href={'/(tabs)/chats' as any} />;
}
