/**
 * Craftsman Profile Dashboard
 * Fixed: race condition, loading state, role detection, image upload
 */
import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  View, Text, StyleSheet, ScrollView, Pressable, TextInput,
  Switch, ActivityIndicator, Alert, KeyboardAvoidingView, Platform,
} from 'react-native';
import { useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import * as ImagePicker from 'expo-image-picker';
import { Colors, FontSize, FontWeight, Radius, Spacing, Shadow } from '@/constants/theme';
import { ARAB_COUNTRIES, EXPERIENCE_OPTIONS, getProvincesByCountry } from '@/constants/arabCountries';
import { getSupabaseClient, useAuth, useAlert } from '@/template';
import { useApp } from '@/hooks/useApp';

interface CraftsmanData {
  id: string;
  name: string;
  specialty: string;
  specialty_icon: string;
  phone: string;
  bio: string;
  skills: string[];
  country: string;
  city: string;
  address_detail: string;
  experience: number;
  rating: number;
  review_count: number;
  completed_jobs: number;
  available: boolean;
  is_online: boolean;
  image_url: string | null;
  price_range: string;
}

type EditSection = 'none' | 'basic' | 'location' | 'bio';

function getRatingStars(rating: number) {
  const full = Math.floor(rating);
  const half = rating - full >= 0.5;
  return { full, half, empty: 5 - full - (half ? 1 : 0) };
}

function getExperienceLabel(years: number): string {
  const opt = [...EXPERIENCE_OPTIONS].reverse().find(e => years >= e.value);
  return opt ? opt.label : `${years} سنة`;
}

export default function CraftsmanProfileScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const { showAlert } = useAlert();
  const supabase = getSupabaseClient();
  const { setOnlineStatus, userRole, roleLoading } = useApp();

  // ── State ──────────────────────────────────────────────────────────────────
  const [craftsman, setCraftsman] = useState<CraftsmanData | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [editSection, setEditSection] = useState<EditSection>('none');
  const [togglingAvail, setTogglingAvail] = useState(false);
  const [uploadingPhoto, setUploadingPhoto] = useState(false);
  const [isOnline, setIsOnline] = useState(false);
  const [togglingOnline, setTogglingOnline] = useState(false);

  // Edit fields
  const [editName, setEditName] = useState('');
  const [editPhone, setEditPhone] = useState('');
  const [editBio, setEditBio] = useState('');
  const [editSkills, setEditSkills] = useState('');
  const [editCountry, setEditCountry] = useState('السعودية');
  const [editProvince, setEditProvince] = useState('');
  const [editAddress, setEditAddress] = useState('');
  const [editExpIndex, setEditExpIndex] = useState(2);

  const provinces = getProvincesByCountry(editCountry);
  const mounted = useRef(true);

  useEffect(() => {
    mounted.current = true;
    return () => { mounted.current = false; };
  }, []);

  // ── Fetch craftsman data directly from DB ──────────────────────────────────
  // Always query by user_id — never rely solely on context state which may
  // still be loading when this screen mounts.
  const fetchCraftsman = useCallback(async () => {
    if (!user) {
      if (mounted.current) setLoading(false);
      return;
    }
    if (mounted.current) setLoading(true);
    try {
      const { data, error } = await supabase
        .from('craftsmen')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle();

      if (!mounted.current) return;

      if (!error && data) {
        setCraftsman(data as CraftsmanData);
        setIsOnline(data.is_online ?? false);
      } else {
        setCraftsman(null);
      }
    } catch (err) {
      console.error('[CraftsmanProfile] fetch error:', err);
      if (mounted.current) setCraftsman(null);
    } finally {
      if (mounted.current) setLoading(false);
    }
  }, [user, supabase]);

  useEffect(() => {
    fetchCraftsman();
  }, [fetchCraftsman]);

  // ── Toggle Online ──────────────────────────────────────────────────────────
  const toggleOnline = async () => {
    if (!craftsman) return;
    setTogglingOnline(true);
    const newVal = !isOnline;
    setIsOnline(newVal);
    await setOnlineStatus(newVal);
    setTogglingOnline(false);
  };

  // ── Toggle Availability ────────────────────────────────────────────────────
  const toggleAvailability = async () => {
    if (!craftsman) return;
    setTogglingAvail(true);
    const newVal = !craftsman.available;
    const { error } = await supabase
      .from('craftsmen')
      .update({ available: newVal, updated_at: new Date().toISOString() })
      .eq('id', craftsman.id);
    if (!error) {
      setCraftsman(prev => prev ? { ...prev, available: newVal } : prev);
    } else {
      showAlert('خطأ', 'لم يتم تحديث حالة التوفر');
    }
    setTogglingAvail(false);
  };

  // ── Photo Upload ───────────────────────────────────────────────────────────
  const pickAndUploadPhoto = async (source: 'camera' | 'gallery') => {
    if (!craftsman || !user) return;
    let result: ImagePicker.ImagePickerResult;

    if (source === 'camera') {
      const { status } = await ImagePicker.requestCameraPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('الكاميرا', 'يرجى السماح للتطبيق باستخدام الكاميرا');
        return;
      }
      result = await ImagePicker.launchCameraAsync({
        mediaTypes: 'images', quality: 0.8, allowsEditing: true, aspect: [1, 1],
      });
    } else {
      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('المعرض', 'يرجى السماح للتطبيق بالوصول إلى المعرض');
        return;
      }
      result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: 'images', quality: 0.8, allowsEditing: true, aspect: [1, 1],
      });
    }

    if (result.canceled || !result.assets?.[0]) return;

    setUploadingPhoto(true);
    try {
      const asset = result.assets[0];
      const ext = (asset.uri.split('.').pop() ?? 'jpg')
        .toLowerCase()
        .replace('jpeg', 'jpg');
      const fileName = `craftsmen/${user.id}-${Date.now()}.${ext}`;

      const response = await fetch(asset.uri);
      const blob = await response.blob();
      const arrayBuffer = await new Response(blob).arrayBuffer();

      const { error: uploadError } = await supabase.storage
        .from('profile-images')
        .upload(fileName, arrayBuffer, {
          contentType: `image/${ext}`,
          upsert: true,
        });

      if (uploadError) throw new Error(uploadError.message);

      const { data: { publicUrl } } = supabase.storage
        .from('profile-images')
        .getPublicUrl(fileName);

      // Cache-busting to force image refresh
      const freshUrl = `${publicUrl}?t=${Date.now()}`;

      const { error: dbError } = await supabase
        .from('craftsmen')
        .update({ image_url: freshUrl })
        .eq('id', craftsman.id);

      if (dbError) throw new Error(dbError.message);

      if (mounted.current) {
        setCraftsman(prev => prev ? { ...prev, image_url: freshUrl } : prev);
        showAlert('تم', 'تم تحديث الصورة بنجاح');
      }
    } catch (err: any) {
      console.error('[CraftsmanProfile] photo upload error:', err);
      if (mounted.current) {
        showAlert('خطأ', 'لم يتم رفع الصورة. تأكد من اتصالك وحاول مجدداً.');
      }
    } finally {
      if (mounted.current) setUploadingPhoto(false);
    }
  };

  const showPhotoOptions = () => {
    Alert.alert('تغيير الصورة', 'اختر المصدر', [
      { text: 'الكاميرا', onPress: () => pickAndUploadPhoto('camera') },
      { text: 'معرض الصور', onPress: () => pickAndUploadPhoto('gallery') },
      { text: 'إلغاء', style: 'cancel' },
    ]);
  };

  // ── Edit Sections ──────────────────────────────────────────────────────────
  const openEdit = (section: EditSection) => {
    if (!craftsman) return;
    if (section === 'basic') {
      setEditName(craftsman.name ?? '');
      setEditPhone(craftsman.phone ?? '');
      const expIdx = EXPERIENCE_OPTIONS.findIndex(
        e => e.value === craftsman.experience,
      );
      setEditExpIndex(expIdx >= 0 ? expIdx : 2);
      setEditSkills(craftsman.skills?.join('، ') ?? '');
    }
    if (section === 'location') {
      setEditCountry(craftsman.country ?? 'السعودية');
      setEditProvince(craftsman.city ?? '');
      setEditAddress(craftsman.address_detail ?? '');
    }
    if (section === 'bio') {
      setEditBio(craftsman.bio ?? '');
    }
    setEditSection(section);
  };

  const saveBasic = async () => {
    if (!craftsman) return;
    if (!editName.trim()) { showAlert('تنبيه', 'الاسم مطلوب'); return; }
    setSaving(true);
    const skillsArr = editSkills.trim()
      ? editSkills.split('،').map(s => s.trim()).filter(Boolean)
      : [];
    const { error } = await supabase
      .from('craftsmen')
      .update({
        name: editName.trim(),
        phone: editPhone.trim(),
        experience: EXPERIENCE_OPTIONS[editExpIndex].value,
        skills: skillsArr,
        updated_at: new Date().toISOString(),
      })
      .eq('id', craftsman.id);
    setSaving(false);
    if (error) { showAlert('خطأ', 'فشل الحفظ، حاول مرة أخرى'); return; }
    setCraftsman(prev =>
      prev
        ? {
            ...prev,
            name: editName.trim(),
            phone: editPhone.trim(),
            experience: EXPERIENCE_OPTIONS[editExpIndex].value,
            skills: skillsArr,
          }
        : prev,
    );
    setEditSection('none');
    showAlert('تم الحفظ', 'تم تحديث بياناتك بنجاح');
  };

  const saveLocation = async () => {
    if (!craftsman) return;
    if (!editProvince) { showAlert('تنبيه', 'يرجى اختيار المحافظة'); return; }
    setSaving(true);
    const { error } = await supabase
      .from('craftsmen')
      .update({
        country: editCountry,
        city: editProvince,
        address_detail: editAddress.trim() || null,
        updated_at: new Date().toISOString(),
      })
      .eq('id', craftsman.id);
    setSaving(false);
    if (error) { showAlert('خطأ', 'فشل الحفظ'); return; }
    setCraftsman(prev =>
      prev
        ? {
            ...prev,
            country: editCountry,
            city: editProvince,
            address_detail: editAddress,
          }
        : prev,
    );
    setEditSection('none');
    showAlert('تم الحفظ', 'تم تحديث الموقع بنجاح');
  };

  const saveBio = async () => {
    if (!craftsman) return;
    setSaving(true);
    const { error } = await supabase
      .from('craftsmen')
      .update({ bio: editBio.trim(), updated_at: new Date().toISOString() })
      .eq('id', craftsman.id);
    setSaving(false);
    if (error) { showAlert('خطأ', 'فشل الحفظ'); return; }
    setCraftsman(prev => prev ? { ...prev, bio: editBio.trim() } : prev);
    setEditSection('none');
    showAlert('تم الحفظ', 'تم تحديث النبذة بنجاح');
  };

  // ── Render: Loading ────────────────────────────────────────────────────────
  // Show loading if either local fetch OR global role check is still running.
  if (loading || roleLoading) {
    return (
      <View style={[styles.container, styles.centered, { paddingTop: insets.top }]}>
        <StatusBar style="light" />
        <ActivityIndicator size="large" color={Colors.gold} />
        <Text style={styles.loadingText}>جاري تحميل ملفك المهني...</Text>
      </View>
    );
  }

  // ── Render: Not a craftsman ────────────────────────────────────────────────
  // Only show "register" screen when loading is fully done AND no craftsman record.
  if (!craftsman) {
    return (
      <View style={[styles.container, { paddingTop: insets.top }]}>
        <StatusBar style="light" />
        <View style={styles.header}>
          <View style={{ width: 40 }} />
          <Text style={styles.headerTitle}>ملفي كحرفي</Text>
          <Pressable style={styles.backBtn} onPress={() => router.back()}>
            <MaterialIcons name="arrow-forward" size={22} color={Colors.text} />
          </Pressable>
        </View>
        <View style={styles.centered}>
          <MaterialIcons name="engineering" size={64} color={Colors.textMuted} />
          <Text style={styles.emptyTitle}>لم تسجّل كحرفي بعد</Text>
          <Text style={styles.emptyText}>
            سجّل الآن وابدأ استقبال الطلبات فوراً
          </Text>
          <Pressable
            style={styles.registerBtn}
            onPress={() => router.replace('/craftsman-register' as any)}
          >
            <MaterialIcons name="add-circle" size={18} color={Colors.primary} />
            <Text style={styles.registerBtnText}>سجّل كحرفي معتمد</Text>
          </Pressable>
        </View>
      </View>
    );
  }

  // ── Render: Craftsman profile ──────────────────────────────────────────────
  const stars = getRatingStars(craftsman.rating ?? 0);
  const countryFlag =
    ARAB_COUNTRIES.find(c => c.name === craftsman.country)?.flag ?? '';
  const expLabel = getExperienceLabel(craftsman.experience ?? 1);
  const craftsmanImgSrc =
    craftsman.image_url ??
    'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400';

  return (
    <KeyboardAvoidingView
      style={{ flex: 1 }}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <View style={[styles.container, { paddingTop: insets.top }]}>
        <StatusBar style="light" />

        {/* Header */}
        <View style={styles.header}>
          <Pressable
            style={styles.refreshBtn}
            onPress={fetchCraftsman}
          >
            <MaterialIcons name="refresh" size={20} color={Colors.gold} />
          </Pressable>
          <Text style={styles.headerTitle}>ملفي كحرفي</Text>
          <Pressable style={styles.backBtn} onPress={() => router.back()}>
            <MaterialIcons name="arrow-forward" size={22} color={Colors.text} />
          </Pressable>
        </View>

        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingBottom: insets.bottom + 40 }}
          keyboardShouldPersistTaps="handled"
        >
          {/* ── Profile Card ── */}
          <View style={styles.profileCard}>
            <Pressable
              style={styles.photoWrapper}
              onPress={showPhotoOptions}
              disabled={uploadingPhoto}
            >
              {uploadingPhoto ? (
                <View style={styles.photoLoading}>
                  <ActivityIndicator color={Colors.gold} size="large" />
                </View>
              ) : (
                <Image
                  key={craftsmanImgSrc}
                  source={{ uri: craftsmanImgSrc }}
                  style={styles.photo}
                  contentFit="cover"
                  transition={200}
                  cachePolicy="none"
                />
              )}
              <View style={styles.cameraBadge}>
                <MaterialIcons name="photo-camera" size={14} color={Colors.text} />
              </View>
              <View
                style={[
                  styles.onlineDot,
                  { backgroundColor: isOnline ? Colors.success : Colors.textMuted },
                ]}
              />
            </Pressable>

            <View style={styles.profileInfo}>
              <Text style={styles.craftsmanName}>{craftsman.name}</Text>
              <Text style={styles.specialty}>{craftsman.specialty}</Text>
              <Text style={styles.location}>
                {countryFlag} {craftsman.country} — {craftsman.city}
              </Text>
              <View style={styles.starsRow}>
                {Array.from({ length: stars.full }).map((_, i) => (
                  <MaterialIcons key={`f${i}`} name="star" size={15} color={Colors.gold} />
                ))}
                {stars.half ? (
                  <MaterialIcons name="star-half" size={15} color={Colors.gold} />
                ) : null}
                {Array.from({ length: stars.empty }).map((_, i) => (
                  <MaterialIcons key={`e${i}`} name="star-border" size={15} color={Colors.textMuted} />
                ))}
                <Text style={styles.ratingText}>
                  {(craftsman.rating ?? 0).toFixed(1)}
                </Text>
                <Text style={styles.reviewCount}>({craftsman.review_count ?? 0})</Text>
              </View>
            </View>
          </View>

          {/* ── Stats ── */}
          <View style={styles.statsRow}>
            {[
              {
                icon: 'check-circle',
                value: craftsman.completed_jobs ?? 0,
                label: 'مكتمل',
                color: Colors.success,
                bg: 'rgba(46,204,113,0.08)',
              },
              {
                icon: 'star',
                value: (craftsman.rating ?? 0).toFixed(1),
                label: 'التقييم',
                color: Colors.gold,
                bg: Colors.goldSoft,
              },
              {
                icon: 'rate-review',
                value: craftsman.review_count ?? 0,
                label: 'تقييمات',
                color: Colors.info,
                bg: 'rgba(52,152,219,0.08)',
              },
            ].map((s, i) => (
              <View
                key={i}
                style={[
                  styles.statCard,
                  { backgroundColor: s.bg, borderColor: `${s.color}22` },
                ]}
              >
                <MaterialIcons name={s.icon as any} size={22} color={s.color} />
                <Text style={[styles.statValue, { color: s.color }]}>{s.value}</Text>
                <Text style={styles.statLabel}>{s.label}</Text>
              </View>
            ))}
          </View>

          {/* ── Online Status Toggle ── */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>حالة الاتصال</Text>
            <View style={styles.toggleCard}>
              <View style={styles.toggleRight}>
                {togglingOnline ? (
                  <ActivityIndicator size="small" color={Colors.success} />
                ) : (
                  <Switch
                    value={isOnline}
                    onValueChange={toggleOnline}
                    trackColor={{
                      false: 'rgba(100,100,100,0.25)',
                      true: 'rgba(46,204,113,0.4)',
                    }}
                    thumbColor={isOnline ? Colors.success : Colors.textMuted}
                  />
                )}
              </View>
              <View style={styles.toggleLeft}>
                <View style={styles.toggleTitleRow}>
                  <View
                    style={[
                      styles.statusDot,
                      {
                        backgroundColor: isOnline
                          ? Colors.success
                          : Colors.textMuted,
                      },
                    ]}
                  />
                  <Text style={styles.toggleTitle}>
                    {isOnline ? 'متصل الآن' : 'غير متصل'}
                  </Text>
                </View>
                <Text style={styles.toggleSub}>
                  {isOnline
                    ? 'يظهر للعملاء أنك نشط ومتاح للتواصل'
                    : 'لن يظهر وضع اتصالك للعملاء'}
                </Text>
              </View>
            </View>
          </View>

          {/* ── Availability Toggle ── */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>قبول الطلبات</Text>
            <View style={styles.toggleCard}>
              <View style={styles.toggleRight}>
                {togglingAvail ? (
                  <ActivityIndicator size="small" color={Colors.gold} />
                ) : (
                  <Switch
                    value={craftsman.available ?? false}
                    onValueChange={toggleAvailability}
                    trackColor={{
                      false: 'rgba(231,76,60,0.3)',
                      true: 'rgba(46,204,113,0.4)',
                    }}
                    thumbColor={
                      craftsman.available ? Colors.success : Colors.error
                    }
                  />
                )}
              </View>
              <View style={styles.toggleLeft}>
                <View style={styles.toggleTitleRow}>
                  <View
                    style={[
                      styles.statusDot,
                      {
                        backgroundColor: craftsman.available
                          ? Colors.success
                          : Colors.error,
                      },
                    ]}
                  />
                  <Text style={styles.toggleTitle}>
                    {craftsman.available ? 'متاح للعمل' : 'غير متاح حالياً'}
                  </Text>
                </View>
                <Text style={styles.toggleSub}>
                  {craftsman.available
                    ? 'ملفك ظاهر وتستقبل الطلبات الجديدة'
                    : 'ملفك مخفي مؤقتاً — لن تتلقى طلبات جديدة'}
                </Text>
              </View>
            </View>
          </View>

          {/* ── Professional Data ── */}
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Pressable
                style={styles.editBtn}
                onPress={() => openEdit('basic')}
              >
                <MaterialIcons name="edit" size={14} color={Colors.gold} />
                <Text style={styles.editBtnText}>تعديل</Text>
              </Pressable>
              <Text style={styles.sectionTitle}>البيانات المهنية</Text>
            </View>

            {editSection === 'basic' ? (
              <View style={styles.editCard}>
                <View style={styles.inputGroup}>
                  <Text style={styles.inputLabel}>الاسم الكامل *</Text>
                  <View style={styles.inputRow}>
                    <TextInput
                      style={styles.input}
                      value={editName}
                      onChangeText={setEditName}
                      placeholder="اسمك الكامل"
                      placeholderTextColor={Colors.textMuted}
                      textAlign="right"
                    />
                    <MaterialIcons name="person" size={18} color={Colors.textMuted} />
                  </View>
                </View>
                <View style={styles.inputGroup}>
                  <Text style={styles.inputLabel}>رقم الجوال</Text>
                  <View style={styles.inputRow}>
                    <TextInput
                      style={styles.input}
                      value={editPhone}
                      onChangeText={setEditPhone}
                      placeholder="+966 5XX XXX XXX"
                      placeholderTextColor={Colors.textMuted}
                      textAlign="right"
                      keyboardType="phone-pad"
                    />
                    <MaterialIcons name="phone" size={18} color={Colors.textMuted} />
                  </View>
                </View>
                <View style={styles.inputGroup}>
                  <Text style={styles.inputLabel}>سنوات الخبرة</Text>
                  <View style={styles.chipGrid}>
                    {EXPERIENCE_OPTIONS.map((exp, i) => (
                      <Pressable
                        key={i}
                        style={[styles.chip, editExpIndex === i && styles.chipActive]}
                        onPress={() => setEditExpIndex(i)}
                      >
                        <Text
                          style={[
                            styles.chipText,
                            editExpIndex === i && styles.chipTextActive,
                          ]}
                        >
                          {exp.label}
                        </Text>
                      </Pressable>
                    ))}
                  </View>
                </View>
                <View style={styles.inputGroup}>
                  <Text style={styles.inputLabel}>المهارات (افصل بـ ،)</Text>
                  <TextInput
                    style={[styles.input, styles.bioInput]}
                    value={editSkills}
                    onChangeText={setEditSkills}
                    placeholder="مثال: إصلاح كهرباء، تمديد أسلاك"
                    placeholderTextColor={Colors.textMuted}
                    textAlign="right"
                    multiline
                    numberOfLines={2}
                    textAlignVertical="top"
                  />
                </View>
                <View style={styles.editActions}>
                  <Pressable
                    style={styles.cancelEditBtn}
                    onPress={() => setEditSection('none')}
                  >
                    <Text style={styles.cancelEditText}>إلغاء</Text>
                  </Pressable>
                  <Pressable
                    style={styles.saveEditBtn}
                    onPress={saveBasic}
                    disabled={saving}
                  >
                    {saving ? (
                      <ActivityIndicator size="small" color={Colors.primary} />
                    ) : (
                      <Text style={styles.saveEditText}>حفظ</Text>
                    )}
                  </Pressable>
                </View>
              </View>
            ) : (
              <View style={styles.infoCard}>
                <InfoRow icon="work" label="الخبرة" value={expLabel} />
                <InfoRow
                  icon="phone"
                  label="الجوال"
                  value={craftsman.phone || 'غير محدد'}
                  divider
                />
                {(craftsman.skills?.length ?? 0) > 0 && (
                  <View style={styles.skillsRow}>
                    <View style={styles.skillsWrap}>
                      {craftsman.skills.map((sk, i) => (
                        <View key={i} style={styles.skillTag}>
                          <Text style={styles.skillText}>{sk}</Text>
                        </View>
                      ))}
                    </View>
                    <View style={styles.skillsLabel}>
                      <Text style={styles.skillsLabelText}>المهارات</Text>
                      <MaterialIcons name="build" size={15} color={Colors.gold} />
                    </View>
                  </View>
                )}
              </View>
            )}
          </View>

          {/* ── Location ── */}
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Pressable
                style={styles.editBtn}
                onPress={() => openEdit('location')}
              >
                <MaterialIcons name="edit" size={14} color={Colors.gold} />
                <Text style={styles.editBtnText}>تعديل</Text>
              </Pressable>
              <Text style={styles.sectionTitle}>الموقع</Text>
            </View>

            {editSection === 'location' ? (
              <View style={styles.editCard}>
                <View style={styles.inputGroup}>
                  <Text style={styles.inputLabel}>الدولة *</Text>
                  <ScrollView
                    horizontal
                    showsHorizontalScrollIndicator={false}
                    contentContainerStyle={{ gap: Spacing.sm }}
                  >
                    {ARAB_COUNTRIES.map(c => (
                      <Pressable
                        key={c.name}
                        style={[
                          styles.chip,
                          editCountry === c.name && styles.chipActive,
                        ]}
                        onPress={() => {
                          setEditCountry(c.name);
                          setEditProvince('');
                        }}
                      >
                        <Text
                          style={[
                            styles.chipText,
                            editCountry === c.name && styles.chipTextActive,
                          ]}
                        >
                          {c.flag} {c.name}
                        </Text>
                      </Pressable>
                    ))}
                  </ScrollView>
                </View>
                <View style={styles.inputGroup}>
                  <Text style={styles.inputLabel}>المحافظة *</Text>
                  <View style={styles.chipGrid}>
                    {provinces.map(p => (
                      <Pressable
                        key={p}
                        style={[styles.chip, editProvince === p && styles.chipActive]}
                        onPress={() => setEditProvince(p)}
                      >
                        <Text
                          style={[
                            styles.chipText,
                            editProvince === p && styles.chipTextActive,
                          ]}
                        >
                          {p}
                        </Text>
                      </Pressable>
                    ))}
                  </View>
                </View>
                <View style={styles.inputGroup}>
                  <Text style={styles.inputLabel}>العنوان التفصيلي (اختياري)</Text>
                  <TextInput
                    style={[styles.input, styles.bioInput]}
                    value={editAddress}
                    onChangeText={setEditAddress}
                    placeholder="حي، شارع..."
                    placeholderTextColor={Colors.textMuted}
                    textAlign="right"
                    multiline
                    numberOfLines={2}
                    textAlignVertical="top"
                  />
                </View>
                <View style={styles.editActions}>
                  <Pressable
                    style={styles.cancelEditBtn}
                    onPress={() => setEditSection('none')}
                  >
                    <Text style={styles.cancelEditText}>إلغاء</Text>
                  </Pressable>
                  <Pressable
                    style={styles.saveEditBtn}
                    onPress={saveLocation}
                    disabled={saving}
                  >
                    {saving ? (
                      <ActivityIndicator size="small" color={Colors.primary} />
                    ) : (
                      <Text style={styles.saveEditText}>حفظ</Text>
                    )}
                  </Pressable>
                </View>
              </View>
            ) : (
              <View style={styles.infoCard}>
                <InfoRow
                  icon="location-on"
                  label="الموقع"
                  value={`${countryFlag} ${craftsman.country} — ${craftsman.city}`}
                />
                {craftsman.address_detail ? (
                  <InfoRow
                    icon="place"
                    label="العنوان"
                    value={craftsman.address_detail}
                    divider
                  />
                ) : null}
              </View>
            )}
          </View>

          {/* ── Bio ── */}
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Pressable
                style={styles.editBtn}
                onPress={() => openEdit('bio')}
              >
                <MaterialIcons name="edit" size={14} color={Colors.gold} />
                <Text style={styles.editBtnText}>تعديل</Text>
              </Pressable>
              <Text style={styles.sectionTitle}>نبذة عني</Text>
            </View>

            {editSection === 'bio' ? (
              <View style={styles.editCard}>
                <TextInput
                  style={[styles.input, styles.bioInput, { minHeight: 110 }]}
                  value={editBio}
                  onChangeText={setEditBio}
                  placeholder="اكتب نبذة مختصرة تعرّف بك وبخبرتك..."
                  placeholderTextColor={Colors.textMuted}
                  textAlign="right"
                  multiline
                  numberOfLines={5}
                  textAlignVertical="top"
                />
                <View style={styles.editActions}>
                  <Pressable
                    style={styles.cancelEditBtn}
                    onPress={() => setEditSection('none')}
                  >
                    <Text style={styles.cancelEditText}>إلغاء</Text>
                  </Pressable>
                  <Pressable
                    style={styles.saveEditBtn}
                    onPress={saveBio}
                    disabled={saving}
                  >
                    {saving ? (
                      <ActivityIndicator size="small" color={Colors.primary} />
                    ) : (
                      <Text style={styles.saveEditText}>حفظ</Text>
                    )}
                  </Pressable>
                </View>
              </View>
            ) : (
              <View style={styles.bioCard}>
                <Text style={styles.bioText}>
                  {craftsman.bio?.trim() ||
                    'لم تكتب نبذة بعد — اضغط تعديل لإضافتها'}
                </Text>
              </View>
            )}
          </View>

          {/* ── View Public Profile ── */}
          <View style={[styles.section, { marginTop: Spacing.sm }]}>
            <Pressable
              style={styles.viewProfileBtn}
              onPress={() =>
                router.push(`/craftsmen/${craftsman.id}` as any)
              }
            >
              <MaterialIcons name="open-in-new" size={16} color={Colors.gold} />
              <Text style={styles.viewProfileText}>
                عرض الملف كما يراه العملاء
              </Text>
            </Pressable>
          </View>
        </ScrollView>
      </View>
    </KeyboardAvoidingView>
  );
}

// ── Info Row Helper ────────────────────────────────────────────────────────────
function InfoRow({
  icon, label, value, divider,
}: {
  icon: string; label: string; value: string; divider?: boolean;
}) {
  return (
    <View style={[infoRowSt.row, divider && infoRowSt.divider]}>
      <Text style={infoRowSt.value}>{value}</Text>
      <View style={infoRowSt.label}>
        <Text style={infoRowSt.labelText}>{label}</Text>
        <MaterialIcons name={icon as any} size={15} color={Colors.gold} />
      </View>
    </View>
  );
}

const infoRowSt = StyleSheet.create({
  row: {
    flexDirection: 'row', alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 12, paddingHorizontal: Spacing.md,
  },
  divider: { borderTopWidth: 1, borderTopColor: Colors.divider },
  label: { flexDirection: 'row', alignItems: 'center', gap: 6, minWidth: 80 },
  labelText: { fontSize: FontSize.sm, color: Colors.textMuted },
  value: {
    fontSize: FontSize.sm, color: Colors.text,
    fontWeight: FontWeight.medium, flex: 1, textAlign: 'right',
  },
});

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  centered: {
    flex: 1, alignItems: 'center', justifyContent: 'center',
    gap: Spacing.md, paddingHorizontal: Spacing.xl,
  },
  loadingText: { color: Colors.textMuted, fontSize: FontSize.base },

  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: Spacing.md, paddingVertical: Spacing.md,
    borderBottomWidth: 1, borderBottomColor: Colors.divider,
  },
  headerTitle: {
    fontSize: FontSize.xl, fontWeight: FontWeight.bold, color: Colors.text,
  },
  backBtn: {
    width: 40, height: 40, borderRadius: 20,
    backgroundColor: Colors.surface,
    alignItems: 'center', justifyContent: 'center',
  },
  refreshBtn: {
    width: 40, height: 40, borderRadius: 20,
    backgroundColor: Colors.goldSoft,
    alignItems: 'center', justifyContent: 'center',
  },

  emptyTitle: {
    fontSize: FontSize.xxl, fontWeight: FontWeight.bold, color: Colors.text,
  },
  emptyText: {
    fontSize: FontSize.base, color: Colors.textMuted,
    textAlign: 'center', lineHeight: 24,
  },
  registerBtn: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.sm,
    backgroundColor: Colors.gold, borderRadius: Radius.lg,
    paddingVertical: 14, paddingHorizontal: Spacing.xl, ...Shadow.gold,
  },
  registerBtnText: {
    fontSize: FontSize.base, fontWeight: FontWeight.bold, color: Colors.primary,
  },

  profileCard: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.md,
    backgroundColor: Colors.surface, padding: Spacing.md,
    borderBottomWidth: 1, borderBottomColor: Colors.divider,
  },
  photoWrapper: { position: 'relative' },
  photo: {
    width: 90, height: 90, borderRadius: 45,
    borderWidth: 2.5, borderColor: Colors.gold,
  },
  photoLoading: {
    width: 90, height: 90, borderRadius: 45,
    borderWidth: 2.5, borderColor: Colors.gold,
    backgroundColor: Colors.surface2,
    alignItems: 'center', justifyContent: 'center',
  },
  cameraBadge: {
    position: 'absolute', bottom: 2, right: 2,
    width: 26, height: 26, borderRadius: 13,
    backgroundColor: Colors.gold,
    alignItems: 'center', justifyContent: 'center',
    borderWidth: 2, borderColor: Colors.background,
  },
  onlineDot: {
    position: 'absolute', top: 4, left: 4,
    width: 14, height: 14, borderRadius: 7,
    borderWidth: 2, borderColor: Colors.background,
  },
  profileInfo: { flex: 1, alignItems: 'flex-end', gap: 4 },
  craftsmanName: {
    fontSize: FontSize.xl, fontWeight: FontWeight.bold,
    color: Colors.text, textAlign: 'right',
  },
  specialty: { fontSize: FontSize.sm, color: Colors.gold },
  location: { fontSize: FontSize.xs, color: Colors.textMuted },
  starsRow: { flexDirection: 'row', alignItems: 'center', gap: 2, marginTop: 2 },
  ratingText: {
    fontSize: FontSize.sm, fontWeight: FontWeight.bold,
    color: Colors.gold, marginLeft: 3,
  },
  reviewCount: { fontSize: FontSize.xs, color: Colors.textMuted, marginLeft: 2 },

  statsRow: {
    flexDirection: 'row', gap: Spacing.sm,
    paddingHorizontal: Spacing.lg, paddingVertical: Spacing.lg,
  },
  statCard: {
    flex: 1, borderRadius: Radius.lg, paddingVertical: Spacing.md,
    alignItems: 'center', gap: 5, borderWidth: 1,
  },
  statValue: { fontSize: FontSize.xl, fontWeight: FontWeight.bold },
  statLabel: { fontSize: 10, color: Colors.textMuted, textAlign: 'center' },

  section: { paddingHorizontal: Spacing.lg, marginBottom: Spacing.md },
  sectionHeader: {
    flexDirection: 'row', alignItems: 'center',
    justifyContent: 'space-between', marginBottom: Spacing.sm,
  },
  sectionTitle: {
    fontSize: FontSize.base, fontWeight: FontWeight.bold,
    color: Colors.text, marginBottom: Spacing.sm,
  },
  editBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: Colors.goldSoft, borderRadius: Radius.full,
    paddingHorizontal: 10, paddingVertical: 5,
    borderWidth: 1, borderColor: 'rgba(212,160,23,0.25)',
  },
  editBtnText: {
    fontSize: FontSize.xs, color: Colors.gold, fontWeight: FontWeight.semibold,
  },

  toggleCard: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.md,
    backgroundColor: Colors.surface, borderRadius: Radius.xl,
    padding: Spacing.md, borderWidth: 1, borderColor: Colors.border, ...Shadow.sm,
  },
  toggleRight: { flexShrink: 0 },
  toggleLeft: { flex: 1, alignItems: 'flex-end', gap: 4 },
  toggleTitleRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  statusDot: { width: 10, height: 10, borderRadius: 5 },
  toggleTitle: {
    fontSize: FontSize.base, fontWeight: FontWeight.bold, color: Colors.text,
  },
  toggleSub: {
    fontSize: FontSize.xs, color: Colors.textMuted,
    textAlign: 'right', lineHeight: 18,
  },

  infoCard: {
    backgroundColor: Colors.surface, borderRadius: Radius.xl,
    borderWidth: 1, borderColor: Colors.border, overflow: 'hidden',
  },
  skillsRow: {
    flexDirection: 'row', alignItems: 'flex-start',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.md, paddingVertical: 12,
    borderTopWidth: 1, borderTopColor: Colors.divider,
  },
  skillsWrap: {
    flex: 1, flexDirection: 'row', flexWrap: 'wrap',
    gap: 6, justifyContent: 'flex-end', marginLeft: Spacing.md,
  },
  skillTag: {
    backgroundColor: Colors.goldSoft, borderRadius: Radius.full,
    paddingHorizontal: 9, paddingVertical: 4,
    borderWidth: 1, borderColor: 'rgba(212,160,23,0.2)',
  },
  skillText: { fontSize: 11, color: Colors.gold, fontWeight: FontWeight.medium },
  skillsLabel: {
    flexDirection: 'row', alignItems: 'center', gap: 6, flexShrink: 0,
  },
  skillsLabelText: { fontSize: FontSize.sm, color: Colors.textMuted },

  bioCard: {
    backgroundColor: Colors.surface, borderRadius: Radius.xl,
    borderWidth: 1, borderColor: Colors.border, padding: Spacing.md,
  },
  bioText: {
    fontSize: FontSize.base, color: Colors.textMuted,
    textAlign: 'right', lineHeight: 26,
  },

  editCard: {
    backgroundColor: Colors.surface, borderRadius: Radius.xl,
    borderWidth: 1, borderColor: 'rgba(212,160,23,0.3)',
    padding: Spacing.md, gap: Spacing.md,
  },
  inputGroup: { gap: Spacing.sm },
  inputLabel: {
    fontSize: FontSize.xs, color: Colors.textMuted,
    textAlign: 'right', fontWeight: FontWeight.medium,
  },
  inputRow: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: Colors.surface2, borderRadius: Radius.md,
    borderWidth: 1, borderColor: Colors.border,
    paddingHorizontal: Spacing.md, paddingVertical: 12, gap: Spacing.sm,
  },
  input: { flex: 1, color: Colors.text, fontSize: FontSize.base },
  bioInput: {
    backgroundColor: Colors.surface2, borderRadius: Radius.md,
    borderWidth: 1, borderColor: Colors.border,
    paddingHorizontal: Spacing.md, paddingVertical: 10,
    color: Colors.text, fontSize: FontSize.base, minHeight: 70,
  },
  chipGrid: {
    flexDirection: 'row', flexWrap: 'wrap',
    gap: Spacing.sm, justifyContent: 'flex-end',
  },
  chip: {
    paddingHorizontal: 12, paddingVertical: 7,
    backgroundColor: Colors.surface2, borderRadius: Radius.full,
    borderWidth: 1, borderColor: Colors.border,
  },
  chipActive: { backgroundColor: Colors.gold, borderColor: Colors.gold },
  chipText: {
    fontSize: FontSize.xs, color: Colors.textMuted, fontWeight: FontWeight.medium,
  },
  chipTextActive: { color: Colors.primary, fontWeight: FontWeight.bold },
  editActions: { flexDirection: 'row', gap: Spacing.sm, marginTop: Spacing.sm },
  cancelEditBtn: {
    flex: 1, paddingVertical: 11, borderRadius: Radius.md,
    backgroundColor: Colors.surface2,
    alignItems: 'center', justifyContent: 'center',
    borderWidth: 1, borderColor: Colors.border,
  },
  cancelEditText: {
    fontSize: FontSize.sm, color: Colors.textMuted, fontWeight: FontWeight.medium,
  },
  saveEditBtn: {
    flex: 2, paddingVertical: 11, borderRadius: Radius.md,
    backgroundColor: Colors.gold,
    alignItems: 'center', justifyContent: 'center', ...Shadow.gold,
  },
  saveEditText: {
    fontSize: FontSize.base, fontWeight: FontWeight.bold, color: Colors.primary,
  },

  viewProfileBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    gap: Spacing.sm, backgroundColor: Colors.goldSoft, borderRadius: Radius.lg,
    paddingVertical: 13,
    borderWidth: 1, borderColor: 'rgba(212,160,23,0.3)',
  },
  viewProfileText: {
    fontSize: FontSize.base, color: Colors.gold, fontWeight: FontWeight.semibold,
  },
});
