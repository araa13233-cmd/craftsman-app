import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, StyleSheet, ScrollView, Pressable,
  FlatList, Dimensions, ActivityIndicator,
} from 'react-native';
import { useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import { Colors, FontSize, FontWeight, Radius, Spacing, Shadow } from '@/constants/theme';
import { useAlert, getSupabaseClient } from '@/template';

const { width } = Dimensions.get('window');

const TABS = [
  { key: 'overview', label: 'نظرة عامة', icon: 'dashboard' },
  { key: 'craftsmen', label: 'الحرفيون', icon: 'engineering' },
  { key: 'orders', label: 'الطلبات', icon: 'list-alt' },
  { key: 'revenue', label: 'الأرباح', icon: 'attach-money' },
];

const MONTHLY_REVENUE = [
  { month: 'يناير', revenue: 12_000, commissions: 1_200 },
  { month: 'فبراير', revenue: 14_500, commissions: 1_450 },
  { month: 'مارس', revenue: 11_800, commissions: 1_180 },
  { month: 'أبريل', revenue: 16_200, commissions: 1_620 },
  { month: 'مايو', revenue: 15_400, commissions: 1_540 },
  { month: 'يونيو', revenue: 18_340, commissions: 1_834 },
];

const STATUS_CONFIG: Record<string, { color: string; label: string; bg: string }> = {
  pending:     { color: Colors.warning, label: 'انتظار', bg: 'rgba(243,156,18,0.12)' },
  in_progress: { color: Colors.info,    label: 'جاري',   bg: 'rgba(52,152,219,0.12)' },
  completed:   { color: Colors.success, label: 'مكتمل',  bg: 'rgba(46,204,113,0.12)' },
  cancelled:   { color: Colors.error,   label: 'ملغي',   bg: 'rgba(231,76,60,0.12)'  },
};

// ─── Sub-Components ────────────────────────────────────────────────────────────
const StatCard = ({ icon, label, value, sub, color, trend }: any) => (
  <View style={statStyles.card}>
    <View style={[statStyles.iconBox, { backgroundColor: color + '20' }]}>
      <MaterialIcons name={icon} size={22} color={color} />
    </View>
    <View style={statStyles.info}>
      <Text style={statStyles.value}>{typeof value === 'number' ? value.toLocaleString('ar-SA') : value}</Text>
      <Text style={statStyles.label}>{label}</Text>
      {sub ? <Text style={[statStyles.sub, { color: trend === 'up' ? Colors.success : Colors.textMuted }]}>{sub}</Text> : null}
    </View>
  </View>
);

const statStyles = StyleSheet.create({
  card: {
    flex: 1, minWidth: (width - Spacing.lg * 2 - Spacing.sm) / 2,
    backgroundColor: Colors.surface, borderRadius: Radius.lg,
    borderWidth: 1, borderColor: Colors.border, ...Shadow.sm,
    padding: Spacing.md, flexDirection: 'row', alignItems: 'center', gap: Spacing.md,
  },
  iconBox: { width: 46, height: 46, borderRadius: Radius.md, alignItems: 'center', justifyContent: 'center' },
  info: { flex: 1, gap: 2, alignItems: 'flex-end' },
  value: { fontSize: FontSize.xl, fontWeight: FontWeight.bold, color: Colors.text },
  label: { fontSize: FontSize.xs, color: Colors.textMuted, textAlign: 'right' },
  sub: { fontSize: 10, fontWeight: FontWeight.semibold },
});

const BarChart = ({ data, maxVal }: { data: typeof MONTHLY_REVENUE; maxVal: number }) => (
  <View style={chartStyles.container}>
    {data.map((item, i) => {
      const revenueH = Math.max(4, (item.revenue / maxVal) * 120);
      const commH = Math.max(4, (item.commissions / maxVal) * 120);
      return (
        <View key={i} style={chartStyles.barGroup}>
          <View style={chartStyles.bars}>
            <View style={[chartStyles.bar, { height: revenueH, backgroundColor: Colors.gold }]} />
            <View style={[chartStyles.bar, { height: commH, backgroundColor: Colors.info }]} />
          </View>
          <Text style={chartStyles.barLabel}>{item.month.slice(0, 3)}</Text>
        </View>
      );
    })}
  </View>
);

const chartStyles = StyleSheet.create({
  container: { flexDirection: 'row', alignItems: 'flex-end', justifyContent: 'space-between', height: 140, paddingBottom: 24 },
  barGroup: { alignItems: 'center', gap: 4, flex: 1 },
  bars: { flexDirection: 'row', gap: 2, alignItems: 'flex-end' },
  bar: { width: 10, borderRadius: 4, minHeight: 4 },
  barLabel: { fontSize: 9, color: Colors.textMuted, textAlign: 'center' },
});

// ─── Main Component ────────────────────────────────────────────────────────────
export default function AdminDashboard() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { showAlert } = useAlert();
  const supabase = getSupabaseClient();

  const [activeTab, setActiveTab] = useState('overview');
  const [loading, setLoading] = useState(true);

  // Real stats from DB
  const [stats, setStats] = useState({
    totalOrders: 0, pendingOrders: 0, activeOrders: 0,
    completedOrders: 0, cancelledOrders: 0,
    totalCraftsmen: 0, pendingCraftsmen: 0, approvedCraftsmen: 0,
  });
  const [pendingCraftsmenList, setPendingCraftsmenList] = useState<any[]>([]);
  const [recentOrders, setRecentOrders] = useState<any[]>([]);

  const fetchStats = useCallback(async () => {
    setLoading(true);
    try {
      // Orders stats
      const { data: orders } = await supabase
        .from('orders').select('id, status, service_type, craftsman_name, price, created_at');

      if (orders) {
        setStats(prev => ({
          ...prev,
          totalOrders: orders.length,
          pendingOrders: orders.filter(o => o.status === 'pending').length,
          activeOrders: orders.filter(o => o.status === 'in_progress').length,
          completedOrders: orders.filter(o => o.status === 'completed').length,
          cancelledOrders: orders.filter(o => o.status === 'cancelled').length,
        }));
        setRecentOrders(orders.slice(0, 8).map(o => ({
          id: o.id,
          service: o.service_type,
          craftsman: o.craftsman_name ?? 'غير معيّن',
          status: o.status,
          price: o.price ?? 'غير محدد',
          time: new Date(o.created_at).toLocaleDateString('ar-SA', { day: 'numeric', month: 'short' }),
        })));
      }

      // Craftsmen stats
      const { data: craftsmen } = await supabase
        .from('craftsmen')
        .select('id, name, specialty, city, experience, phone, image_url, is_approved, created_at, rating');

      if (craftsmen) {
        const pending = craftsmen.filter(c => !c.is_approved);
        const approved = craftsmen.filter(c => c.is_approved);
        setStats(prev => ({
          ...prev,
          totalCraftsmen: craftsmen.length,
          pendingCraftsmen: pending.length,
          approvedCraftsmen: approved.length,
        }));
        setPendingCraftsmenList(pending.map(c => ({
          id: c.id,
          name: c.name,
          specialty: c.specialty,
          city: c.city,
          experience: c.experience,
          phone: c.phone,
          image: c.image_url ?? 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400',
          submitted: new Date(c.created_at).toLocaleDateString('ar-SA'),
          rating: c.rating ?? 0,
        })));
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchStats(); }, [fetchStats]);

  const handleApprove = (id: string, name: string) => {
    showAlert('تأكيد الموافقة', `هل تريد قبول ${name} كحرفي معتمد؟`, [
      { text: 'إلغاء', style: 'cancel' },
      {
        text: 'موافقة', onPress: async () => {
          await supabase.from('craftsmen').update({ is_approved: true }).eq('id', id);
          setPendingCraftsmenList(prev => prev.filter(c => c.id !== id));
          setStats(prev => ({
            ...prev,
            pendingCraftsmen: prev.pendingCraftsmen - 1,
            approvedCraftsmen: prev.approvedCraftsmen + 1,
          }));
          showAlert('تمت الموافقة', `تم قبول ${name} كحرفي معتمد ✓`);
        },
      },
    ]);
  };

  const handleReject = (id: string, name: string) => {
    showAlert('رفض الطلب', `هل تريد رفض طلب ${name}؟`, [
      { text: 'إلغاء', style: 'cancel' },
      {
        text: 'رفض', style: 'destructive', onPress: async () => {
          await supabase.from('craftsmen').update({ is_active: false }).eq('id', id);
          setPendingCraftsmenList(prev => prev.filter(c => c.id !== id));
          setStats(prev => ({
            ...prev,
            pendingCraftsmen: prev.pendingCraftsmen - 1,
          }));
        },
      },
    ]);
  };

  const maxRevenue = Math.max(...MONTHLY_REVENUE.map(d => d.revenue));

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <StatusBar style="light" />

      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerLeft}>
          <View style={styles.adminBadge}>
            <MaterialIcons name="admin-panel-settings" size={14} color={Colors.primary} />
            <Text style={styles.adminBadgeText}>Admin</Text>
          </View>
        </View>
        <Text style={styles.headerTitle}>لوحة التحكم</Text>
        <Pressable style={styles.backBtn} onPress={() => router.back()}>
          <MaterialIcons name="arrow-forward" size={22} color={Colors.text} />
        </Pressable>
      </View>

      {/* Tab Bar */}
      <ScrollView
        horizontal showsHorizontalScrollIndicator={false}
        style={styles.tabsScroll} contentContainerStyle={styles.tabsContent}
      >
        {TABS.map(tab => (
          <Pressable
            key={tab.key}
            style={[styles.tabBtn, activeTab === tab.key && styles.tabBtnActive]}
            onPress={() => setActiveTab(tab.key)}
          >
            <MaterialIcons
              name={tab.icon as any}
              size={16}
              color={activeTab === tab.key ? Colors.primary : Colors.textMuted}
            />
            <Text style={[styles.tabText, activeTab === tab.key && styles.tabTextActive]}>
              {tab.label}
            </Text>
            {tab.key === 'craftsmen' && stats.pendingCraftsmen > 0 && (
              <View style={styles.tabBadge}>
                <Text style={styles.tabBadgeText}>{stats.pendingCraftsmen}</Text>
              </View>
            )}
          </Pressable>
        ))}
      </ScrollView>

      {loading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={Colors.gold} />
          <Text style={styles.loadingText}>جاري تحميل البيانات...</Text>
        </View>
      ) : (
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={[styles.content, { paddingBottom: insets.bottom + 24 }]}
          onScrollToTop={() => fetchStats()}
        >
          {/* ── Overview ── */}
          {activeTab === 'overview' && (
            <View style={styles.section}>
              <View style={styles.todayBanner}>
                <Pressable style={styles.refreshBtn} onPress={fetchStats}>
                  <MaterialIcons name="refresh" size={18} color={Colors.gold} />
                </Pressable>
                <View>
                  <Text style={styles.todayDate}>
                    {new Date().toLocaleDateString('ar-SA', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
                  </Text>
                  <Text style={styles.todayGreeting}>لوحة تحكم معلم 👋</Text>
                </View>
                <MaterialIcons name="admin-panel-settings" size={36} color="rgba(212,160,23,0.4)" />
              </View>

              <Text style={styles.sectionTitle}>الإحصائيات من قاعدة البيانات</Text>
              <View style={styles.statsGrid}>
                <StatCard icon="list-alt"    label="إجمالي الطلبات" value={stats.totalOrders}       sub={`${stats.activeOrders} نشط`}          color={Colors.info}    trend="up" />
                <StatCard icon="engineering" label="الحرفيون"        value={stats.totalCraftsmen}    sub={`${stats.pendingCraftsmen} بانتظار`}  color={Colors.gold} />
                <StatCard icon="check-circle" label="مكتملة"         value={stats.completedOrders}   sub="طلب مكتمل"                            color={Colors.success} />
                <StatCard icon="hourglass-empty" label="قيد الانتظار" value={stats.pendingOrders}    sub="طلب معلق"                             color={Colors.warning} />
              </View>

              {/* Orders breakdown */}
              <Text style={styles.sectionTitle}>توزيع حالات الطلبات</Text>
              <View style={styles.card}>
                {[
                  { label: 'قيد الانتظار', val: stats.pendingOrders, color: Colors.warning },
                  { label: 'جاري التنفيذ', val: stats.activeOrders, color: Colors.info },
                  { label: 'مكتملة', val: stats.completedOrders, color: Colors.success },
                  { label: 'ملغاة', val: stats.cancelledOrders, color: Colors.error },
                ].map((s, i) => (
                  <View key={i} style={styles.statusBar}>
                    <Text style={[styles.statusBarVal, { color: s.color }]}>{s.val}</Text>
                    <View style={styles.statusBarTrack}>
                      <View style={[
                        styles.statusBarFill,
                        {
                          width: stats.totalOrders > 0
                            ? `${Math.max(2, (s.val / stats.totalOrders) * 100)}%` as any
                            : '2%',
                          backgroundColor: s.color,
                        },
                      ]} />
                    </View>
                    <Text style={styles.statusBarLabel}>{s.label}</Text>
                  </View>
                ))}
              </View>

              <Text style={styles.sectionTitle}>إيرادات تقديرية</Text>
              <View style={styles.card}>
                <View style={styles.chartHeader}>
                  <View style={styles.chartLegendRow}>
                    <View style={styles.legendItem}>
                      <Text style={styles.legendLabel}>عمولات</Text>
                      <View style={[styles.legendDot, { backgroundColor: Colors.info }]} />
                    </View>
                    <View style={styles.legendItem}>
                      <Text style={styles.legendLabel}>إيرادات</Text>
                      <View style={[styles.legendDot, { backgroundColor: Colors.gold }]} />
                    </View>
                  </View>
                  <Text style={styles.chartTitle}>آخر 6 أشهر (تقديري)</Text>
                </View>
                <BarChart data={MONTHLY_REVENUE} maxVal={maxRevenue} />
              </View>
            </View>
          )}

          {/* ── Craftsmen ── */}
          {activeTab === 'craftsmen' && (
            <View style={styles.section}>
              <View style={styles.statsGrid}>
                <StatCard icon="check-circle"    label="معتمدون"      value={stats.approvedCraftsmen} color={Colors.success} />
                <StatCard icon="hourglass-empty" label="بانتظار الموافقة" value={stats.pendingCraftsmen} color={Colors.warning} />
              </View>

              <Text style={styles.sectionTitle}>
                طلبات الانضمام ({stats.pendingCraftsmen})
              </Text>

              {pendingCraftsmenList.length === 0 ? (
                <View style={styles.emptyCard}>
                  <MaterialIcons name="check-circle" size={48} color={Colors.success} />
                  <Text style={styles.emptyText}>تمت مراجعة جميع الطلبات</Text>
                </View>
              ) : (
                pendingCraftsmenList.map(c => (
                  <View key={c.id} style={styles.craftsmanCard}>
                    <View style={styles.craftsmanCardHeader}>
                      <Text style={styles.submittedTime}>{c.submitted}</Text>
                      <View style={styles.pendingBadge}>
                        <MaterialIcons name="hourglass-empty" size={13} color={Colors.warning} />
                        <Text style={styles.pendingBadgeText}>بانتظار المراجعة</Text>
                      </View>
                    </View>
                    <View style={styles.craftsmanCardBody}>
                      <View style={styles.craftsmanMeta}>
                        <Text style={styles.craftsmanSpec}>{c.specialty}</Text>
                        <Text style={styles.craftsmanName}>{c.name}</Text>
                      </View>
                      <Image source={{ uri: c.image }} style={styles.craftsmanAvatar} contentFit="cover" />
                    </View>
                    <View style={styles.craftsmanDetails}>
                      {[
                        { icon: 'location-on', text: c.city },
                        { icon: 'work', text: `${c.experience} سنوات خبرة` },
                        ...(c.phone ? [{ icon: 'phone', text: c.phone }] : []),
                      ].map((d, i) => (
                        <View key={i} style={styles.detailItem}>
                          <Text style={styles.detailText}>{d.text}</Text>
                          <MaterialIcons name={d.icon as any} size={14} color={Colors.textMuted} />
                        </View>
                      ))}
                    </View>
                    <View style={styles.actionButtons}>
                      <Pressable style={styles.rejectBtn} onPress={() => handleReject(c.id, c.name)}>
                        {({ pressed }) => (
                          <View style={[styles.rejectBtnInner, pressed && { opacity: 0.8 }]}>
                            <MaterialIcons name="close" size={18} color={Colors.error} />
                            <Text style={styles.rejectText}>رفض</Text>
                          </View>
                        )}
                      </Pressable>
                      <Pressable style={styles.approveBtn} onPress={() => handleApprove(c.id, c.name)}>
                        {({ pressed }) => (
                          <View style={[styles.approveBtnInner, pressed && { opacity: 0.85 }]}>
                            <MaterialIcons name="check" size={18} color={Colors.primary} />
                            <Text style={styles.approveText}>قبول وتفعيل</Text>
                          </View>
                        )}
                      </Pressable>
                    </View>
                  </View>
                ))
              )}

              <Pressable
                style={styles.notifBtn}
                onPress={() => showAlert('إشعار', 'سيتم إرسال إشعار لجميع الحرفيين قريباً')}
              >
                <MaterialIcons name="notifications" size={20} color={Colors.primary} />
                <Text style={styles.notifBtnText}>إرسال إشعار للحرفيين</Text>
              </Pressable>
            </View>
          )}

          {/* ── Orders ── */}
          {activeTab === 'orders' && (
            <View style={styles.section}>
              <View style={styles.statsGrid}>
                <StatCard icon="hourglass-empty" label="انتظار"   value={stats.pendingOrders}   color={Colors.warning} />
                <StatCard icon="engineering"     label="جارٍ"     value={stats.activeOrders}    color={Colors.info}    />
                <StatCard icon="check-circle"    label="مكتملة"   value={stats.completedOrders} color={Colors.success} />
                <StatCard icon="cancel"          label="ملغاة"    value={stats.cancelledOrders} color={Colors.error}   />
              </View>

              <Text style={styles.sectionTitle}>آخر الطلبات ({recentOrders.length})</Text>
              {recentOrders.length === 0 ? (
                <View style={styles.emptyCard}>
                  <MaterialIcons name="list-alt" size={48} color={Colors.textMuted} />
                  <Text style={styles.emptyText}>لا توجد طلبات بعد</Text>
                </View>
              ) : (
                recentOrders.map(order => {
                  const sc = STATUS_CONFIG[order.status] ?? STATUS_CONFIG.pending;
                  return (
                    <Pressable
                      key={order.id}
                      style={styles.orderCard}
                      onPress={() => router.push(`/orders/${order.id}` as any)}
                    >
                      <View style={styles.orderHeader}>
                        <View style={[styles.statusPill, { backgroundColor: sc.bg }]}>
                          <Text style={[styles.statusPillText, { color: sc.color }]}>{sc.label}</Text>
                        </View>
                        <Text style={styles.orderService} numberOfLines={1}>{order.service}</Text>
                      </View>
                      <View style={styles.orderRow}>
                        <Text style={styles.orderTime}>{order.time}</Text>
                        <Text style={styles.orderParty}>الحرفي: <Text style={{ color: Colors.gold }}>{order.craftsman}</Text></Text>
                      </View>
                    </Pressable>
                  );
                })
              )}
            </View>
          )}

          {/* ── Revenue ── */}
          {activeTab === 'revenue' && (
            <View style={styles.section}>
              <View style={styles.revenueBanner}>
                <Text style={styles.revenueLabel}>إيرادات تقديرية (آخر 6 أشهر)</Text>
                <Text style={styles.revenueAmount}>
                  {MONTHLY_REVENUE.reduce((s, m) => s + m.revenue, 0).toLocaleString('ar-SA')} ريال
                </Text>
                <View style={styles.revenueMeta}>
                  <View style={styles.revenueMetaItem}>
                    <Text style={styles.revenueMetaValue}>
                      {MONTHLY_REVENUE.reduce((s, m) => s + m.commissions, 0).toLocaleString('ar-SA')} ر
                    </Text>
                    <Text style={styles.revenueMetaLabel}>عمولات</Text>
                  </View>
                  <View style={styles.revenueDivider} />
                  <View style={styles.revenueMetaItem}>
                    <Text style={styles.revenueMetaValue}>10%</Text>
                    <Text style={styles.revenueMetaLabel}>نسبة العمولة</Text>
                  </View>
                  <View style={styles.revenueDivider} />
                  <View style={styles.revenueMetaItem}>
                    <Text style={styles.revenueMetaValue}>{stats.completedOrders}</Text>
                    <Text style={styles.revenueMetaLabel}>طلب مكتمل</Text>
                  </View>
                </View>
              </View>

              <View style={styles.card}>
                <View style={styles.chartHeader}>
                  <View style={styles.chartLegendRow}>
                    <View style={styles.legendItem}>
                      <Text style={styles.legendLabel}>عمولات</Text>
                      <View style={[styles.legendDot, { backgroundColor: Colors.info }]} />
                    </View>
                    <View style={styles.legendItem}>
                      <Text style={styles.legendLabel}>إيرادات</Text>
                      <View style={[styles.legendDot, { backgroundColor: Colors.gold }]} />
                    </View>
                  </View>
                  <Text style={styles.chartTitle}>الإيرادات الشهرية</Text>
                </View>
                <BarChart data={MONTHLY_REVENUE} maxVal={maxRevenue} />
              </View>

              <Text style={styles.sectionTitle}>تفصيل الأشهر</Text>
              {[...MONTHLY_REVENUE].reverse().map((m, i) => (
                <View key={i} style={styles.monthRow}>
                  <View style={[styles.monthGrowth, { backgroundColor: i < 2 ? 'rgba(46,204,113,0.12)' : 'rgba(231,76,60,0.12)' }]}>
                    <MaterialIcons name={i < 2 ? 'trending-up' : 'trending-down'} size={14} color={i < 2 ? Colors.success : Colors.error} />
                  </View>
                  <View style={styles.monthRight}>
                    <Text style={styles.monthName}>{m.month} 2025</Text>
                    <Text style={styles.commText}>عمولة: {m.commissions.toLocaleString('ar-SA')} ريال</Text>
                  </View>
                  <Text style={styles.monthRevenue}>{m.revenue.toLocaleString('ar-SA')} ريال</Text>
                </View>
              ))}
            </View>
          )}
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  loadingContainer: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: Spacing.md },
  loadingText: { color: Colors.textMuted, fontSize: FontSize.base },

  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: Spacing.lg, paddingVertical: Spacing.md,
    borderBottomWidth: 1, borderBottomColor: Colors.divider,
  },
  backBtn: { width: 40, height: 40, borderRadius: 20, backgroundColor: Colors.surface, alignItems: 'center', justifyContent: 'center' },
  headerTitle: { fontSize: FontSize.xl, fontWeight: FontWeight.bold, color: Colors.text },
  headerLeft: { width: 80, alignItems: 'flex-start' },
  adminBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: Colors.gold, borderRadius: Radius.full,
    paddingHorizontal: 10, paddingVertical: 5,
  },
  adminBadgeText: { fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: Colors.primary },

  tabsScroll: { maxHeight: 52, borderBottomWidth: 1, borderBottomColor: Colors.divider },
  tabsContent: { flexDirection: 'row', paddingHorizontal: Spacing.md, gap: Spacing.sm, alignItems: 'center', height: 52 },
  tabBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    paddingHorizontal: 14, paddingVertical: 8, borderRadius: Radius.full,
    backgroundColor: Colors.surface, borderWidth: 1, borderColor: Colors.border,
    position: 'relative',
  },
  tabBtnActive: { backgroundColor: Colors.gold, borderColor: Colors.gold },
  tabText: { fontSize: FontSize.sm, color: Colors.textMuted, fontWeight: FontWeight.medium },
  tabTextActive: { color: Colors.primary, fontWeight: FontWeight.bold },
  tabBadge: {
    backgroundColor: Colors.error, borderRadius: Radius.full,
    minWidth: 18, height: 18, alignItems: 'center', justifyContent: 'center',
    paddingHorizontal: 4, marginLeft: 2,
  },
  tabBadgeText: { fontSize: 9, fontWeight: FontWeight.bold, color: Colors.text },

  content: { paddingHorizontal: Spacing.lg, paddingTop: Spacing.md },
  section: { gap: Spacing.md },
  sectionTitle: { fontSize: FontSize.base, fontWeight: FontWeight.bold, color: Colors.text, textAlign: 'right', marginTop: Spacing.sm },
  card: {
    backgroundColor: Colors.surface, borderRadius: Radius.xl,
    borderWidth: 1, borderColor: Colors.border, ...Shadow.sm, padding: Spacing.md, gap: Spacing.sm,
  },

  todayBanner: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    backgroundColor: Colors.primarySurface, borderRadius: Radius.xl,
    padding: Spacing.md, borderWidth: 1, borderColor: Colors.glassBorder,
  },
  todayDate: { fontSize: FontSize.xs, color: Colors.textMuted, textAlign: 'right' },
  todayGreeting: { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: Colors.text, textAlign: 'right' },
  refreshBtn: {
    width: 36, height: 36, borderRadius: 18,
    backgroundColor: Colors.goldSoft, alignItems: 'center', justifyContent: 'center',
    borderWidth: 1, borderColor: 'rgba(212,160,23,0.3)',
  },

  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm },

  statusBar: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  statusBarLabel: { fontSize: FontSize.xs, color: Colors.textMuted, width: 70, textAlign: 'right' },
  statusBarTrack: { flex: 1, height: 8, backgroundColor: Colors.surface2, borderRadius: 4, overflow: 'hidden' },
  statusBarFill: { height: '100%', borderRadius: 4 },
  statusBarVal: { fontSize: FontSize.sm, fontWeight: FontWeight.bold, width: 32, textAlign: 'right' },

  chartHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: Spacing.sm },
  chartTitle: { fontSize: FontSize.sm, color: Colors.text, fontWeight: FontWeight.semibold },
  chartLegendRow: { flexDirection: 'row', gap: Spacing.md },
  legendItem: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  legendDot: { width: 8, height: 8, borderRadius: 4 },
  legendLabel: { fontSize: FontSize.xs, color: Colors.textMuted },

  // Craftsmen
  craftsmanCard: {
    backgroundColor: Colors.surface, borderRadius: Radius.xl,
    borderWidth: 1, borderColor: Colors.border, ...Shadow.sm, padding: Spacing.md, gap: Spacing.md,
  },
  craftsmanCardHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  pendingBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: 'rgba(243,156,18,0.1)', paddingHorizontal: 10, paddingVertical: 5, borderRadius: Radius.full,
  },
  pendingBadgeText: { fontSize: 10, fontWeight: FontWeight.semibold, color: Colors.warning },
  submittedTime: { fontSize: FontSize.xs, color: Colors.textMuted },
  craftsmanCardBody: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  craftsmanMeta: { alignItems: 'flex-end', gap: 4 },
  craftsmanName: { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: Colors.text, textAlign: 'right' },
  craftsmanSpec: { fontSize: FontSize.sm, color: Colors.gold },
  craftsmanAvatar: { width: 72, height: 72, borderRadius: 36, borderWidth: 2.5, borderColor: Colors.gold },
  craftsmanDetails: { gap: Spacing.xs, backgroundColor: Colors.primarySurface, borderRadius: Radius.md, padding: Spacing.sm },
  detailItem: { flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-end', gap: Spacing.sm },
  detailText: { fontSize: FontSize.sm, color: Colors.textMuted },
  actionButtons: { flexDirection: 'row', gap: Spacing.sm },
  rejectBtn: { flex: 1, borderRadius: Radius.lg, overflow: 'hidden', borderWidth: 1.5, borderColor: Colors.error },
  rejectBtnInner: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, paddingVertical: 11 },
  rejectText: { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: Colors.error },
  approveBtn: { flex: 2, borderRadius: Radius.lg, overflow: 'hidden' },
  approveBtnInner: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, backgroundColor: Colors.gold, paddingVertical: 11 },
  approveText: { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: Colors.primary },
  emptyCard: { backgroundColor: Colors.surface, borderRadius: Radius.xl, padding: Spacing.xl, alignItems: 'center', gap: Spacing.md, borderWidth: 1, borderColor: Colors.border },
  emptyText: { fontSize: FontSize.base, color: Colors.textMuted },
  notifBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: Spacing.sm,
    backgroundColor: Colors.gold, borderRadius: Radius.lg, paddingVertical: 14, ...Shadow.gold,
  },
  notifBtnText: { fontSize: FontSize.base, fontWeight: FontWeight.bold, color: Colors.primary },

  // Orders
  orderCard: {
    backgroundColor: Colors.surface, borderRadius: Radius.lg,
    borderWidth: 1, borderColor: Colors.border, padding: Spacing.md, gap: Spacing.sm,
  },
  orderHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-end', gap: Spacing.sm },
  orderService: { fontSize: FontSize.base, fontWeight: FontWeight.bold, color: Colors.text, flex: 1, textAlign: 'right' },
  statusPill: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: Radius.full },
  statusPillText: { fontSize: FontSize.xs, fontWeight: FontWeight.bold },
  orderRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  orderParty: { fontSize: FontSize.xs, color: Colors.textMuted, textAlign: 'right' },
  orderTime: { fontSize: FontSize.xs, color: Colors.textMuted },

  // Revenue
  revenueBanner: {
    backgroundColor: Colors.primarySurface, borderRadius: Radius.xl,
    borderWidth: 1, borderColor: Colors.glassBorder, padding: Spacing.lg, gap: Spacing.sm,
    alignItems: 'center', overflow: 'hidden',
  },
  revenueLabel: { fontSize: FontSize.sm, color: Colors.textMuted },
  revenueAmount: { fontSize: 28, fontWeight: FontWeight.bold, color: Colors.gold },
  revenueMeta: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md },
  revenueMetaItem: { alignItems: 'center', gap: 3 },
  revenueMetaLabel: { fontSize: 10, color: Colors.textMuted },
  revenueMetaValue: { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: Colors.text },
  revenueDivider: { width: 1, height: 30, backgroundColor: Colors.divider },
  monthRow: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.md,
    backgroundColor: Colors.surface, borderRadius: Radius.lg,
    padding: Spacing.md, borderWidth: 1, borderColor: Colors.border,
  },
  monthRight: { flex: 1, alignItems: 'flex-end', gap: 3 },
  monthName: { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: Colors.text },
  monthRevenue: { fontSize: FontSize.base, fontWeight: FontWeight.bold, color: Colors.gold, minWidth: 100, textAlign: 'left' },
  commText: { fontSize: FontSize.xs, color: Colors.textMuted },
  monthGrowth: { flexDirection: 'row', alignItems: 'center', gap: 3, paddingHorizontal: 8, paddingVertical: 6, borderRadius: Radius.full },
});
