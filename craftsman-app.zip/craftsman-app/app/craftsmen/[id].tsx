import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  View, Text, StyleSheet, ScrollView, Pressable, Dimensions,
  Linking, ActivityIndicator, TextInput, KeyboardAvoidingView,
  Platform, Modal, Animated,
} from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import { Colors, FontSize, FontWeight, Radius, Spacing, Shadow } from '@/constants/theme';
import { useApp } from '@/hooks/useApp';
import { getSupabaseClient, useAuth, useAlert } from '@/template';

const { width } = Dimensions.get('window');

// ─── Types ────────────────────────────────────────────────────────────────────
interface CraftsmanDetail {
  id: string;
  name: string;
  specialty: string;
  specialtyIcon: string;
  rating: number;
  reviewCount: number;
  city: string;
  available: boolean;
  experience: number;
  price: string;
  image: string;
  phone: string;
  bio: string;
  completedJobs: number;
  skills: string[];
  portfolio: string[];
}

interface Review {
  id: string;
  userName: string;
  rating: number;
  comment: string;
  date: string;
}

// ─── Star Rating Component ─────────────────────────────────────────────────────
function StarPicker({ value, onChange }: { value: number; onChange: (v: number) => void }) {
  return (
    <View style={starStyles.row}>
      {[1, 2, 3, 4, 5].map(i => (
        <Pressable key={i} onPress={() => onChange(i)} hitSlop={{ top: 8, bottom: 8, left: 4, right: 4 }}>
          <MaterialIcons
            name={i <= value ? 'star' : 'star-border'}
            size={34}
            color={i <= value ? Colors.gold : Colors.border}
          />
        </Pressable>
      ))}
    </View>
  );
}

const starStyles = StyleSheet.create({
  row: { flexDirection: 'row', gap: 4, justifyContent: 'center' },
});

// ─── Lightbox Component ───────────────────────────────────────────────────────
function ImageLightbox({ visible, uri, onClose }: { visible: boolean; uri: string; onClose: () => void }) {
  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <Pressable style={lbStyles.overlay} onPress={onClose}>
        <Image source={{ uri }} style={lbStyles.img} contentFit="contain" />
        <Pressable style={lbStyles.closeBtn} onPress={onClose}>
          <MaterialIcons name="close" size={24} color={Colors.text} />
        </Pressable>
      </Pressable>
    </Modal>
  );
}

const lbStyles = StyleSheet.create({
  overlay: {
    flex: 1, backgroundColor: 'rgba(0,0,0,0.92)',
    alignItems: 'center', justifyContent: 'center',
  },
  img: { width: width, height: width, maxHeight: '80%' },
  closeBtn: {
    position: 'absolute', top: 50, right: 20,
    width: 44, height: 44, borderRadius: 22,
    backgroundColor: 'rgba(255,255,255,0.15)',
    alignItems: 'center', justifyContent: 'center',
  },
});

// ─── Main Screen ──────────────────────────────────────────────────────────────
export default function CraftsmanDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { toggleFavorite, isFavorite } = useApp();
  const { user } = useAuth();
  const { showAlert } = useAlert();
  const supabase = getSupabaseClient();

  // Data states
  const [craftsman, setCraftsman] = useState<CraftsmanDetail | null>(null);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);
  const [reviewsLoading, setReviewsLoading] = useState(true);

  // Portfolio lightbox
  const [lightboxUri, setLightboxUri] = useState('');
  const [lightboxVisible, setLightboxVisible] = useState(false);

  // Review form state
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [myRating, setMyRating] = useState(0);
  const [myComment, setMyComment] = useState('');
  const [submittingReview, setSubmittingReview] = useState(false);
  const [hasReviewed, setHasReviewed] = useState(false);

  // Scroll animation for parallax header
  const scrollY = useRef(new Animated.Value(0)).current;
  const headerOpacity = scrollY.interpolate({
    inputRange: [0, 180, 280],
    outputRange: [0, 0, 1],
    extrapolate: 'clamp',
  });

  // ── Fetch craftsman data ──────────────────────────────────────────────────
  const fetchCraftsman = useCallback(async () => {
    if (!id) return;
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('craftsmen')
        .select('*')
        .eq('id', id)
        .single();
      if (!error && data) {
        setCraftsman({
          id: data.id,
          name: data.name,
          specialty: data.specialty,
          specialtyIcon: data.specialty_icon ?? 'build',
          rating: parseFloat(data.rating) || 0,
          reviewCount: data.review_count ?? 0,
          city: data.city ?? 'الرياض',
          available: data.available ?? true,
          experience: data.experience ?? 1,
          price: data.price_range ?? '50 - 150 ريال',
          image: data.image_url ?? 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400',
          phone: data.phone ?? '',
          bio: data.bio ?? '',
          completedJobs: data.completed_jobs ?? 0,
          skills: data.skills ?? [],
          portfolio: data.portfolio_urls ?? [],
        });
      }
    } finally {
      setLoading(false);
    }
  }, [id]);

  // ── Fetch reviews ─────────────────────────────────────────────────────────
  const fetchReviews = useCallback(async () => {
    if (!id) return;
    setReviewsLoading(true);
    try {
      const { data, error } = await supabase
        .from('reviews')
        .select('*')
        .eq('craftsman_id', id)
        .order('created_at', { ascending: false });
      if (!error && data) {
        setReviews(data.map((r: any) => ({
          id: r.id,
          userName: r.user_name ?? 'مستخدم',
          rating: r.rating,
          comment: r.comment ?? '',
          date: new Date(r.created_at).toLocaleDateString('ar-SA', { day: 'numeric', month: 'long', year: 'numeric' }),
        })));

        // Check if current user already reviewed
        if (user) {
          const existed = data.find((r: any) => r.user_id === user.id);
          if (existed) setHasReviewed(true);
        }
      }
    } finally {
      setReviewsLoading(false);
    }
  }, [id, user]);

  useEffect(() => {
    fetchCraftsman();
    fetchReviews();
  }, [fetchCraftsman, fetchReviews]);

  // ── Submit review ─────────────────────────────────────────────────────────
  const handleSubmitReview = async () => {
    if (!user) {
      showAlert('تسجيل الدخول', 'يجب تسجيل الدخول لإضافة تقييم', [
        { text: 'إلغاء', style: 'cancel' },
        { text: 'تسجيل الدخول', onPress: () => router.push('/auth/login') },
      ]);
      return;
    }
    if (myRating === 0) {
      showAlert('تنبيه', 'يرجى اختيار عدد النجوم');
      return;
    }
    if (myComment.trim().length < 5) {
      showAlert('تنبيه', 'يرجى كتابة تعليق مختصر (5 أحرف على الأقل)');
      return;
    }

    setSubmittingReview(true);
    try {
      const displayName = user.username || user.email?.split('@')[0] || 'مستخدم';
      const { error } = await supabase.from('reviews').insert({
        craftsman_id: id,
        user_id: user.id,
        user_name: displayName,
        rating: myRating,
        comment: myComment.trim(),
      });

      if (error) {
        if (error.code === '23505') {
          showAlert('تنبيه', 'لقد قمت بتقييم هذا الحرفي مسبقاً');
          setHasReviewed(true);
        } else {
          showAlert('خطأ', 'لم يتم إرسال التقييم، حاول مرة أخرى');
        }
        return;
      }

      // Update craftsman average rating in DB
      const allRatings = [...reviews.map(r => r.rating), myRating];
      const newAvg = allRatings.reduce((s, v) => s + v, 0) / allRatings.length;
      await supabase.from('craftsmen').update({
        rating: parseFloat(newAvg.toFixed(2)),
        review_count: allRatings.length,
      }).eq('id', id);

      setHasReviewed(true);
      setShowReviewForm(false);
      setMyRating(0);
      setMyComment('');
      await fetchReviews();
      await fetchCraftsman();

      showAlert('شكراً!', 'تم إضافة تقييمك بنجاح');
    } finally {
      setSubmittingReview(false);
    }
  };

  const handleCall = () => {
    if (craftsman?.phone) Linking.openURL(`tel:${craftsman.phone}`);
  };

  const handleWhatsApp = () => {
    if (craftsman?.phone) Linking.openURL(`https://wa.me/${craftsman.phone.replace(/\D/g, '')}`);
  };

  const handleChat = () => {
    if (craftsman) router.push(`/chat/${craftsman.id}` as any);
  };

  // ── Computed ──────────────────────────────────────────────────────────────
  const avgRating = reviews.length > 0
    ? reviews.reduce((s, r) => s + r.rating, 0) / reviews.length
    : craftsman?.rating ?? 0;

  const ratingDistribution = [5, 4, 3, 2, 1].map(star => ({
    star,
    count: reviews.filter(r => r.rating === star).length,
    pct: reviews.length > 0
      ? (reviews.filter(r => r.rating === star).length / reviews.length) * 100
      : 0,
  }));

  // ── Loading / Not found ───────────────────────────────────────────────────
  if (loading) {
    return (
      <View style={[styles.container, styles.centered, { paddingTop: insets.top }]}>
        <StatusBar style="light" />
        <ActivityIndicator size="large" color={Colors.gold} />
        <Text style={styles.loadingText}>جاري تحميل بيانات الحرفي...</Text>
      </View>
    );
  }

  if (!craftsman) {
    return (
      <View style={[styles.container, styles.centered, { paddingTop: insets.top }]}>
        <StatusBar style="light" />
        <MaterialIcons name="person-off" size={56} color={Colors.textMuted} />
        <Text style={styles.notFoundText}>لم يتم العثور على الحرفي</Text>
        <Pressable style={styles.backFallbackBtn} onPress={() => router.back()}>
          <Text style={styles.backFallbackText}>العودة</Text>
        </Pressable>
      </View>
    );
  }

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <View style={[styles.container, { paddingTop: insets.top }]}>
        <StatusBar style="light" />

        {/* Floating compact header (appears on scroll) */}
        <Animated.View style={[styles.floatingHeader, { opacity: headerOpacity, paddingTop: insets.top }]}>
          <Text style={styles.floatingHeaderTitle} numberOfLines={1}>{craftsman.name}</Text>
        </Animated.View>

        {/* Fixed top actions */}
        <View style={[styles.topActions, { top: insets.top + 8 }]}>
          <Pressable style={styles.topBtn} onPress={() => toggleFavorite(craftsman.id)}>
            <MaterialIcons
              name={isFavorite(craftsman.id) ? 'favorite' : 'favorite-border'}
              size={22}
              color={isFavorite(craftsman.id) ? '#E74C3C' : Colors.text}
            />
          </Pressable>
          <Pressable style={styles.topBtn} onPress={() => router.back()}>
            <MaterialIcons name="arrow-forward" size={22} color={Colors.text} />
          </Pressable>
        </View>

        <Animated.ScrollView
          showsVerticalScrollIndicator={false}
          onScroll={Animated.event([{ nativeEvent: { contentOffset: { y: scrollY } } }], { useNativeDriver: true })}
          scrollEventThrottle={16}
        >
          {/* ── Hero Image ── */}
          <View style={styles.heroArea}>
            <Image source={{ uri: craftsman.image }} style={styles.heroImg} contentFit="cover" transition={200} />
            <View style={styles.heroGradient} />

            {/* Availability + Price */}
            <View style={styles.heroBadgesRow}>
              <View style={styles.priceBadge}>
                <MaterialIcons name="attach-money" size={14} color={Colors.gold} />
                <Text style={styles.priceText}>{craftsman.price}</Text>
              </View>
              <View style={[styles.availBadge, { backgroundColor: craftsman.available ? 'rgba(46,204,113,0.2)' : 'rgba(231,76,60,0.2)' }]}>
                <View style={[styles.availDot, { backgroundColor: craftsman.available ? Colors.success : Colors.error }]} />
                <Text style={[styles.availText, { color: craftsman.available ? Colors.success : Colors.error }]}>
                  {craftsman.available ? 'متاح الآن' : 'غير متاح'}
                </Text>
              </View>
            </View>
          </View>

          <View style={styles.body}>
            {/* ── Name, Specialty, Rating ── */}
            <View style={styles.nameCard}>
              <View style={styles.ratingBadgeLarge}>
                <MaterialIcons name="star" size={18} color={Colors.gold} />
                <Text style={styles.ratingNumLarge}>{avgRating.toFixed(1)}</Text>
                <Text style={styles.ratingCountText}>({reviews.length > 0 ? reviews.length : craftsman.reviewCount})</Text>
              </View>
              <View style={styles.nameBlock}>
                <Text style={styles.name}>{craftsman.name}</Text>
                <View style={styles.specialtyRow}>
                  <MaterialIcons name={craftsman.specialtyIcon as any} size={14} color={Colors.gold} />
                  <Text style={styles.specialty}>{craftsman.specialty}</Text>
                </View>
              </View>
            </View>

            {/* ── Quick Stats ── */}
            <View style={styles.statsCard}>
              {[
                { icon: 'work-history', label: 'الخبرة', value: `${craftsman.experience}`, unit: 'سنة' },
                { icon: 'task-alt',     label: 'مهام',   value: `${craftsman.completedJobs}`, unit: 'منجزة' },
                { icon: 'star',         label: 'تقييمات', value: `${reviews.length > 0 ? reviews.length : craftsman.reviewCount}`, unit: 'تقييم' },
                { icon: 'location-on',  label: 'المدينة', value: craftsman.city, unit: '' },
              ].map((s, i) => (
                <View key={i} style={[styles.statItem, i < 3 && styles.statItemBorder]}>
                  <MaterialIcons name={s.icon as any} size={18} color={Colors.gold} />
                  <Text style={styles.statValue}>{s.value}</Text>
                  <Text style={styles.statLabel}>{s.unit || s.label}</Text>
                </View>
              ))}
            </View>

            {/* ── Bio ── */}
            {craftsman.bio ? (
              <View style={styles.section}>
                <Text style={styles.sectionTitle}>نبذة عنه</Text>
                <View style={styles.bioCard}>
                  <MaterialIcons name="format-quote" size={22} color="rgba(212,160,23,0.4)" style={{ alignSelf: 'flex-end' }} />
                  <Text style={styles.bioText}>{craftsman.bio}</Text>
                </View>
              </View>
            ) : null}

            {/* ── Skills ── */}
            {craftsman.skills.length > 0 ? (
              <View style={styles.section}>
                <Text style={styles.sectionTitle}>المهارات والتخصصات</Text>
                <View style={styles.skillsWrap}>
                  {craftsman.skills.map((sk, i) => (
                    <View key={i} style={styles.skillChip}>
                      <MaterialIcons name="check-circle" size={13} color={Colors.gold} />
                      <Text style={styles.skillText}>{sk}</Text>
                    </View>
                  ))}
                </View>
              </View>
            ) : null}

            {/* ── Portfolio ── */}
            {craftsman.portfolio.length > 0 ? (
              <View style={styles.section}>
                <Text style={styles.sectionTitle}>معرض الأعمال ({craftsman.portfolio.length})</Text>
                <ScrollView
                  horizontal
                  showsHorizontalScrollIndicator={false}
                  contentContainerStyle={styles.portfolioScroll}
                >
                  {craftsman.portfolio.map((uri, i) => (
                    <Pressable
                      key={i}
                      onPress={() => { setLightboxUri(uri); setLightboxVisible(true); }}
                    >
                      {({ pressed }) => (
                        <View style={[styles.portfolioThumb, pressed && { opacity: 0.85 }]}>
                          <Image source={{ uri }} style={styles.portfolioImg} contentFit="cover" transition={150} />
                          <View style={styles.portfolioOverlay}>
                            <MaterialIcons name="zoom-in" size={20} color="rgba(255,255,255,0.8)" />
                          </View>
                        </View>
                      )}
                    </Pressable>
                  ))}
                </ScrollView>
              </View>
            ) : null}

            {/* ── Reviews Section ── */}
            <View style={styles.section}>
              <View style={styles.sectionHeaderRow}>
                <Pressable
                  style={[
                    styles.addReviewBtn,
                    (hasReviewed || !craftsman.available) && styles.addReviewBtnDisabled,
                  ]}
                  onPress={() => {
                    if (hasReviewed) {
                      showAlert('تنبيه', 'لقد قمت بتقييم هذا الحرفي مسبقاً');
                      return;
                    }
                    setShowReviewForm(v => !v);
                  }}
                >
                  <MaterialIcons
                    name={showReviewForm ? 'close' : 'rate-review'}
                    size={16}
                    color={hasReviewed ? Colors.textMuted : Colors.primary}
                  />
                  <Text style={[styles.addReviewText, hasReviewed && { color: Colors.textMuted }]}>
                    {hasReviewed ? 'تم التقييم' : 'أضف تقييم'}
                  </Text>
                </Pressable>
                <Text style={styles.sectionTitle}>تقييمات العملاء</Text>
              </View>

              {/* Rating overview */}
              {reviews.length > 0 && (
                <View style={styles.ratingOverviewCard}>
                  {/* Big score */}
                  <View style={styles.ratingScoreCol}>
                    <Text style={styles.bigScore}>{avgRating.toFixed(1)}</Text>
                    <View style={styles.starsRow}>
                      {[1, 2, 3, 4, 5].map(i => (
                        <MaterialIcons
                          key={i}
                          name={i <= Math.round(avgRating) ? 'star' : 'star-border'}
                          size={14}
                          color={Colors.gold}
                        />
                      ))}
                    </View>
                    <Text style={styles.ratingTotalText}>{reviews.length} تقييم</Text>
                  </View>

                  {/* Distribution bars */}
                  <View style={styles.ratingBarsCol}>
                    {ratingDistribution.map(({ star, count, pct }) => (
                      <View key={star} style={styles.ratingBarRow}>
                        <Text style={styles.ratingBarCount}>{count}</Text>
                        <View style={styles.ratingBarTrack}>
                          <View style={[styles.ratingBarFill, { width: `${Math.max(pct, 2)}%` }]} />
                        </View>
                        <View style={styles.ratingBarStarRow}>
                          <Text style={styles.ratingBarStar}>{star}</Text>
                          <MaterialIcons name="star" size={11} color={Colors.gold} />
                        </View>
                      </View>
                    ))}
                  </View>
                </View>
              )}

              {/* ── Review Form ── */}
              {showReviewForm && (
                <View style={styles.reviewFormCard}>
                  <Text style={styles.reviewFormTitle}>أضف تقييمك</Text>

                  <View style={styles.reviewFormStarsSection}>
                    <Text style={styles.reviewFormLabel}>
                      {myRating === 0 ? 'اختر تقييمك' :
                       myRating === 1 ? 'سيء' :
                       myRating === 2 ? 'مقبول' :
                       myRating === 3 ? 'جيد' :
                       myRating === 4 ? 'جيد جداً' : 'ممتاز! ⭐'}
                    </Text>
                    <StarPicker value={myRating} onChange={setMyRating} />
                  </View>

                  <TextInput
                    style={styles.reviewInput}
                    value={myComment}
                    onChangeText={setMyComment}
                    placeholder="اكتب تعليقاً عن تجربتك مع الحرفي..."
                    placeholderTextColor={Colors.textMuted}
                    multiline
                    numberOfLines={4}
                    textAlign="right"
                    textAlignVertical="top"
                    maxLength={300}
                  />
                  <Text style={styles.charCount}>{myComment.length} / 300</Text>

                  <View style={styles.reviewFormActions}>
                    <Pressable
                      style={styles.cancelReviewBtn}
                      onPress={() => { setShowReviewForm(false); setMyRating(0); setMyComment(''); }}
                    >
                      <Text style={styles.cancelReviewText}>إلغاء</Text>
                    </Pressable>
                    <Pressable
                      style={[styles.submitReviewBtn, (submittingReview || myRating === 0) && { opacity: 0.6 }]}
                      onPress={handleSubmitReview}
                      disabled={submittingReview || myRating === 0}
                    >
                      {submittingReview ? (
                        <ActivityIndicator size="small" color={Colors.primary} />
                      ) : (
                        <>
                          <MaterialIcons name="send" size={16} color={Colors.primary} />
                          <Text style={styles.submitReviewText}>إرسال التقييم</Text>
                        </>
                      )}
                    </Pressable>
                  </View>
                </View>
              )}

              {/* ── Reviews List ── */}
              {reviewsLoading ? (
                <View style={styles.reviewsLoading}>
                  <ActivityIndicator size="small" color={Colors.gold} />
                  <Text style={styles.loadingText}>جاري تحميل التقييمات...</Text>
                </View>
              ) : reviews.length === 0 ? (
                <View style={styles.emptyReviews}>
                  <MaterialIcons name="rate-review" size={40} color={Colors.textMuted} />
                  <Text style={styles.emptyReviewsTitle}>لا توجد تقييمات بعد</Text>
                  <Text style={styles.emptyReviewsSub}>كن أول من يقيّم هذا الحرفي</Text>
                  {!hasReviewed && (
                    <Pressable
                      style={styles.firstReviewBtn}
                      onPress={() => setShowReviewForm(true)}
                    >
                      <MaterialIcons name="star" size={16} color={Colors.primary} />
                      <Text style={styles.firstReviewText}>أضف أول تقييم</Text>
                    </Pressable>
                  )}
                </View>
              ) : (
                <View style={styles.reviewsList}>
                  {reviews.map((review, idx) => (
                    <View key={review.id} style={[styles.reviewCard, idx === 0 && styles.reviewCardFirst]}>
                      {/* Avatar + name + stars */}
                      <View style={styles.reviewHeader}>
                        <Text style={styles.reviewDate}>{review.date}</Text>
                        <View style={styles.reviewUserRow}>
                          <View style={styles.reviewStarsRow}>
                            {[1, 2, 3, 4, 5].map(i => (
                              <MaterialIcons
                                key={i}
                                name="star"
                                size={13}
                                color={i <= review.rating ? Colors.gold : Colors.border}
                              />
                            ))}
                          </View>
                          <Text style={styles.reviewName}>{review.userName}</Text>
                          <View style={styles.reviewAvatar}>
                            <Text style={styles.reviewAvatarText}>
                              {review.userName.charAt(0).toUpperCase()}
                            </Text>
                          </View>
                        </View>
                      </View>
                      {/* Comment */}
                      {review.comment ? (
                        <Text style={styles.reviewComment}>{review.comment}</Text>
                      ) : null}
                      {/* Rating chip */}
                      <View style={[
                        styles.ratingChip,
                        {
                          backgroundColor: review.rating >= 4 ? 'rgba(46,204,113,0.1)' :
                                          review.rating === 3 ? 'rgba(243,156,18,0.1)' : 'rgba(231,76,60,0.1)',
                        },
                      ]}>
                        <Text style={[
                          styles.ratingChipText,
                          {
                            color: review.rating >= 4 ? Colors.success :
                                   review.rating === 3 ? Colors.warning : Colors.error,
                          },
                        ]}>
                          {review.rating >= 4 ? 'ممتاز' : review.rating === 3 ? 'جيد' : 'سيء'}
                        </Text>
                      </View>
                    </View>
                  ))}
                </View>
              )}
            </View>

            {/* Bottom padding for action bar */}
            <View style={{ height: 90 }} />
          </View>
        </Animated.ScrollView>

        {/* ── Bottom Action Bar ── */}
        <View style={[styles.actionBar, { paddingBottom: insets.bottom + Spacing.sm }]}>
          <Pressable
            style={styles.requestBtn}
            onPress={() => router.push({
              pathname: '/request/new',
              params: { craftsmanId: craftsman.id, craftsmanName: craftsman.name },
            } as any)}
          >
            {({ pressed }) => (
              <View style={[styles.requestBtnInner, pressed && { opacity: 0.88 }]}>
                <MaterialIcons name="home-repair-service" size={18} color={Colors.primary} />
                <Text style={styles.requestBtnText}>طلب خدمة</Text>
              </View>
            )}
          </Pressable>

          <Pressable style={styles.iconBtn} onPress={handleChat}>
            <MaterialIcons name="chat-bubble" size={22} color={Colors.gold} />
          </Pressable>

          <Pressable style={[styles.iconBtn, { backgroundColor: 'rgba(37,211,102,0.12)', borderColor: 'rgba(37,211,102,0.3)' }]} onPress={handleWhatsApp}>
            <MaterialIcons name="chat" size={22} color="#25D366" />
          </Pressable>

          <Pressable style={styles.iconBtn} onPress={handleCall}>
            <MaterialIcons name="call" size={22} color={Colors.info} />
          </Pressable>
        </View>

        {/* Portfolio Lightbox */}
        <ImageLightbox
          visible={lightboxVisible}
          uri={lightboxUri}
          onClose={() => setLightboxVisible(false)}
        />
      </View>
    </KeyboardAvoidingView>
  );
}

// ─── Styles ───────────────────────────────────────────────────────────────────
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  centered: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: Spacing.md },
  loadingText: { color: Colors.textMuted, fontSize: FontSize.base },
  notFoundText: { fontSize: FontSize.xl, color: Colors.text, fontWeight: FontWeight.bold },
  backFallbackBtn: { backgroundColor: Colors.gold, borderRadius: Radius.lg, paddingVertical: 12, paddingHorizontal: 32 },
  backFallbackText: { color: Colors.primary, fontWeight: FontWeight.bold, fontSize: FontSize.base },

  // Floating header
  floatingHeader: {
    position: 'absolute', top: 0, left: 0, right: 0, zIndex: 50,
    backgroundColor: Colors.background, paddingHorizontal: Spacing.lg,
    paddingBottom: Spacing.sm, borderBottomWidth: 1, borderBottomColor: Colors.divider,
    alignItems: 'center',
  },
  floatingHeaderTitle: { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: Colors.text },

  // Top actions (fixed overlay)
  topActions: {
    position: 'absolute', left: 0, right: 0, zIndex: 40,
    flexDirection: 'row', justifyContent: 'space-between',
    paddingHorizontal: Spacing.lg,
  },
  topBtn: {
    width: 42, height: 42, borderRadius: 21,
    backgroundColor: 'rgba(8,15,32,0.65)',
    alignItems: 'center', justifyContent: 'center',
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.1)',
  },

  // Hero
  heroArea: { height: 300, position: 'relative' },
  heroImg: { width: '100%', height: '100%' },
  heroGradient: {
    position: 'absolute', bottom: 0, left: 0, right: 0, height: 160,
    backgroundColor: 'rgba(8,15,32,0.75)',
  },
  heroBadgesRow: {
    position: 'absolute', bottom: Spacing.md, left: 0, right: 0,
    flexDirection: 'row', justifyContent: 'space-between', paddingHorizontal: Spacing.lg,
  },
  priceBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    paddingHorizontal: 12, paddingVertical: 6, borderRadius: Radius.full,
    backgroundColor: Colors.goldSoft, borderWidth: 1, borderColor: 'rgba(212,160,23,0.4)',
  },
  priceText: { fontSize: FontSize.sm, color: Colors.gold, fontWeight: FontWeight.bold },
  availBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    paddingHorizontal: 12, paddingVertical: 6, borderRadius: Radius.full,
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.1)',
  },
  availDot: { width: 8, height: 8, borderRadius: 4 },
  availText: { fontSize: FontSize.sm, fontWeight: FontWeight.semibold },

  // Body
  body: { paddingHorizontal: Spacing.lg, paddingTop: Spacing.lg, gap: Spacing.xl },

  // Name card
  nameCard: {
    flexDirection: 'row', alignItems: 'flex-start',
    justifyContent: 'flex-end', gap: Spacing.md,
  },
  nameBlock: { flex: 1, alignItems: 'flex-end', gap: 4 },
  name: { fontSize: FontSize.xxl, fontWeight: FontWeight.bold, color: Colors.text, textAlign: 'right' },
  specialtyRow: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  specialty: { fontSize: FontSize.base, color: Colors.gold, fontWeight: FontWeight.medium },
  ratingBadgeLarge: {
    flexDirection: 'column', alignItems: 'center', gap: 3,
    backgroundColor: Colors.goldSoft, borderRadius: Radius.lg,
    paddingHorizontal: Spacing.md, paddingVertical: 10,
    borderWidth: 1, borderColor: 'rgba(212,160,23,0.35)',
    minWidth: 70,
  },
  ratingNumLarge: { fontSize: FontSize.xxl, fontWeight: FontWeight.bold, color: Colors.gold },
  ratingCountText: { fontSize: 10, color: Colors.textMuted },

  // Stats card
  statsCard: {
    flexDirection: 'row', backgroundColor: Colors.surface,
    borderRadius: Radius.xl, borderWidth: 1, borderColor: Colors.border,
    ...Shadow.sm,
  },
  statItem: { flex: 1, alignItems: 'center', gap: 4, paddingVertical: Spacing.md },
  statItemBorder: { borderRightWidth: 1, borderRightColor: Colors.divider },
  statValue: { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: Colors.text, textAlign: 'center' },
  statLabel: { fontSize: 10, color: Colors.textMuted, textAlign: 'center' },

  // Section
  section: { gap: Spacing.sm },
  sectionTitle: { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: Colors.text, textAlign: 'right' },
  sectionHeaderRow: {
    flexDirection: 'row', alignItems: 'center',
    justifyContent: 'space-between',
  },

  // Bio
  bioCard: {
    backgroundColor: Colors.surface, borderRadius: Radius.xl,
    borderWidth: 1, borderColor: Colors.border,
    padding: Spacing.md, gap: Spacing.sm,
    borderRightWidth: 3, borderRightColor: Colors.gold,
  },
  bioText: { fontSize: FontSize.base, color: Colors.textMuted, lineHeight: 28, textAlign: 'right' },

  // Skills
  skillsWrap: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm, justifyContent: 'flex-end' },
  skillChip: {
    flexDirection: 'row', alignItems: 'center', gap: 5,
    backgroundColor: Colors.goldSoft, borderRadius: Radius.full,
    paddingHorizontal: 13, paddingVertical: 7,
    borderWidth: 1, borderColor: 'rgba(212,160,23,0.3)',
  },
  skillText: { fontSize: FontSize.sm, color: Colors.gold, fontWeight: FontWeight.medium },

  // Portfolio
  portfolioScroll: { gap: Spacing.sm, paddingVertical: 2 },
  portfolioThumb: {
    width: 140, height: 105, borderRadius: Radius.lg,
    overflow: 'hidden', position: 'relative',
    borderWidth: 1, borderColor: Colors.border,
  },
  portfolioImg: { width: '100%', height: '100%' },
  portfolioOverlay: {
    position: 'absolute', bottom: 0, left: 0, right: 0, top: 0,
    backgroundColor: 'rgba(0,0,0,0.15)',
    alignItems: 'center', justifyContent: 'center',
  },

  // Reviews section header
  addReviewBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 5,
    backgroundColor: Colors.gold, borderRadius: Radius.full,
    paddingHorizontal: 14, paddingVertical: 8,
    ...Shadow.gold,
  },
  addReviewBtnDisabled: { backgroundColor: Colors.surface, borderWidth: 1, borderColor: Colors.border },
  addReviewText: { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: Colors.primary },

  // Rating overview card
  ratingOverviewCard: {
    flexDirection: 'row', backgroundColor: Colors.surface,
    borderRadius: Radius.xl, borderWidth: 1, borderColor: Colors.border,
    padding: Spacing.md, gap: Spacing.md, alignItems: 'center',
  },
  ratingScoreCol: { alignItems: 'center', gap: 4, minWidth: 70 },
  bigScore: { fontSize: 42, fontWeight: FontWeight.bold, color: Colors.gold, lineHeight: 48 },
  starsRow: { flexDirection: 'row', gap: 1 },
  ratingTotalText: { fontSize: FontSize.xs, color: Colors.textMuted },
  ratingBarsCol: { flex: 1, gap: 5 },
  ratingBarRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  ratingBarStarRow: { flexDirection: 'row', alignItems: 'center', gap: 1, minWidth: 22 },
  ratingBarStar: { fontSize: 11, color: Colors.textMuted },
  ratingBarTrack: {
    flex: 1, height: 6, backgroundColor: Colors.surface2,
    borderRadius: 3, overflow: 'hidden',
  },
  ratingBarFill: { height: '100%', backgroundColor: Colors.gold, borderRadius: 3 },
  ratingBarCount: { fontSize: 10, color: Colors.textMuted, minWidth: 14, textAlign: 'right' },

  // Review form
  reviewFormCard: {
    backgroundColor: Colors.surface, borderRadius: Radius.xl,
    borderWidth: 1.5, borderColor: 'rgba(212,160,23,0.5)',
    padding: Spacing.md, gap: Spacing.md,
    ...Shadow.md,
  },
  reviewFormTitle: {
    fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: Colors.text,
    textAlign: 'center',
  },
  reviewFormStarsSection: { alignItems: 'center', gap: Spacing.sm },
  reviewFormLabel: {
    fontSize: FontSize.base, color: Colors.textMuted, fontWeight: FontWeight.medium, textAlign: 'center',
  },
  reviewInput: {
    backgroundColor: Colors.surface2, borderRadius: Radius.md,
    borderWidth: 1, borderColor: Colors.border,
    paddingHorizontal: Spacing.md, paddingVertical: Spacing.sm,
    color: Colors.text, fontSize: FontSize.base,
    minHeight: 100, textAlignVertical: 'top',
  },
  charCount: { fontSize: FontSize.xs, color: Colors.textMuted, textAlign: 'left' },
  reviewFormActions: { flexDirection: 'row', gap: Spacing.sm },
  cancelReviewBtn: {
    flex: 1, paddingVertical: 12, borderRadius: Radius.lg,
    borderWidth: 1, borderColor: Colors.border,
    alignItems: 'center', justifyContent: 'center',
  },
  cancelReviewText: { color: Colors.textMuted, fontSize: FontSize.base, fontWeight: FontWeight.medium },
  submitReviewBtn: {
    flex: 2, backgroundColor: Colors.gold, borderRadius: Radius.lg,
    paddingVertical: 12, flexDirection: 'row', alignItems: 'center',
    justifyContent: 'center', gap: 6, ...Shadow.gold,
  },
  submitReviewText: { color: Colors.primary, fontWeight: FontWeight.bold, fontSize: FontSize.base },

  // Reviews list
  reviewsList: { gap: Spacing.sm },
  reviewCard: {
    backgroundColor: Colors.surface, borderRadius: Radius.xl,
    borderWidth: 1, borderColor: Colors.border, padding: Spacing.md, gap: Spacing.sm,
  },
  reviewCardFirst: { borderColor: 'rgba(212,160,23,0.35)', backgroundColor: 'rgba(212,160,23,0.03)' },
  reviewHeader: { gap: 6 },
  reviewUserRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-end', gap: Spacing.sm },
  reviewAvatar: {
    width: 34, height: 34, borderRadius: 17,
    backgroundColor: Colors.primarySurface, borderWidth: 1.5, borderColor: Colors.gold,
    alignItems: 'center', justifyContent: 'center',
  },
  reviewAvatarText: { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: Colors.gold },
  reviewName: { fontSize: FontSize.base, fontWeight: FontWeight.semibold, color: Colors.text },
  reviewStarsRow: { flexDirection: 'row', gap: 2 },
  reviewDate: { fontSize: FontSize.xs, color: Colors.textMuted, textAlign: 'right' },
  reviewComment: { fontSize: FontSize.base, color: Colors.textMuted, lineHeight: 24, textAlign: 'right' },
  ratingChip: {
    alignSelf: 'flex-end', paddingHorizontal: 10, paddingVertical: 3, borderRadius: Radius.full,
  },
  ratingChipText: { fontSize: 11, fontWeight: FontWeight.bold },

  reviewsLoading: { alignItems: 'center', gap: Spacing.sm, paddingVertical: Spacing.lg },
  emptyReviews: {
    alignItems: 'center', gap: Spacing.sm, paddingVertical: Spacing.xl,
    backgroundColor: Colors.surface, borderRadius: Radius.xl,
    borderWidth: 1, borderColor: Colors.border,
  },
  emptyReviewsTitle: { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: Colors.text },
  emptyReviewsSub: { fontSize: FontSize.sm, color: Colors.textMuted },
  firstReviewBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    backgroundColor: Colors.gold, borderRadius: Radius.full,
    paddingHorizontal: 18, paddingVertical: 10, marginTop: Spacing.sm,
    ...Shadow.gold,
  },
  firstReviewText: { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: Colors.primary },

  // Bottom action bar
  actionBar: {
    flexDirection: 'row', gap: Spacing.sm,
    paddingHorizontal: Spacing.lg, paddingTop: Spacing.md,
    backgroundColor: Colors.background,
    borderTopWidth: 1, borderTopColor: Colors.divider,
  },
  requestBtn: { flex: 1, borderRadius: Radius.lg, overflow: 'hidden' },
  requestBtnInner: {
    backgroundColor: Colors.gold, borderRadius: Radius.lg,
    paddingVertical: 15, flexDirection: 'row',
    alignItems: 'center', justifyContent: 'center', gap: 8, ...Shadow.gold,
  },
  requestBtnText: { fontSize: FontSize.base, fontWeight: FontWeight.bold, color: Colors.primary },
  iconBtn: {
    width: 52, height: 52, borderRadius: Radius.md,
    backgroundColor: Colors.surface, alignItems: 'center', justifyContent: 'center',
    borderWidth: 1, borderColor: Colors.border,
  },
});
