import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, StyleSheet, FlatList, Pressable, TextInput,
  ActivityIndicator, ScrollView,
} from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import { Colors, FontSize, FontWeight, Radius, Spacing, Shadow } from '@/constants/theme';
import { ARAB_COUNTRIES, EXPERIENCE_OPTIONS } from '@/constants/arabCountries';
import { useApp } from '@/hooks/useApp';
import { getSupabaseClient } from '@/template';

// ─── Types ────────────────────────────────────────────────────────────────────
interface CraftsmanRow {
  id: string;
  name: string;
  specialty: string;
  specialty_icon: string;
  rating: number;
  review_count: number;
  city: string;
  country: string;
  address_detail: string | null;
  available: boolean;
  experience: number;
  price_range: string;
  image_url: string | null;
  completed_jobs: number;
}

// ─── Filter options ───────────────────────────────────────────────────────────
const AVAILABILITY = [
  { key: 'all', label: 'الكل' },
  { key: 'available', label: 'متاح الآن' },
];

const RATINGS = [
  { key: 'all', label: 'أي تقييم' },
  { key: '4.5', label: '4.5+ ⭐' },
  { key: '4.0', label: '4.0+ ⭐' },
  { key: '3.0', label: '3.0+ ⭐' },
];

const SORT_OPTIONS = [
  { key: 'rating', label: 'الأعلى تقييماً' },
  { key: 'experience', label: 'الأكثر خبرة' },
  { key: 'jobs', label: 'الأكثر إنجازاً' },
];

const SPECIALTIES = [
  { key: 'all', label: 'جميع التخصصات', icon: 'apps' },
  { key: 'كهربائي', label: 'كهربائي', icon: 'flash-on' },
  { key: 'سباك', label: 'سباك', icon: 'water-drop' },
  { key: 'نجار', label: 'نجار', icon: 'build' },
  { key: 'دهان', label: 'دهان', icon: 'brush' },
  { key: 'مكيفات', label: 'مكيفات', icon: 'ac-unit' },
  { key: 'شمسية', label: 'طاقة شمسية', icon: 'wb-sunny' },
];

// Min experience filter options
const EXP_FILTERS = [
  { key: 'all', label: 'أي خبرة' },
  { key: '3', label: '3+ سنوات' },
  { key: '7', label: '7+ سنوات' },
  { key: '15', label: '10+ سنوات' },
  { key: '25', label: '20+ سنة' },
  { key: '30', label: '30+ سنة' },
];

export default function CraftsmenScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { country: paramCountry } = useLocalSearchParams<{ country?: string }>();
  const { toggleFavorite, isFavorite } = useApp();
  const supabase = getSupabaseClient();

  const [craftsmen, setCraftsmen] = useState<CraftsmanRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  // Filters
  const [search, setSearch] = useState('');
  const [activeSpecialty, setActiveSpecialty] = useState('all');
  const [activeAvail, setActiveAvail] = useState('all');
  const [activeRating, setActiveRating] = useState('all');
  const [activeCountry, setActiveCountry] = useState(paramCountry ? decodeURIComponent(paramCountry) : 'الكل');
  const [activeProvince, setActiveProvince] = useState('الكل');
  const [activeExp, setActiveExp] = useState('all');
  const [sortBy, setSortBy] = useState('rating');
  const [showFilters, setShowFilters] = useState(false);
  const [filterTab, setFilterTab] = useState<'basic' | 'location' | 'exp'>('basic');

  const countryProvinces = activeCountry !== 'الكل'
    ? ['الكل', ...(ARAB_COUNTRIES.find(c => c.name === activeCountry)?.provinces ?? [])]
    : ['الكل'];

  // ── Fetch from DB ─────────────────────────────────────────────────────────
  const fetchCraftsmen = useCallback(async (isRefresh = false) => {
    if (isRefresh) setRefreshing(true);
    else setLoading(true);

    let query = supabase
      .from('craftsmen')
      .select('id, name, specialty, specialty_icon, rating, review_count, city, country, address_detail, available, experience, price_range, image_url, completed_jobs')
      .eq('is_active', true);

    if (activeAvail === 'available') query = query.eq('available', true);
    if (activeRating !== 'all') query = query.gte('rating', parseFloat(activeRating));
    if (activeCountry !== 'الكل') query = query.eq('country', activeCountry);
    if (activeProvince !== 'الكل') query = query.eq('city', activeProvince);
    if (activeSpecialty !== 'all') query = query.ilike('specialty', `%${activeSpecialty}%`);
    if (activeExp !== 'all') query = query.gte('experience', parseInt(activeExp));
    if (sortBy === 'rating') query = query.order('rating', { ascending: false });
    else if (sortBy === 'experience') query = query.order('experience', { ascending: false });
    else if (sortBy === 'jobs') query = query.order('completed_jobs', { ascending: false });

    const { data, error } = await query;
    if (!error && data) setCraftsmen(data as CraftsmanRow[]);
    setLoading(false);
    setRefreshing(false);
  }, [activeAvail, activeRating, activeCountry, activeProvince, activeSpecialty, activeExp, sortBy]);

  useEffect(() => { fetchCraftsmen(); }, [fetchCraftsmen]);

  const filtered = craftsmen.filter(c => {
    if (!search) return true;
    const q = search.toLowerCase();
    return (
      c.name.includes(search) ||
      c.specialty.includes(search) ||
      c.city.includes(search) ||
      (c.country ?? '').includes(search) ||
      c.name.toLowerCase().includes(q) ||
      c.specialty.toLowerCase().includes(q)
    );
  });

  const getExperienceLabel = (years: number) => {
    const opt = EXPERIENCE_OPTIONS.slice().reverse().find(e => years >= e.value);
    return opt ? opt.label : `${years} سنة`;
  };

  const activeFiltersCount = [
    activeAvail !== 'all', activeRating !== 'all',
    activeCountry !== 'الكل', activeProvince !== 'الكل',
    activeSpecialty !== 'all', activeExp !== 'all',
  ].filter(Boolean).length;

  // ── Render card ───────────────────────────────────────────────────────────
  const renderCraftsman = ({ item }: { item: CraftsmanRow }) => {
    const img = item.image_url ?? 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400';
    const countryFlag = ARAB_COUNTRIES.find(c => c.name === item.country)?.flag ?? '';
    const expLabel = getExperienceLabel(item.experience);
    const locationText = item.country
      ? `${countryFlag} ${item.city}`
      : item.city;

    return (
      <Pressable style={styles.card} onPress={() => router.push(`/craftsmen/${item.id}` as any)}>
        {({ pressed }) => (
          <View style={[styles.cardInner, pressed && { opacity: 0.9 }]}>
            <View style={styles.imageArea}>
              <Image source={{ uri: img }} style={styles.img} contentFit="cover" />
              <View style={[styles.availBadgeImg, { backgroundColor: item.available ? 'rgba(46,204,113,0.85)' : 'rgba(231,76,60,0.75)' }]}>
                <View style={styles.dot} />
                <Text style={styles.availBadgeText}>{item.available ? 'متاح' : 'مشغول'}</Text>
              </View>
              <Pressable style={styles.favBtn} onPress={() => toggleFavorite(item.id)}>
                <MaterialIcons
                  name={isFavorite(item.id) ? 'favorite' : 'favorite-border'}
                  size={16}
                  color={isFavorite(item.id) ? '#E74C3C' : Colors.text}
                />
              </Pressable>
              {/* Experience badge */}
              {item.experience >= 30 && (
                <View style={styles.expertBadge}>
                  <MaterialIcons name="workspace-premium" size={11} color={Colors.gold} />
                  <Text style={styles.expertBadgeText}>خبير</Text>
                </View>
              )}
            </View>

            <View style={styles.info}>
              <View style={styles.infoTop}>
                <View style={styles.ratingBadge}>
                  <Text style={styles.ratingNum}>{item.rating.toFixed(1)}</Text>
                  <MaterialIcons name="star" size={12} color={Colors.gold} />
                </View>
                <View style={styles.nameCol}>
                  <Text style={styles.name} numberOfLines={1}>{item.name}</Text>
                  <Text style={styles.specialty}>{item.specialty}</Text>
                </View>
              </View>

              <View style={styles.statsRow}>
                <View style={styles.statItem}>
                  <MaterialIcons name="work-history" size={13} color={Colors.gold} />
                  <Text style={styles.statText}>{expLabel}</Text>
                </View>
                <View style={styles.statItem}>
                  <MaterialIcons name="location-on" size={13} color={Colors.textMuted} />
                  <Text style={styles.statText} numberOfLines={1}>{locationText}</Text>
                </View>
              </View>

              {item.address_detail ? (
                <View style={styles.addressRow}>
                  <MaterialIcons name="place" size={11} color={Colors.textMuted} />
                  <Text style={styles.addressText} numberOfLines={1}>{item.address_detail}</Text>
                </View>
              ) : null}

              <View style={styles.statsRow}>
                <View style={styles.statItem}>
                  <MaterialIcons name="check-circle" size={13} color={Colors.success} />
                  <Text style={styles.statText}>{item.completed_jobs} إنجاز</Text>
                </View>
                <Text style={styles.price}>{item.price_range}</Text>
              </View>

              <Text style={styles.reviewCount}>({item.review_count} تقييم)</Text>

              <View style={styles.actionRow}>
                <Pressable style={styles.contactBtn} onPress={() => router.push(`/chat/${item.id}` as any)}>
                  <MaterialIcons name="chat" size={14} color={Colors.gold} />
                  <Text style={styles.contactBtnText}>تواصل</Text>
                </Pressable>
                <Pressable style={styles.requestBtn} onPress={() => router.push('/request/new' as any)}>
                  <Text style={styles.requestBtnText}>طلب خدمة</Text>
                </Pressable>
              </View>
            </View>
          </View>
        )}
      </Pressable>
    );
  };

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <StatusBar style="light" />

      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>الحرفيون</Text>
        <Pressable style={styles.backBtn} onPress={() => router.back()}>
          <MaterialIcons name="arrow-forward" size={22} color={Colors.text} />
        </Pressable>
      </View>

      {/* Search Row */}
      <View style={styles.searchRow}>
        <Pressable
          style={[styles.filterToggleBtn, activeFiltersCount > 0 && styles.filterToggleBtnActive]}
          onPress={() => setShowFilters(v => !v)}
        >
          <MaterialIcons name="tune" size={20} color={activeFiltersCount > 0 ? Colors.primary : Colors.gold} />
          {activeFiltersCount > 0 && (
            <View style={styles.filterCountBadge}>
              <Text style={styles.filterCountText}>{activeFiltersCount}</Text>
            </View>
          )}
        </Pressable>
        <View style={styles.searchBar}>
          <MaterialIcons name="search" size={20} color={Colors.textMuted} />
          <TextInput
            style={styles.searchInput}
            value={search}
            onChangeText={setSearch}
            placeholder="ابحث عن حرفي، تخصص، دولة، محافظة..."
            placeholderTextColor={Colors.textMuted}
            textAlign="right"
          />
          {search ? (
            <Pressable onPress={() => setSearch('')}>
              <MaterialIcons name="close" size={18} color={Colors.textMuted} />
            </Pressable>
          ) : null}
        </View>
      </View>

      {/* Specialty Chips */}
      <View style={styles.specialtyBarOuter}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.specialtyBarInner}
        >
          {SPECIALTIES.map(sp => (
            <Pressable
              key={sp.key}
              style={[styles.specChip, activeSpecialty === sp.key && styles.specChipActive]}
              onPress={() => setActiveSpecialty(sp.key)}
            >
              <MaterialIcons name={sp.icon as any} size={14} color={activeSpecialty === sp.key ? Colors.primary : Colors.gold} />
              <Text style={[styles.specChipText, activeSpecialty === sp.key && styles.specChipTextActive]}>
                {sp.label}
              </Text>
            </Pressable>
          ))}
        </ScrollView>
      </View>

      {/* Expanded Filters Panel */}
      {showFilters && (
        <View style={styles.filtersPanel}>
          {/* Filter tab switcher */}
          <View style={styles.filterTabRow}>
            {[
              { key: 'basic', label: 'أساسي' },
              { key: 'location', label: 'الموقع' },
              { key: 'exp', label: 'الخبرة' },
            ].map(ft => (
              <Pressable
                key={ft.key}
                style={[styles.filterTabBtn, filterTab === ft.key && styles.filterTabBtnActive]}
                onPress={() => setFilterTab(ft.key as any)}
              >
                <Text style={[styles.filterTabText, filterTab === ft.key && styles.filterTabTextActive]}>
                  {ft.label}
                </Text>
              </Pressable>
            ))}
          </View>

          {/* Basic filters */}
          {filterTab === 'basic' && (
            <>
              <View style={styles.filterGroup}>
                <Text style={styles.filterGroupLabel}>التوفر</Text>
                <View style={styles.filterChips}>
                  {AVAILABILITY.map(av => (
                    <Pressable
                      key={av.key}
                      style={[styles.filterChip, activeAvail === av.key && styles.filterChipActive]}
                      onPress={() => setActiveAvail(av.key)}
                    >
                      <Text style={[styles.filterChipText, activeAvail === av.key && styles.filterChipTextActive]}>{av.label}</Text>
                    </Pressable>
                  ))}
                </View>
              </View>
              <View style={styles.filterGroup}>
                <Text style={styles.filterGroupLabel}>التقييم</Text>
                <View style={styles.filterChips}>
                  {RATINGS.map(r => (
                    <Pressable
                      key={r.key}
                      style={[styles.filterChip, activeRating === r.key && styles.filterChipActive]}
                      onPress={() => setActiveRating(r.key)}
                    >
                      <Text style={[styles.filterChipText, activeRating === r.key && styles.filterChipTextActive]}>{r.label}</Text>
                    </Pressable>
                  ))}
                </View>
              </View>
              <View style={styles.filterGroup}>
                <Text style={styles.filterGroupLabel}>ترتيب حسب</Text>
                <View style={styles.filterChips}>
                  {SORT_OPTIONS.map(s => (
                    <Pressable
                      key={s.key}
                      style={[styles.filterChip, sortBy === s.key && styles.filterChipActive]}
                      onPress={() => setSortBy(s.key)}
                    >
                      <Text style={[styles.filterChipText, sortBy === s.key && styles.filterChipTextActive]}>{s.label}</Text>
                    </Pressable>
                  ))}
                </View>
              </View>
            </>
          )}

          {/* Location filters */}
          {filterTab === 'location' && (
            <>
              <View style={styles.filterGroup}>
                <Text style={styles.filterGroupLabel}>الدولة</Text>
                <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: Spacing.sm }}>
                  {['الكل', ...ARAB_COUNTRIES.map(c => c.name)].map(c => {
                    const flag = c !== 'الكل' ? (ARAB_COUNTRIES.find(x => x.name === c)?.flag ?? '') : '🌍';
                    return (
                      <Pressable
                        key={c}
                        style={[styles.filterChip, activeCountry === c && styles.filterChipActive]}
                        onPress={() => { setActiveCountry(c); setActiveProvince('الكل'); }}
                      >
                        <Text style={[styles.filterChipText, activeCountry === c && styles.filterChipTextActive]}>
                          {flag} {c}
                        </Text>
                      </Pressable>
                    );
                  })}
                </ScrollView>
              </View>

              {activeCountry !== 'الكل' && (
                <View style={styles.filterGroup}>
                  <Text style={styles.filterGroupLabel}>المحافظة / المنطقة</Text>
                  <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: Spacing.sm }}>
                    {countryProvinces.map(p => (
                      <Pressable
                        key={p}
                        style={[styles.filterChip, activeProvince === p && styles.filterChipActive]}
                        onPress={() => setActiveProvince(p)}
                      >
                        <Text style={[styles.filterChipText, activeProvince === p && styles.filterChipTextActive]}>{p}</Text>
                      </Pressable>
                    ))}
                  </ScrollView>
                </View>
              )}
            </>
          )}

          {/* Experience filter */}
          {filterTab === 'exp' && (
            <View style={styles.filterGroup}>
              <Text style={styles.filterGroupLabel}>الحد الأدنى من الخبرة</Text>
              <View style={styles.filterChips}>
                {EXP_FILTERS.map(e => (
                  <Pressable
                    key={e.key}
                    style={[styles.filterChip, activeExp === e.key && styles.filterChipActive]}
                    onPress={() => setActiveExp(e.key)}
                  >
                    <Text style={[styles.filterChipText, activeExp === e.key && styles.filterChipTextActive]}>
                      {e.label}
                    </Text>
                  </Pressable>
                ))}
              </View>
            </View>
          )}

          {activeFiltersCount > 0 && (
            <Pressable
              style={styles.resetBtn}
              onPress={() => {
                setActiveAvail('all'); setActiveRating('all');
                setActiveCountry('الكل'); setActiveProvince('الكل');
                setActiveSpecialty('all'); setActiveExp('all'); setSortBy('rating');
                setShowFilters(false);
              }}
            >
              <MaterialIcons name="refresh" size={16} color={Colors.error} />
              <Text style={styles.resetBtnText}>إعادة ضبط الفلاتر ({activeFiltersCount})</Text>
            </Pressable>
          )}
        </View>
      )}

      {/* Results count */}
      <View style={styles.resultsRow}>
        <Text style={styles.resultsCount}>
          {loading ? '...' : `${filtered.length} حرفي`}
          {activeCountry !== 'الكل' ? ` في ${activeCountry}` : ''}
        </Text>
        <Text style={styles.sortLabel}>{SORT_OPTIONS.find(s => s.key === sortBy)?.label}</Text>
      </View>

      {loading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={Colors.gold} />
          <Text style={styles.loadingText}>جاري البحث...</Text>
        </View>
      ) : (
        <FlatList
          data={filtered}
          keyExtractor={i => i.id}
          renderItem={renderCraftsman}
          contentContainerStyle={{ paddingHorizontal: Spacing.lg, paddingBottom: 24, gap: Spacing.md }}
          showsVerticalScrollIndicator={false}
          onRefresh={() => fetchCraftsmen(true)}
          refreshing={refreshing}
          ListEmptyComponent={
            <View style={styles.empty}>
              <MaterialIcons name="search-off" size={52} color={Colors.textMuted} />
              <Text style={styles.emptyTitle}>لا توجد نتائج</Text>
              <Text style={styles.emptyText}>جرّب تغيير الدولة أو الفلاتر أو كلمة البحث</Text>
              <Pressable style={styles.clearBtn} onPress={() => {
                setSearch(''); setActiveSpecialty('all'); setActiveAvail('all');
                setActiveRating('all'); setActiveCountry('الكل'); setActiveProvince('الكل');
                setActiveExp('all');
              }}>
                <Text style={styles.clearBtnText}>مسح جميع الفلاتر</Text>
              </Pressable>
            </View>
          }
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: Spacing.lg, paddingVertical: Spacing.md,
    borderBottomWidth: 1, borderBottomColor: Colors.divider,
  },
  headerTitle: { fontSize: FontSize.xxl, fontWeight: FontWeight.bold, color: Colors.text },
  backBtn: { width: 40, height: 40, borderRadius: 20, backgroundColor: Colors.surface, alignItems: 'center', justifyContent: 'center' },

  searchRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, paddingHorizontal: Spacing.lg, paddingVertical: Spacing.sm },
  searchBar: {
    flex: 1, flexDirection: 'row', alignItems: 'center', gap: Spacing.sm,
    backgroundColor: Colors.surface, borderRadius: Radius.lg, borderWidth: 1, borderColor: Colors.border,
    paddingHorizontal: Spacing.md, paddingVertical: 11,
  },
  searchInput: { flex: 1, color: Colors.text, fontSize: FontSize.base },
  filterToggleBtn: { width: 44, height: 44, borderRadius: Radius.md, backgroundColor: Colors.surface, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: Colors.border, position: 'relative' },
  filterToggleBtnActive: { backgroundColor: Colors.gold, borderColor: Colors.gold },
  filterCountBadge: { position: 'absolute', top: 4, right: 4, width: 16, height: 16, borderRadius: 8, backgroundColor: Colors.error, alignItems: 'center', justifyContent: 'center' },
  filterCountText: { fontSize: 9, fontWeight: FontWeight.bold, color: Colors.text },

  specialtyBarOuter: { height: 50 },
  specialtyBarInner: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: Spacing.lg, gap: Spacing.sm, height: 50 },
  specChip: { flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 12, paddingVertical: 8, backgroundColor: Colors.surface, borderRadius: Radius.full, borderWidth: 1, borderColor: Colors.border },
  specChipActive: { backgroundColor: Colors.gold, borderColor: Colors.gold },
  specChipText: { fontSize: FontSize.xs, color: Colors.textMuted, fontWeight: FontWeight.medium },
  specChipTextActive: { color: Colors.primary, fontWeight: FontWeight.bold },

  filtersPanel: { backgroundColor: Colors.surface, borderBottomWidth: 1, borderBottomColor: Colors.divider, paddingHorizontal: Spacing.lg, paddingBottom: Spacing.md, gap: Spacing.md, paddingTop: Spacing.sm },
  filterTabRow: { flexDirection: 'row', gap: Spacing.sm },
  filterTabBtn: { flex: 1, paddingVertical: 8, borderRadius: Radius.full, backgroundColor: Colors.surface2, alignItems: 'center', borderWidth: 1, borderColor: Colors.border },
  filterTabBtnActive: { backgroundColor: Colors.gold, borderColor: Colors.gold },
  filterTabText: { fontSize: FontSize.xs, color: Colors.textMuted, fontWeight: FontWeight.medium },
  filterTabTextActive: { color: Colors.primary, fontWeight: FontWeight.bold },
  filterGroup: { gap: Spacing.sm },
  filterGroupLabel: { fontSize: FontSize.xs, color: Colors.gold, fontWeight: FontWeight.semibold, textAlign: 'right' },
  filterChips: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm, justifyContent: 'flex-end' },
  filterChip: { paddingHorizontal: 12, paddingVertical: 7, backgroundColor: Colors.surface2, borderRadius: Radius.full, borderWidth: 1, borderColor: Colors.border },
  filterChipActive: { backgroundColor: Colors.gold, borderColor: Colors.gold },
  filterChipText: { fontSize: FontSize.xs, color: Colors.textMuted, fontWeight: FontWeight.medium },
  filterChipTextActive: { color: Colors.primary, fontWeight: FontWeight.bold },
  resetBtn: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xs, alignSelf: 'center', paddingVertical: 6, paddingHorizontal: Spacing.md, borderRadius: Radius.full, borderWidth: 1, borderColor: Colors.error },
  resetBtnText: { fontSize: FontSize.xs, color: Colors.error, fontWeight: FontWeight.medium },

  resultsRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: Spacing.lg, paddingVertical: Spacing.sm },
  resultsCount: { fontSize: FontSize.sm, color: Colors.textMuted, textAlign: 'right' },
  sortLabel: { fontSize: FontSize.xs, color: Colors.textMuted },
  loadingContainer: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: Spacing.md },
  loadingText: { color: Colors.textMuted, fontSize: FontSize.base },

  card: { borderRadius: Radius.xl, overflow: 'hidden' },
  cardInner: { flexDirection: 'row', backgroundColor: Colors.surface, borderRadius: Radius.xl, borderWidth: 1, borderColor: Colors.border, ...Shadow.sm },
  imageArea: { position: 'relative', width: 110 },
  img: { width: 110, height: 185, borderTopRightRadius: Radius.xl, borderBottomRightRadius: Radius.xl },
  availBadgeImg: { position: 'absolute', bottom: 8, right: 6, flexDirection: 'row', alignItems: 'center', gap: 3, borderRadius: Radius.full, paddingHorizontal: 7, paddingVertical: 3 },
  dot: { width: 5, height: 5, borderRadius: 3, backgroundColor: Colors.text },
  availBadgeText: { fontSize: 9, color: Colors.text, fontWeight: FontWeight.bold },
  favBtn: { position: 'absolute', top: 8, right: 8, width: 28, height: 28, borderRadius: 14, backgroundColor: 'rgba(0,0,0,0.5)', alignItems: 'center', justifyContent: 'center' },
  expertBadge: {
    position: 'absolute', top: 8, left: 6,
    flexDirection: 'row', alignItems: 'center', gap: 2,
    backgroundColor: 'rgba(212,160,23,0.85)', borderRadius: Radius.full,
    paddingHorizontal: 6, paddingVertical: 3,
  },
  expertBadgeText: { fontSize: 9, color: Colors.primary, fontWeight: FontWeight.bold },

  info: { flex: 1, padding: Spacing.sm, gap: 4, justifyContent: 'space-between' },
  infoTop: { flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'flex-end', gap: Spacing.sm },
  nameCol: { alignItems: 'flex-end', flex: 1 },
  name: { fontSize: FontSize.base, fontWeight: FontWeight.bold, color: Colors.text, textAlign: 'right' },
  specialty: { fontSize: FontSize.xs, color: Colors.gold, textAlign: 'right' },
  ratingBadge: { flexDirection: 'row', alignItems: 'center', gap: 2, backgroundColor: Colors.goldSoft, borderRadius: Radius.full, paddingHorizontal: 7, paddingVertical: 4 },
  ratingNum: { fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: Colors.gold },
  statsRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  statItem: { flexDirection: 'row', alignItems: 'center', gap: 3, flex: 1 },
  statText: { fontSize: 11, color: Colors.textMuted, flex: 1 },
  addressRow: { flexDirection: 'row', alignItems: 'center', gap: 3 },
  addressText: { fontSize: 10, color: Colors.textMuted, flex: 1, textAlign: 'right' },
  price: { fontSize: FontSize.xs, color: Colors.success, fontWeight: FontWeight.semibold },
  reviewCount: { fontSize: 10, color: Colors.textMuted, textAlign: 'right' },
  actionRow: { flexDirection: 'row', gap: Spacing.xs, marginTop: 2 },
  requestBtn: { flex: 1, backgroundColor: Colors.gold, borderRadius: Radius.md, paddingVertical: 8, alignItems: 'center' },
  requestBtnText: { fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: Colors.primary },
  contactBtn: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: Colors.goldSoft, borderRadius: Radius.md, paddingVertical: 8, paddingHorizontal: 10, borderWidth: 1, borderColor: 'rgba(212,160,23,0.2)' },
  contactBtnText: { fontSize: FontSize.xs, fontWeight: FontWeight.semibold, color: Colors.gold },

  empty: { alignItems: 'center', paddingTop: 60, gap: Spacing.md },
  emptyTitle: { fontSize: FontSize.xl, fontWeight: FontWeight.bold, color: Colors.text },
  emptyText: { fontSize: FontSize.sm, color: Colors.textMuted, textAlign: 'center' },
  clearBtn: { backgroundColor: Colors.gold, borderRadius: Radius.lg, paddingVertical: 11, paddingHorizontal: Spacing.xl },
  clearBtnText: { color: Colors.primary, fontWeight: FontWeight.bold, fontSize: FontSize.sm },
});
