import React, { useState, useRef, useEffect } from 'react';
import {
  View, Text, StyleSheet, ScrollView, Pressable, TextInput,
  KeyboardAvoidingView, Platform, Dimensions, Alert, ActivityIndicator,
} from 'react-native';
import { useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import * as ImagePicker from 'expo-image-picker';
import * as Location from 'expo-location';
import { MapViewComponent as MapView, Marker, PROVIDER_DEFAULT, Region } from '@/components/MapWrapper';
import { Colors, FontSize, FontWeight, Radius, Spacing, Shadow } from '@/constants/theme';
import { serviceCategories } from '@/constants/mockData';
import { useApp } from '@/hooks/useApp';
import { useAlert } from '@/template';
import type { AutoAssignResult } from '@/contexts/AppContext';

const { width } = Dimensions.get('window');
const STEPS = ['نوع الخدمة', 'وصف المشكلة', 'الموقع', 'الوقت', 'التأكيد'];

const TIME_SLOTS = [
  'الآن (طارئ)', '8:00 ص', '10:00 ص', '12:00 م',
  '2:00 م', '4:00 م', '6:00 م', '8:00 م',
];

const DEFAULT_REGION: Region = {
  latitude: 24.7136,
  longitude: 46.6753,
  latitudeDelta: 0.05,
  longitudeDelta: 0.05,
};

interface Coord { latitude: number; longitude: number; }

export default function NewRequestScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { addOrder } = useApp();
  const { showAlert } = useAlert();
  const mapRef = useRef<any>(null);

  const [step, setStep] = useState(0);
  const [selectedService, setSelectedService] = useState<string | null>(null);
  const [description, setDescription] = useState('');
  const [address, setAddress] = useState('');
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [photos, setPhotos] = useState<string[]>([]);

  // Map state
  const [region, setRegion] = useState<Region>(DEFAULT_REGION);
  const [markerCoord, setMarkerCoord] = useState<Coord | null>(null);
  const [locating, setLocating] = useState(false);

  // Auto-assign result state
  const [assignResult, setAssignResult] = useState<AutoAssignResult | null>(null);

  const pickPhoto = async (source: 'camera' | 'gallery') => {
    let result: ImagePicker.ImagePickerResult;
    if (source === 'camera') {
      const { status } = await ImagePicker.requestCameraPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('الكاميرا', 'يرجى السماح للتطبيق باستخدام الكاميرا');
        return;
      }
      result = await ImagePicker.launchCameraAsync({ mediaTypes: 'images', quality: 0.7, allowsEditing: true });
    } else {
      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('المعرض', 'يرجى السماح للتطبيق بالوصول إلى معرض الصور');
        return;
      }
      result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: 'images', quality: 0.7, allowsEditing: true, allowsMultipleSelection: true });
    }
    if (result.canceled || !result.assets?.length) return;
    const uris = result.assets.map(a => a.uri);
    setPhotos(prev => [...prev, ...uris].slice(0, 5));
  };

  const showPickerOptions = () => {
    Alert.alert('إضافة صورة', 'اختر المصدر', [
      { text: 'الكاميرا', onPress: () => pickPhoto('camera') },
      { text: 'معرض الصور', onPress: () => pickPhoto('gallery') },
      { text: 'إلغاء', style: 'cancel' },
    ]);
  };

  // ── GPS Location ──────────────────────────────────────────────────────────
  const goToMyLocation = async () => {
    setLocating(true);
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('الموقع', 'يرجى السماح للتطبيق بالوصول إلى موقعك');
        setLocating(false);
        return;
      }
      const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High });
      const { latitude, longitude } = loc.coords;
      const newRegion: Region = { latitude, longitude, latitudeDelta: 0.01, longitudeDelta: 0.01 };
      setRegion(newRegion);
      setMarkerCoord({ latitude, longitude });
      mapRef.current?.animateToRegion(newRegion, 600);

      const geo = await Location.reverseGeocodeAsync({ latitude, longitude });
      if (geo.length > 0) {
        const g = geo[0];
        const parts = [g.district, g.city, g.country].filter(Boolean);
        setAddress(parts.join('، '));
      } else {
        setAddress(`${latitude.toFixed(5)}, ${longitude.toFixed(5)}`);
      }
    } catch {
      Alert.alert('خطأ', 'تعذر تحديد الموقع، حاول مرة أخرى');
    } finally {
      setLocating(false);
    }
  };

  const handleMapPress = async (e: any) => {
    const { latitude, longitude } = e.nativeEvent.coordinate;
    setMarkerCoord({ latitude, longitude });
    try {
      const geo = await Location.reverseGeocodeAsync({ latitude, longitude });
      if (geo.length > 0) {
        const g = geo[0];
        const parts = [g.district, g.city, g.country].filter(Boolean);
        setAddress(parts.join('، '));
      } else {
        setAddress(`${latitude.toFixed(5)}, ${longitude.toFixed(5)}`);
      }
    } catch {
      setAddress(`${latitude.toFixed(5)}, ${longitude.toFixed(5)}`);
    }
  };

  const canNext = () => {
    if (step === 0) return !!selectedService;
    if (step === 1) return description.length >= 10;
    if (step === 2) return address.length > 3;
    if (step === 3) return !!selectedTime;
    return true;
  };

  const handleNext = () => {
    if (step < STEPS.length - 1) setStep(s => s + 1);
  };

  const handleBack = () => {
    if (step > 0) setStep(s => s - 1);
    else router.back();
  };

  // ── Submit with Auto-Assignment ──────────────────────────────────────────
  const handleSubmit = async () => {
    if (!selectedService || !description || !address || !selectedTime) return;
    setSubmitting(true);
    setAssignResult(null);

    try {
      const result = await addOrder({
        service: selectedService,
        status: 'pending' as const,
        craftsmanName: '',
        craftsmanImage: '',
        price: 'سيتم التحديد',
        address,
        description,
        latitude: markerCoord?.latitude ?? null,
        longitude: markerCoord?.longitude ?? null,
        scheduledAt: selectedTime !== 'الآن (طارئ)' ? selectedTime : undefined,
      } as any);

      setAssignResult(result);

      if (result.success) {
        showAlert(
          'تم إرسال طلبك وتعيين حرفي! 🎉',
          result.message,
          [
            {
              text: 'عرض الطلب',
              onPress: () => router.replace('/(tabs)/orders' as any),
            },
          ]
        );
      } else {
        // Order created but no craftsman found — still success for the order
        showAlert(
          'تم إرسال طلبك ✓',
          result.message + '\nسيتم إشعارك فور توفر حرفي.',
          [
            {
              text: 'حسناً',
              onPress: () => router.replace('/(tabs)/orders' as any),
            },
          ]
        );
      }
    } catch {
      showAlert('خطأ', 'حدث خطأ أثناء إرسال الطلب، حاول مرة أخرى');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <View style={[styles.container, { paddingTop: insets.top }]}>
        <StatusBar style="light" />

        {/* Header */}
        <View style={styles.header}>
          <Pressable style={styles.backBtn} onPress={handleBack}>
            <MaterialIcons name="arrow-forward" size={22} color={Colors.text} />
          </Pressable>
          <Text style={styles.headerTitle}>طلب خدمة</Text>
          <View style={{ width: 40 }} />
        </View>

        {/* Progress */}
        <View style={styles.progressArea}>
          <View style={styles.progressBar}>
            {STEPS.map((s, i) => (
              <View key={i} style={[styles.progressStep, i <= step && styles.progressStepActive]}>
                {i < step ? (
                  <MaterialIcons name="check" size={14} color={Colors.primary} />
                ) : (
                  <Text style={[styles.progressNum, i === step && styles.progressNumActive]}>{i + 1}</Text>
                )}
              </View>
            ))}
          </View>
          <Text style={styles.stepLabel}>{STEPS[step]}</Text>
          <View style={styles.progressTrack}>
            <View style={[styles.progressFill, { width: `${((step) / (STEPS.length - 1)) * 100}%` }]} />
          </View>
        </View>

        <ScrollView
          contentContainerStyle={[styles.content, { paddingBottom: insets.bottom + 100 }]}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          {/* ── Step 0: Service Type ── */}
          {step === 0 && (
            <View style={styles.stepContent}>
              <Text style={styles.stepTitle}>اختر نوع الخدمة</Text>
              <Text style={styles.stepSubtitle}>ما الخدمة التي تحتاجها؟</Text>
              <View style={styles.servicesGrid}>
                {serviceCategories.map(cat => (
                  <Pressable
                    key={cat.id}
                    style={[styles.serviceCard, selectedService === cat.name && styles.serviceCardActive]}
                    onPress={() => setSelectedService(cat.name)}
                  >
                    {({ pressed }) => (
                      <View style={[styles.serviceCardInner, pressed && { opacity: 0.85 }]}>
                        <View style={[styles.serviceIcon, { backgroundColor: cat.color + '20' }, selectedService === cat.name && { backgroundColor: Colors.gold + '30' }]}>
                          <MaterialIcons
                            name={cat.icon as any}
                            size={28}
                            color={selectedService === cat.name ? Colors.gold : cat.color}
                          />
                        </View>
                        <Text style={[styles.serviceName, selectedService === cat.name && { color: Colors.gold }]}>
                          {cat.name}
                        </Text>
                        {selectedService === cat.name && (
                          <View style={styles.selectedCheck}>
                            <MaterialIcons name="check-circle" size={16} color={Colors.gold} />
                          </View>
                        )}
                      </View>
                    )}
                  </Pressable>
                ))}
              </View>
            </View>
          )}

          {/* ── Step 1: Description ── */}
          {step === 1 && (
            <View style={styles.stepContent}>
              <Text style={styles.stepTitle}>صف المشكلة</Text>
              <Text style={styles.stepSubtitle}>اشرح المشكلة بالتفصيل لتحصل على أفضل خدمة</Text>
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>وصف المشكلة *</Text>
                <TextInput
                  style={styles.textArea}
                  value={description}
                  onChangeText={setDescription}
                  placeholder="مثال: لدي مشكلة في التمديدات الكهربائية في غرفة المعيشة..."
                  placeholderTextColor={Colors.textMuted}
                  multiline
                  numberOfLines={5}
                  textAlign="right"
                  textAlignVertical="top"
                />
                <Text style={styles.charCount}>{description.length} / 500</Text>
              </View>
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>صور المشكلة (اختياري - حتى 5 صور)</Text>
                <ScrollView horizontal showsHorizontalScrollIndicator={false}
                  contentContainerStyle={{ gap: Spacing.sm }}
                >
                  {photos.map((uri, i) => (
                    <View key={i} style={styles.photoThumb}>
                      <Image source={{ uri }} style={styles.photoThumbImg} contentFit="cover" />
                      <Pressable style={styles.photoRemoveBtn} onPress={() => setPhotos(prev => prev.filter((_, j) => j !== i))}>
                        <MaterialIcons name="close" size={14} color={Colors.text} />
                      </Pressable>
                    </View>
                  ))}
                  {photos.length < 5 && (
                    <Pressable style={styles.addPhotoBtn} onPress={showPickerOptions}>
                      <MaterialIcons name="add-a-photo" size={28} color={Colors.gold} />
                      <Text style={styles.addPhotoText}>إضافة صورة</Text>
                    </Pressable>
                  )}
                </ScrollView>
              </View>
              <View style={styles.tipsCard}>
                <Text style={styles.tipsTitle}>نصائح لوصف أفضل:</Text>
                {['اذكر موقع المشكلة في المنزل', 'صف أعراض المشكلة بوضوح', 'حدد منذ متى بدأت المشكلة'].map((t, i) => (
                  <View key={i} style={styles.tip}>
                    <MaterialIcons name="check" size={14} color={Colors.success} />
                    <Text style={styles.tipText}>{t}</Text>
                  </View>
                ))}
              </View>
            </View>
          )}

          {/* ── Step 2: Location ── */}
          {step === 2 && (
            <View style={styles.stepContent}>
              <Text style={styles.stepTitle}>تحديد الموقع</Text>
              <Text style={styles.stepSubtitle}>موقعك يُستخدم لإيجاد أقرب حرفي متاح تلقائياً</Text>

              {/* Auto-assign info banner */}
              <View style={styles.autoAssignBanner}>
                <MaterialIcons name="location-searching" size={20} color={Colors.gold} />
                <Text style={styles.autoAssignText}>
                  سيتم البحث عن أقرب حرفي متاح في منطقتك تلقائياً فور إرسال الطلب
                </Text>
              </View>

              {/* Interactive Map */}
              <View style={styles.mapContainer}>
                <MapView
                  ref={mapRef}
                  style={styles.map}
                  provider={PROVIDER_DEFAULT}
                  initialRegion={DEFAULT_REGION}
                  region={region}
                  onRegionChangeComplete={setRegion}
                  onPress={handleMapPress}
                  showsUserLocation
                  showsMyLocationButton={false}
                >
                  {markerCoord && (
                    <Marker coordinate={markerCoord} title="موقع الخدمة" pinColor={Colors.gold} />
                  )}
                </MapView>

                <Pressable style={styles.gpsBtn} onPress={goToMyLocation} disabled={locating}>
                  {locating ? (
                    <ActivityIndicator size="small" color={Colors.gold} />
                  ) : (
                    <MaterialIcons name="my-location" size={22} color={Colors.gold} />
                  )}
                </Pressable>

                {!markerCoord && (
                  <View style={styles.mapHint}>
                    <Text style={styles.mapHintText}>اضغط على الخريطة أو استخدم GPS</Text>
                  </View>
                )}
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>العنوان التفصيلي</Text>
                <View style={styles.addressInputRow}>
                  <TextInput
                    style={[styles.input, { flex: 1 }]}
                    value={address}
                    onChangeText={setAddress}
                    placeholder="الرياض، حي النرجس، شارع الورود"
                    placeholderTextColor={Colors.textMuted}
                    textAlign="right"
                  />
                  <Pressable style={styles.locateMiniBtn} onPress={goToMyLocation} disabled={locating}>
                    <MaterialIcons name="gps-fixed" size={20} color={Colors.gold} />
                  </Pressable>
                </View>
              </View>

              <Text style={styles.inputLabel}>العناوين المحفوظة</Text>
              {[
                { label: 'المنزل - حي النرجس', lat: 24.7740, lng: 46.6556 },
                { label: 'العمل - حي العليا', lat: 24.6877, lng: 46.6874 },
              ].map((a, i) => (
                <Pressable
                  key={i}
                  style={[styles.savedAddress, address.includes(a.label.split(' - ')[1]) && styles.savedAddressActive]}
                  onPress={() => {
                    const coord = { latitude: a.lat, longitude: a.lng };
                    const r: Region = { ...coord, latitudeDelta: 0.01, longitudeDelta: 0.01 };
                    setMarkerCoord(coord);
                    setRegion(r);
                    mapRef.current?.animateToRegion(r, 600);
                    setAddress(a.label.split(' - ')[1]);
                  }}
                >
                  <MaterialIcons name={i === 0 ? 'home' : 'work'} size={18} color={Colors.gold} />
                  <Text style={styles.savedAddressText}>{a.label}</Text>
                </Pressable>
              ))}
            </View>
          )}

          {/* ── Step 3: Time ── */}
          {step === 3 && (
            <View style={styles.stepContent}>
              <Text style={styles.stepTitle}>اختر الوقت المناسب</Text>
              <Text style={styles.stepSubtitle}>متى تريد الخدمة؟</Text>
              <View style={styles.timesGrid}>
                {TIME_SLOTS.map((time, i) => (
                  <Pressable
                    key={i}
                    style={[styles.timeSlot, selectedTime === time && styles.timeSlotActive]}
                    onPress={() => setSelectedTime(time)}
                  >
                    <MaterialIcons
                      name={i === 0 ? 'flash-on' : 'access-time'}
                      size={16}
                      color={selectedTime === time ? Colors.primary : Colors.gold}
                    />
                    <Text style={[styles.timeText, selectedTime === time && styles.timeTextActive]}>
                      {time}
                    </Text>
                  </Pressable>
                ))}
              </View>
            </View>
          )}

          {/* ── Step 4: Confirm ── */}
          {step === 4 && (
            <View style={styles.stepContent}>
              <Text style={styles.stepTitle}>مراجعة الطلب</Text>
              <Text style={styles.stepSubtitle}>تأكد من تفاصيل طلبك قبل الإرسال</Text>

              <View style={styles.summaryCard}>
                {[
                  { icon: 'home-repair-service', label: 'الخدمة', value: selectedService || '-' },
                  { icon: 'description', label: 'الوصف', value: description || '-' },
                  { icon: 'location-on', label: 'الموقع', value: address || '-' },
                  { icon: 'access-time', label: 'الوقت', value: selectedTime || '-' },
                ].map((item, i) => (
                  <View key={i} style={[styles.summaryItem, i < 3 && { borderBottomWidth: 1, borderBottomColor: Colors.divider }]}>
                    <Text style={styles.summaryValue}>{item.value}</Text>
                    <View style={styles.summaryLabel}>
                      <Text style={styles.summaryLabelText}>{item.label}</Text>
                      <MaterialIcons name={item.icon as any} size={18} color={Colors.gold} />
                    </View>
                  </View>
                ))}
              </View>

              {markerCoord && (
                <View style={styles.mapPreviewContainer}>
                  <MapView
                    style={styles.mapPreview}
                    provider={PROVIDER_DEFAULT}
                    region={{
                      latitude: markerCoord.latitude,
                      longitude: markerCoord.longitude,
                      latitudeDelta: 0.01,
                      longitudeDelta: 0.01,
                    }}
                    scrollEnabled={false}
                    zoomEnabled={false}
                    pitchEnabled={false}
                    rotateEnabled={false}
                  >
                    <Marker coordinate={markerCoord} pinColor={Colors.gold} />
                  </MapView>
                  <View style={styles.mapPreviewLabel}>
                    <MaterialIcons name="location-on" size={14} color={Colors.gold} />
                    <Text style={styles.mapPreviewText}>موقع الخدمة المحدد</Text>
                  </View>
                </View>
              )}

              {/* Auto-assign explanation */}
              <View style={styles.autoAssignCard}>
                <View style={styles.autoAssignCardHeader}>
                  <MaterialIcons name="auto-fix-high" size={20} color={Colors.gold} />
                  <Text style={styles.autoAssignCardTitle}>تعيين تلقائي فوري</Text>
                </View>
                <View style={styles.autoAssignSteps}>
                  {[
                    { icon: 'location-on', text: 'تحديد موقعك الجغرافي' },
                    { icon: 'search', text: 'البحث عن أقرب حرفي متاح غير مشغول' },
                    { icon: 'person-add', text: 'تعيين الحرفي الأنسب تلقائياً' },
                    { icon: 'chat', text: 'فتح قناة تواصل مباشر معه' },
                  ].map((s, i) => (
                    <View key={i} style={styles.autoAssignStep}>
                      <Text style={styles.autoAssignStepNum}>{i + 1}</Text>
                      <MaterialIcons name={s.icon as any} size={16} color={Colors.gold} />
                      <Text style={styles.autoAssignStepText}>{s.text}</Text>
                    </View>
                  ))}
                </View>
              </View>
            </View>
          )}
        </ScrollView>

        {/* Navigation Buttons */}
        <View style={[styles.navButtons, { paddingBottom: insets.bottom + Spacing.md }]}>
          {step < STEPS.length - 1 ? (
            <Pressable
              style={[styles.nextBtn, !canNext() && styles.disabledBtn]}
              onPress={handleNext}
              disabled={!canNext()}
            >
              {({ pressed }) => (
                <Text style={[styles.nextBtnText, pressed && { opacity: 0.85 }]}>التالي</Text>
              )}
            </Pressable>
          ) : (
            <Pressable
              style={[styles.submitBtn, submitting && { opacity: 0.7 }]}
              onPress={handleSubmit}
              disabled={submitting}
            >
              {submitting ? (
                <View style={styles.submitLoadingRow}>
                  <ActivityIndicator color={Colors.primary} size="small" />
                  <Text style={styles.submitBtnText}>جاري البحث عن حرفي...</Text>
                </View>
              ) : (
                <>
                  <Text style={styles.submitBtnText}>إرسال وتعيين حرفي</Text>
                  <MaterialIcons name="auto-fix-high" size={20} color={Colors.primary} />
                </>
              )}
            </Pressable>
          )}
        </View>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: Spacing.lg, paddingVertical: Spacing.md,
    borderBottomWidth: 1, borderBottomColor: Colors.divider,
  },
  backBtn: { width: 40, height: 40, borderRadius: 20, backgroundColor: Colors.surface, alignItems: 'center', justifyContent: 'center' },
  headerTitle: { fontSize: FontSize.xl, fontWeight: FontWeight.bold, color: Colors.text },
  progressArea: { paddingHorizontal: Spacing.lg, paddingVertical: Spacing.md, gap: Spacing.sm },
  progressBar: { flexDirection: 'row', justifyContent: 'center', gap: Spacing.sm },
  progressStep: {
    width: 30, height: 30, borderRadius: 15,
    backgroundColor: Colors.surface, alignItems: 'center', justifyContent: 'center',
    borderWidth: 1.5, borderColor: Colors.border,
  },
  progressStepActive: { backgroundColor: Colors.gold, borderColor: Colors.gold },
  progressNum: { fontSize: FontSize.xs, color: Colors.textMuted, fontWeight: FontWeight.bold },
  progressNumActive: { color: Colors.primary },
  stepLabel: { fontSize: FontSize.sm, color: Colors.gold, textAlign: 'center', fontWeight: FontWeight.semibold },
  progressTrack: { height: 4, backgroundColor: Colors.surface, borderRadius: 2, overflow: 'hidden' },
  progressFill: { height: '100%', backgroundColor: Colors.gold, borderRadius: 2 },
  content: { paddingHorizontal: Spacing.lg, paddingTop: Spacing.md },
  stepContent: { gap: Spacing.lg },
  stepTitle: { fontSize: FontSize.xxl, fontWeight: FontWeight.bold, color: Colors.text, textAlign: 'right' },
  stepSubtitle: { fontSize: FontSize.base, color: Colors.textMuted, textAlign: 'right', marginTop: -Spacing.sm },

  // Auto-assign banner
  autoAssignBanner: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.sm,
    backgroundColor: 'rgba(212,160,23,0.08)', borderRadius: Radius.lg,
    padding: Spacing.md, borderWidth: 1, borderColor: 'rgba(212,160,23,0.25)',
  },
  autoAssignText: { flex: 1, fontSize: FontSize.sm, color: Colors.text, lineHeight: 20, textAlign: 'right' },

  // Auto-assign card in confirm step
  autoAssignCard: {
    backgroundColor: Colors.surface, borderRadius: Radius.xl,
    borderWidth: 1, borderColor: 'rgba(212,160,23,0.3)', padding: Spacing.md, gap: Spacing.md,
  },
  autoAssignCardHeader: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, justifyContent: 'flex-end' },
  autoAssignCardTitle: { fontSize: FontSize.base, fontWeight: FontWeight.bold, color: Colors.gold },
  autoAssignSteps: { gap: Spacing.sm },
  autoAssignStep: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.sm,
    justifyContent: 'flex-end', padding: Spacing.sm,
    backgroundColor: Colors.primarySurface, borderRadius: Radius.md,
  },
  autoAssignStepNum: {
    width: 22, height: 22, borderRadius: 11,
    backgroundColor: Colors.gold, color: Colors.primary,
    fontSize: FontSize.xs, fontWeight: FontWeight.bold,
    textAlign: 'center', lineHeight: 22,
    marginLeft: 4,
  },
  autoAssignStepText: { flex: 1, fontSize: FontSize.sm, color: Colors.text, textAlign: 'right' },

  servicesGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm },
  serviceCard: { width: (width - Spacing.lg * 2 - Spacing.sm * 3) / 4, borderRadius: Radius.lg, overflow: 'hidden' },
  serviceCardActive: {},
  serviceCardInner: {
    backgroundColor: Colors.surface, borderRadius: Radius.lg, paddingVertical: Spacing.md,
    alignItems: 'center', gap: Spacing.sm, borderWidth: 1.5, borderColor: Colors.border,
    position: 'relative',
  },
  serviceIcon: { width: 52, height: 52, borderRadius: Radius.md, alignItems: 'center', justifyContent: 'center' },
  serviceName: { fontSize: FontSize.xs, color: Colors.text, fontWeight: FontWeight.semibold, textAlign: 'center' },
  selectedCheck: { position: 'absolute', top: 6, left: 6 },
  inputGroup: { gap: Spacing.sm },
  inputLabel: { fontSize: FontSize.sm, color: Colors.textMuted, fontWeight: FontWeight.medium, textAlign: 'right' },
  input: {
    backgroundColor: Colors.surface, borderRadius: Radius.md, borderWidth: 1,
    borderColor: Colors.border, paddingHorizontal: Spacing.md, paddingVertical: 13,
    color: Colors.text, fontSize: FontSize.base,
  },
  addressInputRow: { flexDirection: 'row', gap: Spacing.sm, alignItems: 'center' },
  locateMiniBtn: {
    width: 48, height: 48, borderRadius: Radius.md,
    backgroundColor: Colors.goldSoft, alignItems: 'center', justifyContent: 'center',
    borderWidth: 1, borderColor: 'rgba(212,160,23,0.3)',
  },
  textArea: {
    backgroundColor: Colors.surface, borderRadius: Radius.md, borderWidth: 1,
    borderColor: Colors.border, paddingHorizontal: Spacing.md, paddingVertical: 13,
    color: Colors.text, fontSize: FontSize.base, minHeight: 130,
  },
  charCount: { fontSize: FontSize.xs, color: Colors.textMuted, textAlign: 'left' },
  tipsCard: { backgroundColor: Colors.surface, borderRadius: Radius.lg, padding: Spacing.md, gap: Spacing.sm, borderWidth: 1, borderColor: Colors.border },
  tipsTitle: { fontSize: FontSize.sm, color: Colors.gold, fontWeight: FontWeight.semibold, textAlign: 'right' },
  tip: { flexDirection: 'row', gap: Spacing.sm, alignItems: 'center', justifyContent: 'flex-end' },
  tipText: { fontSize: FontSize.sm, color: Colors.textMuted },

  mapContainer: {
    height: 240, borderRadius: Radius.xl, overflow: 'hidden',
    borderWidth: 1, borderColor: Colors.border, position: 'relative',
  },
  map: { flex: 1 },
  gpsBtn: {
    position: 'absolute', bottom: 12, left: 12,
    width: 44, height: 44, borderRadius: 22,
    backgroundColor: Colors.background,
    alignItems: 'center', justifyContent: 'center',
    borderWidth: 1, borderColor: Colors.border,
    ...Shadow.md,
  },
  mapHint: {
    position: 'absolute', top: 12, left: 0, right: 0,
    alignItems: 'center',
  },
  mapHintText: {
    fontSize: FontSize.xs, color: Colors.text, fontWeight: FontWeight.medium,
    backgroundColor: 'rgba(13,27,62,0.8)', paddingHorizontal: 12, paddingVertical: 6,
    borderRadius: Radius.full, overflow: 'hidden',
  },

  savedAddress: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.md,
    backgroundColor: Colors.surface, borderRadius: Radius.lg, padding: Spacing.md,
    borderWidth: 1, borderColor: Colors.border, marginBottom: Spacing.sm,
  },
  savedAddressActive: { borderColor: Colors.gold, backgroundColor: Colors.goldSoft },
  savedAddressText: { flex: 1, color: Colors.text, fontSize: FontSize.base, textAlign: 'right' },

  timesGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm },
  timeSlot: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.sm,
    paddingHorizontal: 14, paddingVertical: 12, borderRadius: Radius.lg,
    backgroundColor: Colors.surface, borderWidth: 1.5, borderColor: Colors.border,
  },
  timeSlotActive: { backgroundColor: Colors.gold, borderColor: Colors.gold },
  timeText: { fontSize: FontSize.sm, color: Colors.text, fontWeight: FontWeight.medium },
  timeTextActive: { color: Colors.primary, fontWeight: FontWeight.bold },

  summaryCard: { backgroundColor: Colors.surface, borderRadius: Radius.xl, overflow: 'hidden', borderWidth: 1, borderColor: Colors.border },
  summaryItem: { paddingHorizontal: Spacing.md, paddingVertical: Spacing.md, gap: 4 },
  summaryLabel: { flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-end', gap: 6 },
  summaryLabelText: { fontSize: FontSize.sm, color: Colors.textMuted, fontWeight: FontWeight.medium },
  summaryValue: { fontSize: FontSize.base, color: Colors.text, fontWeight: FontWeight.semibold, textAlign: 'right' },

  mapPreviewContainer: {
    borderRadius: Radius.xl, overflow: 'hidden',
    borderWidth: 1, borderColor: Colors.border,
  },
  mapPreview: { height: 150, width: '100%' },
  mapPreviewLabel: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    paddingHorizontal: Spacing.md, paddingVertical: 10,
    backgroundColor: Colors.surface, justifyContent: 'flex-end',
  },
  mapPreviewText: { fontSize: FontSize.xs, color: Colors.textMuted },

  addPhotoBtn: {
    width: 90, height: 90, borderRadius: Radius.md,
    backgroundColor: Colors.surface, borderWidth: 1.5, borderColor: Colors.border,
    borderStyle: 'dashed', alignItems: 'center', justifyContent: 'center', gap: 4,
  },
  addPhotoText: { fontSize: 10, color: Colors.gold, fontWeight: FontWeight.medium },
  photoThumb: { width: 90, height: 90, borderRadius: Radius.md, position: 'relative', overflow: 'hidden' },
  photoThumbImg: { width: '100%', height: '100%' },
  photoRemoveBtn: {
    position: 'absolute', top: 4, right: 4,
    width: 22, height: 22, borderRadius: 11,
    backgroundColor: 'rgba(0,0,0,0.6)', alignItems: 'center', justifyContent: 'center',
  },
  navButtons: { paddingHorizontal: Spacing.lg, paddingTop: Spacing.md, backgroundColor: Colors.background, borderTopWidth: 1, borderTopColor: Colors.divider },
  nextBtn: { backgroundColor: Colors.gold, borderRadius: Radius.lg, paddingVertical: 16, alignItems: 'center', ...Shadow.gold },
  disabledBtn: { opacity: 0.4 },
  nextBtnText: { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: Colors.primary },
  submitBtn: {
    backgroundColor: Colors.gold, borderRadius: Radius.lg, paddingVertical: 16,
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: Spacing.sm, ...Shadow.gold,
  },
  submitLoadingRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  submitBtnText: { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: Colors.primary },
});
