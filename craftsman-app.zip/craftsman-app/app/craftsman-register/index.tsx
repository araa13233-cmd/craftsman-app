import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, ScrollView, Pressable, TextInput,
  KeyboardAvoidingView, Platform, ActivityIndicator, Alert,
} from 'react-native';
import { useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import * as ImagePicker from 'expo-image-picker';
import { Colors, FontSize, FontWeight, Radius, Spacing, Shadow } from '@/constants/theme';
import { ARAB_COUNTRIES, EXPERIENCE_OPTIONS, getProvincesByCountry } from '@/constants/arabCountries';
import { getSupabaseClient, useAuth, useAlert } from '@/template';
import { useApp } from '@/hooks/useApp';
import * as Location from 'expo-location';

const SPECIALTIES = [
  { label: 'كهربائي',        icon: 'flash-on',            value: 'كهربائي معتمد' },
  { label: 'سباك',           icon: 'water-drop',          value: 'سباك محترف' },
  { label: 'نجار',           icon: 'build',               value: 'نجار وأثاث' },
  { label: 'دهان',           icon: 'brush',               value: 'دهان وديكور' },
  { label: 'مكيفات',         icon: 'ac-unit',             value: 'صيانة مكيفات' },
  { label: 'طاقة شمسية',     icon: 'wb-sunny',            value: 'طاقة شمسية' },
  { label: 'صيانة أجهزة',   icon: 'home-repair-service', value: 'صيانة أجهزة' },
  { label: 'ألمنيوم وزجاج', icon: 'crop-square',         value: 'ألمنيوم وزجاج' },
];

const STEPS = ['التخصص', 'البيانات', 'الموقع', 'الصورة', 'التأكيد'];

const BENEFITS = [
  { icon: 'trending-up', text: 'زد دخلك بما يصل إلى 3x' },
  { icon: 'location-on', text: 'اعثر على عملاء في منطقتك' },
  { icon: 'shield',      text: 'عمل موثوق وآمن' },
  { icon: 'payments',    text: 'دفع سريع ومضمون' },
];

export default function CraftsmanRegisterScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const { showAlert } = useAlert();
  const supabase = getSupabaseClient();
  const { refreshRole } = useApp();

  const [step, setStep] = useState(0);
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [checkingExisting, setCheckingExisting] = useState(true);

  // Step 0 – Specialty
  const [specialty, setSpecialty] = useState('');
  const [specialtyIcon, setSpecialtyIcon] = useState('build');

  // Step 1 – Personal details
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [experienceIndex, setExperienceIndex] = useState(2);
  const [bio, setBio] = useState('');
  const [skills, setSkills] = useState('');

  // Step 2 – Location
  const [selectedCountry, setSelectedCountry] = useState('السعودية');
  const [selectedProvince, setSelectedProvince] = useState('الرياض');
  const [addressDetail, setAddressDetail] = useState('');
  const [gpsLat, setGpsLat] = useState<number | null>(null);
  const [gpsLng, setGpsLng] = useState<number | null>(null);
  const [gpsLoading, setGpsLoading] = useState(false);
  const provinces = getProvincesByCountry(selectedCountry);

  // Step 3 – Photo
  const [photoUri, setPhotoUri] = useState<string | null>(null);
  const [uploadingPhoto, setUploadingPhoto] = useState(false);
  const [uploadedPhotoUrl, setUploadedPhotoUrl] = useState<string | null>(null);

  useEffect(() => {
    if (user?.username) setName(user.username);
  }, [user]);

  useEffect(() => {
    const newProvinces = getProvincesByCountry(selectedCountry);
    setSelectedProvince(newProvinces[0] ?? '');
  }, [selectedCountry]);

  useEffect(() => {
    const check = async () => {
      if (!user) { setCheckingExisting(false); return; }
      const { data } = await supabase.from('craftsmen').select('id').eq('user_id', user.id).maybeSingle();
      if (data) setSubmitted(true);
      setCheckingExisting(false);
    };
    check();
  }, [user]);

  const grabGPS = async () => {
    setGpsLoading(true);
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') { Alert.alert('الموقع', 'يرجى السماح للتطبيق باستخدام موقعك'); return; }
      const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      setGpsLat(loc.coords.latitude);
      setGpsLng(loc.coords.longitude);
      // Reverse geocode to fill in city/province
      const geo = await Location.reverseGeocodeAsync({ latitude: loc.coords.latitude, longitude: loc.coords.longitude });
      if (geo[0]?.city) {
        const matchedProvince = provinces.find(p => geo[0].city && p.includes(geo[0].city!));
        if (matchedProvince) setSelectedProvince(matchedProvince);
      }
      Alert.alert('تم', 'تم تحديد موقعك بنجاح ✅');
    } catch { Alert.alert('خطأ', 'تعذر تحديد الموقع، تأكد من تفعيل خدمات الموقع'); }
    finally { setGpsLoading(false); }
  };

  const pickPhoto = async (source: 'camera' | 'gallery') => {
    let result: ImagePicker.ImagePickerResult;
    if (source === 'camera') {
      const { status } = await ImagePicker.requestCameraPermissionsAsync();
      if (status !== 'granted') { Alert.alert('الكاميرا', 'يرجى السماح للتطبيق باستخدام الكاميرا'); return; }
      result = await ImagePicker.launchCameraAsync({ mediaTypes: 'images', quality: 0.8, allowsEditing: true, aspect: [1, 1] });
    } else {
      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== 'granted') { Alert.alert('المعرض', 'يرجى السماح للتطبيق بالوصول إلى المعرض'); return; }
      result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: 'images', quality: 0.8, allowsEditing: true, aspect: [1, 1] });
    }
    if (result.canceled || !result.assets?.[0]) return;
    setPhotoUri(result.assets[0].uri);
    setUploadedPhotoUrl(null);
  };

  const showPhotoOptions = () => {
    Alert.alert('إضافة صورة شخصية', 'اختر المصدر', [
      { text: 'الكاميرا', onPress: () => pickPhoto('camera') },
      { text: 'معرض الصور', onPress: () => pickPhoto('gallery') },
      { text: 'إلغاء', style: 'cancel' },
    ]);
  };

  const uploadPhoto = async (): Promise<string | null> => {
    if (!photoUri || !user) return null;
    if (uploadedPhotoUrl) return uploadedPhotoUrl;
    setUploadingPhoto(true);
    try {
      const ext = photoUri.split('.').pop() ?? 'jpg';
      const fileName = `craftsmen/${user.id}-${Date.now()}.${ext}`;
      const response = await fetch(photoUri);
      const blob = await response.blob();
      const arrayBuffer = await new Response(blob).arrayBuffer();
      const { error: uploadError } = await supabase.storage
        .from('profile-images').upload(fileName, arrayBuffer, { contentType: `image/${ext}`, upsert: true });
      if (uploadError) { console.warn('Upload error:', uploadError.message); return null; }
      const { data: { publicUrl } } = supabase.storage.from('profile-images').getPublicUrl(fileName);
      setUploadedPhotoUrl(publicUrl);
      return publicUrl;
    } catch { return null; }
    finally { setUploadingPhoto(false); }
  };

  const goNext = async () => {
    if (step === 0 && !specialty) { showAlert('تنبيه', 'يرجى اختيار التخصص'); return; }
    if (step === 1) {
      if (!name.trim()) { showAlert('تنبيه', 'يرجى إدخال الاسم الكامل'); return; }
      if (!phone.trim() || phone.trim().length < 9) { showAlert('تنبيه', 'يرجى إدخال رقم جوال صحيح'); return; }
    }
    if (step === 2 && !selectedProvince) { showAlert('تنبيه', 'يرجى اختيار المحافظة'); return; }
    setStep(prev => prev + 1);
  };

  const handleSubmit = async () => {
    if (!user) { showAlert('تنبيه', 'يجب تسجيل الدخول أولاً'); router.push('/auth/login'); return; }
    setLoading(true);
    const imageUrl = await uploadPhoto();
    const skillsArray = skills.trim() ? skills.split('،').map(s => s.trim()).filter(Boolean) : [];

    // Set user role to craftsman in user_profiles
    await supabase.from('user_profiles').update({ role: 'craftsman' }).eq('id', user.id);

    // Check if craftsman record already exists (active or inactive)
    const { data: existingCraftsman } = await supabase
      .from('craftsmen')
      .select('id')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle();

    const craftsmanPayload = {
      user_id: user.id,
      name: name.trim(),
      specialty,
      specialty_icon: specialtyIcon,
      phone: phone.trim(),
      country: selectedCountry,
      city: selectedProvince,
      address_detail: addressDetail.trim() || null,
      experience: EXPERIENCE_OPTIONS[experienceIndex].value,
      bio: bio.trim(),
      image_url: imageUrl,
      skills: skillsArray,
      is_approved: true,
      is_active: true,
      available: true,
      latitude: gpsLat,
      longitude: gpsLng,
      updated_at: new Date().toISOString(),
    };

    let error: any = null;
    if (existingCraftsman) {
      // Update existing record instead of creating duplicate
      const { error: updateError } = await supabase
        .from('craftsmen')
        .update(craftsmanPayload)
        .eq('id', existingCraftsman.id);
      error = updateError;
    } else {
      const { error: insertError } = await supabase
        .from('craftsmen')
        .insert(craftsmanPayload);
      error = insertError;
    }

    setLoading(false);
    if (error) { showAlert('خطأ', 'حدث خطأ أثناء التسجيل. حاول مرة أخرى.'); return; }
    setSubmitted(true);
    refreshRole();
  };

  if (checkingExisting) {
    return (
      <View style={[styles.container, styles.centered, { paddingTop: insets.top }]}>
        <ActivityIndicator size="large" color={Colors.gold} />
      </View>
    );
  }

  // ── Success Screen ──────────────────────────────────────────────────────────
  if (submitted) {
    return (
      <View style={[styles.container, styles.successContainer, { paddingTop: insets.top }]}>
        <StatusBar style="light" />
        <View style={styles.successIconBg}>
          <MaterialIcons name="check-circle" size={72} color={Colors.success} />
        </View>
        <Text style={styles.successTitle}>مرحباً بك حرفياً معتمداً!</Text>
        <Text style={styles.successText}>
          تم تفعيل حسابك كحرفي معتمد{' '}
          <Text style={{ color: Colors.gold, fontWeight: FontWeight.bold }}>فوراً</Text>
          {' '}— ملفك ظاهر للعملاء ويمكنك استقبال الطلبات مباشرة.
        </Text>
        <View style={styles.successSteps}>
          {['حسابك مفعّل الآن', 'ملفك ظاهر للعملاء', 'ابدأ استقبال الطلبات'].map((s, i) => (
            <View key={i} style={styles.successStep}>
              <Text style={styles.successStepText}>{s}</Text>
              <View style={[styles.successStepDot, { backgroundColor: Colors.success }]}>
                <MaterialIcons name="check" size={14} color={Colors.primary} />
              </View>
            </View>
          ))}
        </View>
        <View style={styles.successInfoBox}>
          <MaterialIcons name="tips-and-updates" size={18} color={Colors.gold} />
          <Text style={styles.successInfoText}>
            يمكنك تحديث صورتك ومهاراتك في أي وقت من الملف الشخصي لجذب المزيد من العملاء
          </Text>
        </View>
        <Pressable style={styles.homeBtn} onPress={() => router.replace('/(tabs)' as any)}>
          <Text style={styles.homeBtnText}>استعرض الطلبات</Text>
        </Pressable>
      </View>
    );
  }

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <View style={[styles.container, { paddingTop: insets.top }]}>
        <StatusBar style="light" />

        {/* Header */}
        <View style={styles.header}>
          <Pressable style={styles.backBtn} onPress={() => step > 0 ? setStep(s => s - 1) : router.back()}>
            <MaterialIcons name="arrow-forward" size={22} color={Colors.text} />
          </Pressable>
          <View style={styles.headerCenter}>
            <Text style={styles.headerTitle}>انضم كحرفي معتمد</Text>
            <Text style={styles.headerSub}>الخطوة {step + 1} من {STEPS.length}</Text>
          </View>
          <View style={{ width: 44 }} />
        </View>

        {/* Progress */}
        <ScrollView horizontal showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.progressScroll} style={styles.progressContainer}
        >
          {STEPS.map((s, i) => (
            <View key={i} style={styles.stepItem}>
              <View style={[styles.stepCircle, i <= step && styles.stepCircleActive, i < step && styles.stepCircleDone]}>
                {i < step
                  ? <MaterialIcons name="check" size={14} color={Colors.primary} />
                  : <Text style={[styles.stepNum, i === step && styles.stepNumActive]}>{i + 1}</Text>
                }
              </View>
              <Text style={[styles.stepLabel, i === step && styles.stepLabelActive]}>{s}</Text>
            </View>
          ))}
        </ScrollView>

        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={[styles.scroll, { paddingBottom: insets.bottom + 100 }]}
          keyboardShouldPersistTaps="handled"
        >

          {/* ── Step 0: Specialty ── */}
          {step === 0 && (
            <View style={styles.stepContent}>
              <View style={styles.stepIntro}>
                <MaterialIcons name="home-repair-service" size={40} color={Colors.gold} />
                <Text style={styles.stepTitle}>اختر تخصصك الرئيسي</Text>
                <Text style={styles.stepSubtitle}>اختر المجال الذي تبرع فيه وتقدم خدمات احترافية</Text>
              </View>
              <View style={styles.benefitsRow}>
                {BENEFITS.map((b, i) => (
                  <View key={i} style={styles.benefitItem}>
                    <MaterialIcons name={b.icon as any} size={18} color={Colors.gold} />
                    <Text style={styles.benefitText}>{b.text}</Text>
                  </View>
                ))}
              </View>
              <View style={styles.specialtyGrid}>
                {SPECIALTIES.map(sp => (
                  <Pressable
                    key={sp.value}
                    style={[styles.specialtyCard, specialty === sp.value && styles.specialtyCardActive]}
                    onPress={() => { setSpecialty(sp.value); setSpecialtyIcon(sp.icon); }}
                  >
                    {({ pressed }) => (
                      <View style={[styles.specialtyInner, pressed && { opacity: 0.85 }]}>
                        {specialty === sp.value && (
                          <View style={styles.specialtyCheck}>
                            <MaterialIcons name="check-circle" size={16} color={Colors.primary} />
                          </View>
                        )}
                        <MaterialIcons name={sp.icon as any} size={32} color={specialty === sp.value ? Colors.primary : Colors.gold} />
                        <Text style={[styles.specialtyLabel, specialty === sp.value && styles.specialtyLabelActive]}>
                          {sp.label}
                        </Text>
                      </View>
                    )}
                  </Pressable>
                ))}
              </View>
            </View>
          )}

          {/* ── Step 1: Personal Details ── */}
          {step === 1 && (
            <View style={styles.stepContent}>
              <View style={styles.stepIntro}>
                <MaterialIcons name="person" size={40} color={Colors.gold} />
                <Text style={styles.stepTitle}>بياناتك المهنية</Text>
                <Text style={styles.stepSubtitle}>أدخل معلوماتك لتظهر باحترافية أمام العملاء</Text>
              </View>

              {[
                { label: 'الاسم الكامل *', value: name, set: setName, placeholder: 'محمد عبدالله', icon: 'person', kb: 'default' },
                { label: 'رقم الجوال *', value: phone, set: setPhone, placeholder: '+966 5XX XXX XXX', icon: 'phone', kb: 'phone-pad' },
              ].map((f, i) => (
                <View key={i} style={styles.inputGroup}>
                  <Text style={styles.label}>{f.label}</Text>
                  <View style={styles.inputRow}>
                    <TextInput style={styles.input} value={f.value} onChangeText={f.set}
                      placeholder={f.placeholder} placeholderTextColor={Colors.textMuted}
                      keyboardType={f.kb as any} textAlign="right" autoCapitalize="none" />
                    <MaterialIcons name={f.icon as any} size={20} color={Colors.textMuted} />
                  </View>
                </View>
              ))}

              {/* Experience */}
              <View style={styles.inputGroup}>
                <Text style={styles.label}>سنوات الخبرة</Text>
                <View style={styles.expGrid}>
                  {EXPERIENCE_OPTIONS.map((exp, i) => (
                    <Pressable
                      key={i}
                      style={[styles.expChip, experienceIndex === i && styles.expChipActive]}
                      onPress={() => setExperienceIndex(i)}
                    >
                      <Text style={[styles.expChipText, experienceIndex === i && styles.expChipTextActive]}>
                        {exp.label}
                      </Text>
                    </Pressable>
                  ))}
                </View>
              </View>

              {/* Skills */}
              <View style={styles.inputGroup}>
                <Text style={styles.label}>المهارات (اختياري، افصل بـ ،)</Text>
                <View style={styles.inputRow}>
                  <TextInput style={styles.input} value={skills} onChangeText={setSkills}
                    placeholder="مثال: إصلاح عداد كهرباء، تمديد أسلاك"
                    placeholderTextColor={Colors.textMuted} textAlign="right" />
                  <MaterialIcons name="build" size={20} color={Colors.textMuted} />
                </View>
              </View>

              {/* Bio */}
              <View style={styles.inputGroup}>
                <Text style={styles.label}>نبذة عنك (اختياري)</Text>
                <TextInput style={styles.bioInput} value={bio} onChangeText={setBio}
                  placeholder="اكتب نبذة مختصرة تعرّف بك وبخبرتك..."
                  placeholderTextColor={Colors.textMuted} textAlign="right"
                  multiline numberOfLines={4} textAlignVertical="top" />
              </View>
            </View>
          )}

          {/* ── Step 2: Location ── */}
          {step === 2 && (
            <View style={styles.stepContent}>
              <View style={styles.stepIntro}>
                <MaterialIcons name="location-on" size={40} color={Colors.gold} />
                <Text style={styles.stepTitle}>موقعك وعنوانك</Text>
                <Text style={styles.stepSubtitle}>حدد بلدك ومحافظتك لنوصلك بالعملاء القريبين منك</Text>
              </View>

              {/* GPS Location Capture */}
              <View style={styles.inputGroup}>
                <Text style={styles.label}>تحديد موقعك (موصى به)</Text>
                <Pressable
                  style={[styles.gpsBtn, gpsLat && styles.gpsBtnSuccess]}
                  onPress={grabGPS}
                  disabled={gpsLoading}
                >
                  {gpsLoading
                    ? <ActivityIndicator size="small" color={Colors.gold} />
                    : <MaterialIcons name="my-location" size={18} color={gpsLat ? Colors.success : Colors.gold} />
                  }
                  <Text style={[styles.gpsBtnText, gpsLat && { color: Colors.success }]}>
                    {gpsLat ? `تم تحديد الموقع ✅ (${gpsLat.toFixed(3)}, ${gpsLng!.toFixed(3)})` : 'تحديد موقعك الحالي'}
                  </Text>
                </Pressable>
                <Text style={styles.inputHint}>يساعد العملاء على إيجادك بسهولة ويعرض طلباتك المجاورة لك أولاً</Text>
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.label}>الدولة *</Text>
                <View style={styles.countryGrid}>
                  {ARAB_COUNTRIES.map(c => (
                    <Pressable
                      key={c.name}
                      style={[styles.countryChip, selectedCountry === c.name && styles.countryChipActive]}
                      onPress={() => setSelectedCountry(c.name)}
                    >
                      <Text style={[styles.countryChipText, selectedCountry === c.name && styles.countryChipTextActive]}>
                        {c.flag} {c.name}
                      </Text>
                    </Pressable>
                  ))}
                </View>
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.label}>المحافظة / المنطقة *</Text>
                <View style={styles.provinceGrid}>
                  {provinces.map(prov => (
                    <Pressable
                      key={prov}
                      style={[styles.provChip, selectedProvince === prov && styles.provChipActive]}
                      onPress={() => setSelectedProvince(prov)}
                    >
                      <Text style={[styles.provChipText, selectedProvince === prov && styles.provChipTextActive]}>
                        {prov}
                      </Text>
                    </Pressable>
                  ))}
                </View>
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.label}>العنوان التفصيلي (اختياري)</Text>
                <TextInput
                  style={styles.bioInput}
                  value={addressDetail}
                  onChangeText={setAddressDetail}
                  placeholder={`مثال: حي الملك فهد، شارع الأمير سلطان، بالقرب من ${selectedProvince}...`}
                  placeholderTextColor={Colors.textMuted}
                  textAlign="right"
                  multiline
                  numberOfLines={3}
                  textAlignVertical="top"
                />
                <Text style={styles.inputHint}>
                  {'  '}العنوان التفصيلي يساعد العملاء على تحديد موقعك بدقة
                </Text>
              </View>

              {selectedProvince ? (
                <View style={styles.locationSummary}>
                  <MaterialIcons name="check-circle" size={18} color={Colors.success} />
                  <View style={styles.locationSummaryText}>
                    <Text style={styles.locationSummaryMain}>
                      {ARAB_COUNTRIES.find(c => c.name === selectedCountry)?.flag} {selectedCountry} — {selectedProvince}
                    </Text>
                    {addressDetail ? (
                      <Text style={styles.locationSummaryDetail} numberOfLines={1}>{addressDetail}</Text>
                    ) : null}
                  </View>
                </View>
              ) : null}
            </View>
          )}

          {/* ── Step 3: Photo ── */}
          {step === 3 && (
            <View style={styles.stepContent}>
              <View style={styles.stepIntro}>
                <MaterialIcons name="photo-camera" size={40} color={Colors.gold} />
                <Text style={styles.stepTitle}>صورتك الشخصية</Text>
                <Text style={styles.stepSubtitle}>
                  الملفات التي تحتوي على صورة تحصل على{' '}
                  <Text style={{ color: Colors.gold, fontWeight: FontWeight.bold }}>3x</Text>
                  {' '}مزيداً من الطلبات
                </Text>
              </View>

              <View style={styles.photoArea}>
                <Pressable style={styles.photoCircle} onPress={showPhotoOptions}>
                  {photoUri
                    ? <Image source={{ uri: photoUri }} style={styles.photoPreview} contentFit="cover" />
                    : (
                      <View style={styles.photoPlaceholder}>
                        <MaterialIcons name="person" size={64} color={Colors.textMuted} />
                        <Text style={styles.photoPlaceholderText}>اضغط لإضافة صورة</Text>
                      </View>
                    )
                  }
                  <View style={styles.photoCameraBtn}>
                    <MaterialIcons name="photo-camera" size={18} color={Colors.text} />
                  </View>
                </Pressable>

                <View style={styles.photoActions}>
                  <Pressable style={styles.photoActionBtn} onPress={() => pickPhoto('camera')}>
                    <MaterialIcons name="camera-alt" size={22} color={Colors.gold} />
                    <Text style={styles.photoActionText}>الكاميرا</Text>
                  </Pressable>
                  <Pressable style={styles.photoActionBtn} onPress={() => pickPhoto('gallery')}>
                    <MaterialIcons name="photo-library" size={22} color={Colors.gold} />
                    <Text style={styles.photoActionText}>المعرض</Text>
                  </Pressable>
                  {photoUri && (
                    <Pressable
                      style={[styles.photoActionBtn, { borderColor: Colors.error }]}
                      onPress={() => { setPhotoUri(null); setUploadedPhotoUrl(null); }}
                    >
                      <MaterialIcons name="delete" size={22} color={Colors.error} />
                      <Text style={[styles.photoActionText, { color: Colors.error }]}>حذف</Text>
                    </Pressable>
                  )}
                </View>
              </View>

              <View style={styles.photoTips}>
                <Text style={styles.photoTipsTitle}>نصائح للصورة المثالية:</Text>
                {[
                  'صورة واضحة لوجهك بإضاءة جيدة',
                  'ارتدِ ملابس مهنية تليق بعملك',
                  'ابتسم لتعطي انطباعاً إيجابياً',
                  'تجنب صور المجموعات أو الخلفيات المشتتة',
                ].map((t, i) => (
                  <View key={i} style={styles.photoTip}>
                    <MaterialIcons name="check-circle" size={14} color={Colors.success} />
                    <Text style={styles.photoTipText}>{t}</Text>
                  </View>
                ))}
              </View>

              <Pressable style={styles.skipPhotoBtn} onPress={() => setStep(4)}>
                <Text style={styles.skipPhotoBtnText}>تخطي الصورة الآن وإضافتها لاحقاً</Text>
              </Pressable>
            </View>
          )}

          {/* ── Step 4: Review ── */}
          {step === 4 && (
            <View style={styles.stepContent}>
              <View style={styles.stepIntro}>
                <MaterialIcons name="fact-check" size={40} color={Colors.gold} />
                <Text style={styles.stepTitle}>مراجعة البيانات</Text>
                <Text style={styles.stepSubtitle}>راجع بياناتك قبل الإرسال النهائي</Text>
              </View>

              <View style={styles.reviewPhotoRow}>
                {photoUri
                  ? <Image source={{ uri: photoUri }} style={styles.reviewPhoto} contentFit="cover" />
                  : (
                    <View style={styles.reviewPhotoPlaceholder}>
                      <MaterialIcons name="person" size={36} color={Colors.textMuted} />
                    </View>
                  )
                }
                <View style={styles.reviewPhotoInfo}>
                  <Text style={styles.reviewName}>{name}</Text>
                  <Text style={styles.reviewSpecialty}>{specialty}</Text>
                  <View style={styles.reviewCityRow}>
                    <MaterialIcons name="location-on" size={13} color={Colors.textMuted} />
                    <Text style={styles.reviewCity}>
                      {ARAB_COUNTRIES.find(c => c.name === selectedCountry)?.flag} {selectedCountry} — {selectedProvince}
                    </Text>
                  </View>
                </View>
              </View>

              <View style={styles.reviewCard}>
                {[
                  { icon: 'phone', label: 'الجوال', value: phone },
                  { icon: 'work', label: 'الخبرة', value: EXPERIENCE_OPTIONS[experienceIndex].label },
                  { icon: 'location-city', label: 'المحافظة', value: `${selectedProvince}، ${selectedCountry}` },
                  ...(addressDetail ? [{ icon: 'place', label: 'العنوان التفصيلي', value: addressDetail }] : []),
                  ...(skills ? [{ icon: 'build', label: 'المهارات', value: skills }] : []),
                  ...(bio ? [{ icon: 'description', label: 'النبذة', value: bio.slice(0, 60) + (bio.length > 60 ? '...' : '') }] : []),
                ].map((item, i) => (
                  <View key={i} style={[styles.reviewRow, i > 0 && styles.reviewRowBorder]}>
                    <Text style={styles.reviewValue} numberOfLines={2}>{item.value}</Text>
                    <View style={styles.reviewLabel}>
                      <Text style={styles.reviewLabelText}>{item.label}</Text>
                      <MaterialIcons name={item.icon as any} size={16} color={Colors.gold} />
                    </View>
                  </View>
                ))}
              </View>

              {/* Instant activation notice */}
              <View style={styles.infoBox}>
                <MaterialIcons name="flash-on" size={18} color={Colors.gold} />
                <Text style={styles.infoText}>
                  حسابك سيُفعَّل{' '}
                  <Text style={{ color: Colors.gold, fontWeight: FontWeight.bold }}>فوراً</Text>
                  {' '}بعد الإرسال — لا حاجة للانتظار، ملفك سيظهر للعملاء مباشرة.
                </Text>
              </View>

              <Pressable style={styles.editBtn} onPress={() => setStep(1)}>
                <MaterialIcons name="edit" size={16} color={Colors.gold} />
                <Text style={styles.editBtnText}>تعديل البيانات</Text>
              </Pressable>
            </View>
          )}
        </ScrollView>

        {/* Bottom Action */}
        <View style={[styles.bottomAction, { paddingBottom: insets.bottom + Spacing.md }]}>
          {step < STEPS.length - 1 ? (
            <Pressable style={styles.nextBtn} onPress={goNext}>
              {({ pressed }) => (
                <View style={[styles.nextBtnInner, pressed && { opacity: 0.88 }]}>
                  <MaterialIcons name="arrow-back" size={20} color={Colors.primary} />
                  <Text style={styles.nextBtnText}>التالي</Text>
                </View>
              )}
            </Pressable>
          ) : (
            <Pressable
              style={[styles.submitBtn, (loading || uploadingPhoto) && { opacity: 0.7 }]}
              onPress={handleSubmit}
              disabled={loading || uploadingPhoto}
            >
              {loading || uploadingPhoto ? (
                <View style={styles.submitLoading}>
                  <ActivityIndicator color={Colors.primary} size="small" />
                  <Text style={styles.submitBtnText}>
                    {uploadingPhoto ? 'جاري رفع الصورة...' : 'جاري الإرسال...'}
                  </Text>
                </View>
              ) : (
                <View style={styles.submitLoading}>
                  <MaterialIcons name="flash-on" size={20} color={Colors.primary} />
                  <Text style={styles.submitBtnText}>تفعيل الحساب فوراً</Text>
                </View>
              )}
            </Pressable>
          )}
        </View>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  centered: { flex: 1, alignItems: 'center', justifyContent: 'center' },

  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: Spacing.md, paddingVertical: Spacing.md,
    borderBottomWidth: 1, borderBottomColor: Colors.divider,
  },
  backBtn: { width: 44, height: 44, borderRadius: Radius.md, backgroundColor: Colors.surface, alignItems: 'center', justifyContent: 'center' },
  headerCenter: { alignItems: 'center', gap: 2 },
  headerTitle: { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: Colors.text },
  headerSub: { fontSize: FontSize.xs, color: Colors.textMuted },

  progressContainer: { maxHeight: 68, borderBottomWidth: 1, borderBottomColor: Colors.divider },
  progressScroll: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: Spacing.md, paddingVertical: Spacing.sm, gap: Spacing.xl },
  stepItem: { alignItems: 'center', gap: 4 },
  stepCircle: {
    width: 30, height: 30, borderRadius: 15,
    backgroundColor: Colors.surface, borderWidth: 1.5, borderColor: Colors.border,
    alignItems: 'center', justifyContent: 'center',
  },
  stepCircleActive: { backgroundColor: Colors.gold, borderColor: Colors.gold },
  stepCircleDone: { backgroundColor: Colors.success, borderColor: Colors.success },
  stepNum: { fontSize: FontSize.xs, color: Colors.textMuted, fontWeight: FontWeight.bold },
  stepNumActive: { color: Colors.primary },
  stepLabel: { fontSize: 10, color: Colors.textMuted, textAlign: 'center', minWidth: 50 },
  stepLabelActive: { color: Colors.gold, fontWeight: FontWeight.semibold },

  scroll: { paddingHorizontal: Spacing.lg, paddingTop: Spacing.md },
  stepContent: { gap: Spacing.lg },
  stepIntro: { alignItems: 'center', gap: Spacing.sm, paddingVertical: Spacing.sm },
  stepTitle: { fontSize: FontSize.xl, fontWeight: FontWeight.bold, color: Colors.text, textAlign: 'center' },
  stepSubtitle: { fontSize: FontSize.sm, color: Colors.textMuted, textAlign: 'center', lineHeight: 21 },

  benefitsRow: { backgroundColor: Colors.surface, borderRadius: Radius.xl, borderWidth: 1, borderColor: Colors.border, padding: Spacing.md, gap: Spacing.sm },
  benefitItem: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, justifyContent: 'flex-end' },
  benefitText: { fontSize: FontSize.sm, color: Colors.textMuted, textAlign: 'right' },

  specialtyGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm },
  specialtyCard: { width: '47%', borderRadius: Radius.xl, backgroundColor: Colors.surface, borderWidth: 1.5, borderColor: Colors.border, overflow: 'hidden' },
  specialtyCardActive: { borderColor: Colors.gold, backgroundColor: Colors.gold },
  specialtyInner: { paddingVertical: Spacing.lg, alignItems: 'center', gap: Spacing.sm, position: 'relative' },
  specialtyCheck: { position: 'absolute', top: 8, left: 8 },
  specialtyLabel: { fontSize: FontSize.sm, color: Colors.text, fontWeight: FontWeight.semibold },
  specialtyLabelActive: { color: Colors.primary },

  inputGroup: { gap: Spacing.sm },
  label: { fontSize: FontSize.sm, color: Colors.textMuted, textAlign: 'right', fontWeight: FontWeight.medium },
  inputHint: { fontSize: 10, color: Colors.textMuted, textAlign: 'right' },
  inputRow: {
    flexDirection: 'row', alignItems: 'center', backgroundColor: Colors.surface,
    borderRadius: Radius.md, borderWidth: 1, borderColor: Colors.border,
    paddingHorizontal: Spacing.md, paddingVertical: 14, gap: Spacing.sm,
  },
  input: { flex: 1, color: Colors.text, fontSize: FontSize.base },
  bioInput: {
    backgroundColor: Colors.surface, borderRadius: Radius.md, borderWidth: 1, borderColor: Colors.border,
    paddingHorizontal: Spacing.md, paddingVertical: 12, color: Colors.text, fontSize: FontSize.base, minHeight: 90,
  },
  expGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm },
  expChip: { paddingHorizontal: 14, paddingVertical: 9, backgroundColor: Colors.surface, borderRadius: Radius.full, borderWidth: 1, borderColor: Colors.border },
  expChipActive: { backgroundColor: Colors.gold, borderColor: Colors.gold },
  expChipText: { fontSize: FontSize.sm, color: Colors.textMuted, fontWeight: FontWeight.medium },
  expChipTextActive: { color: Colors.primary, fontWeight: FontWeight.bold },

  countryGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm },
  countryChip: { paddingHorizontal: 12, paddingVertical: 8, backgroundColor: Colors.surface, borderRadius: Radius.full, borderWidth: 1, borderColor: Colors.border },
  countryChipActive: { backgroundColor: Colors.gold, borderColor: Colors.gold },
  countryChipText: { fontSize: FontSize.sm, color: Colors.textMuted, fontWeight: FontWeight.medium },
  countryChipTextActive: { color: Colors.primary, fontWeight: FontWeight.bold },
  provinceGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm },
  provChip: { paddingHorizontal: 12, paddingVertical: 8, backgroundColor: Colors.surface, borderRadius: Radius.full, borderWidth: 1, borderColor: Colors.border },
  provChipActive: { backgroundColor: Colors.primarySurface, borderColor: Colors.gold },
  provChipText: { fontSize: FontSize.sm, color: Colors.textMuted, fontWeight: FontWeight.medium },
  provChipTextActive: { color: Colors.gold, fontWeight: FontWeight.bold },

  locationSummary: {
    flexDirection: 'row', alignItems: 'flex-start', gap: Spacing.sm,
    backgroundColor: 'rgba(46,204,113,0.08)', borderRadius: Radius.lg,
    padding: Spacing.md, borderWidth: 1, borderColor: 'rgba(46,204,113,0.25)',
  },
  locationSummaryText: { flex: 1, alignItems: 'flex-end', gap: 3 },
  locationSummaryMain: { fontSize: FontSize.base, color: Colors.text, fontWeight: FontWeight.semibold, textAlign: 'right' },
  locationSummaryDetail: { fontSize: FontSize.xs, color: Colors.textMuted, textAlign: 'right' },

  photoArea: { alignItems: 'center', gap: Spacing.lg },
  photoCircle: { width: 160, height: 160, borderRadius: 80, borderWidth: 3, borderColor: Colors.gold, backgroundColor: Colors.surface, overflow: 'hidden', position: 'relative', alignItems: 'center', justifyContent: 'center' },
  photoPreview: { width: '100%', height: '100%' },
  photoPlaceholder: { alignItems: 'center', gap: Spacing.sm },
  photoPlaceholderText: { fontSize: FontSize.xs, color: Colors.textMuted, textAlign: 'center' },
  photoCameraBtn: { position: 'absolute', bottom: 8, right: 8, width: 36, height: 36, borderRadius: 18, backgroundColor: Colors.gold, alignItems: 'center', justifyContent: 'center', borderWidth: 2, borderColor: Colors.background },
  photoActions: { flexDirection: 'row', gap: Spacing.md },
  photoActionBtn: { alignItems: 'center', gap: 6, backgroundColor: Colors.surface, borderRadius: Radius.lg, paddingVertical: Spacing.md, paddingHorizontal: Spacing.lg, borderWidth: 1, borderColor: Colors.border },
  photoActionText: { fontSize: FontSize.xs, color: Colors.gold, fontWeight: FontWeight.semibold },
  photoTips: { backgroundColor: Colors.surface, borderRadius: Radius.xl, borderWidth: 1, borderColor: Colors.border, padding: Spacing.md, gap: Spacing.sm },
  photoTipsTitle: { fontSize: FontSize.sm, color: Colors.gold, fontWeight: FontWeight.semibold, textAlign: 'right' },
  photoTip: { flexDirection: 'row', gap: Spacing.sm, alignItems: 'center', justifyContent: 'flex-end' },
  photoTipText: { fontSize: FontSize.sm, color: Colors.textMuted },
  skipPhotoBtn: { alignItems: 'center', paddingVertical: Spacing.sm },
  skipPhotoBtnText: { fontSize: FontSize.sm, color: Colors.textMuted, textDecorationLine: 'underline' },

  reviewPhotoRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md, backgroundColor: Colors.surface, borderRadius: Radius.xl, padding: Spacing.md, borderWidth: 1, borderColor: Colors.border },
  reviewPhoto: { width: 72, height: 72, borderRadius: 36, borderWidth: 2, borderColor: Colors.gold },
  reviewPhotoPlaceholder: { width: 72, height: 72, borderRadius: 36, backgroundColor: Colors.surface2, borderWidth: 2, borderColor: Colors.border, alignItems: 'center', justifyContent: 'center' },
  reviewPhotoInfo: { flex: 1, alignItems: 'flex-end', gap: 4 },
  reviewName: { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: Colors.text, textAlign: 'right' },
  reviewSpecialty: { fontSize: FontSize.sm, color: Colors.gold },
  reviewCityRow: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  reviewCity: { fontSize: FontSize.xs, color: Colors.textMuted },
  reviewCard: { backgroundColor: Colors.surface, borderRadius: Radius.xl, borderWidth: 1, borderColor: Colors.border, overflow: 'hidden' },
  reviewRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: Spacing.md, paddingVertical: 13 },
  reviewRowBorder: { borderTopWidth: 1, borderTopColor: Colors.divider },
  reviewLabel: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, minWidth: 90 },
  reviewLabelText: { fontSize: FontSize.sm, color: Colors.textMuted },
  reviewValue: { fontSize: FontSize.sm, color: Colors.text, fontWeight: FontWeight.semibold, flex: 1, textAlign: 'right' },
  infoBox: { flexDirection: 'row', gap: Spacing.sm, backgroundColor: Colors.goldSoft, borderRadius: Radius.lg, padding: Spacing.md, borderWidth: 1, borderColor: 'rgba(212,160,23,0.3)', alignItems: 'flex-start' },
  infoText: { flex: 1, fontSize: FontSize.sm, color: Colors.textMuted, textAlign: 'right', lineHeight: 22 },
  editBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, backgroundColor: Colors.goldSoft, borderRadius: Radius.lg, paddingVertical: 12, borderWidth: 1, borderColor: 'rgba(212,160,23,0.3)' },
  editBtnText: { fontSize: FontSize.sm, color: Colors.gold, fontWeight: FontWeight.semibold },

  bottomAction: { paddingHorizontal: Spacing.lg, paddingTop: Spacing.md, backgroundColor: Colors.background, borderTopWidth: 1, borderTopColor: Colors.divider },
  nextBtn: { borderRadius: Radius.lg, overflow: 'hidden' },
  nextBtnInner: { backgroundColor: Colors.gold, borderRadius: Radius.lg, paddingVertical: 16, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: Spacing.sm, ...Shadow.gold },
  nextBtnText: { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: Colors.primary },
  submitBtn: { backgroundColor: Colors.gold, borderRadius: Radius.lg, paddingVertical: 16, alignItems: 'center', ...Shadow.gold },
  submitLoading: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  submitBtnText: { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: Colors.primary },

  successContainer: { alignItems: 'center', justifyContent: 'center', padding: Spacing.xl, gap: Spacing.lg },
  successIconBg: { width: 130, height: 130, borderRadius: 65, backgroundColor: 'rgba(46,204,113,0.1)', borderWidth: 2, borderColor: 'rgba(46,204,113,0.3)', alignItems: 'center', justifyContent: 'center' },
  successTitle: { fontSize: FontSize.xxl, fontWeight: FontWeight.bold, color: Colors.text, textAlign: 'center' },
  successText: { fontSize: FontSize.base, color: Colors.textMuted, textAlign: 'center', lineHeight: 26 },
  successSteps: { gap: Spacing.sm, width: '100%' },
  successStep: { flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-end', gap: Spacing.md, backgroundColor: Colors.surface, borderRadius: Radius.lg, paddingVertical: 11, paddingHorizontal: Spacing.md, borderWidth: 1, borderColor: Colors.border },
  successStepText: { flex: 1, fontSize: FontSize.sm, color: Colors.text, textAlign: 'right', fontWeight: FontWeight.medium },
  successStepDot: { width: 28, height: 28, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  successStepNum: { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: Colors.primary },
  successInfoBox: { flexDirection: 'row', alignItems: 'flex-start', gap: Spacing.sm, backgroundColor: Colors.goldSoft, borderRadius: Radius.lg, padding: Spacing.md, borderWidth: 1, borderColor: 'rgba(212,160,23,0.3)' },
  successInfoText: { flex: 1, fontSize: FontSize.sm, color: Colors.text, textAlign: 'right', lineHeight: 21 },
  homeBtn: { backgroundColor: Colors.gold, borderRadius: Radius.lg, paddingVertical: 15, paddingHorizontal: 48, ...Shadow.gold },
  homeBtnText: { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: Colors.primary },

  gpsBtn: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.sm,
    backgroundColor: Colors.goldSoft, borderRadius: Radius.lg,
    paddingVertical: 12, paddingHorizontal: Spacing.md,
    borderWidth: 1, borderColor: 'rgba(212,160,23,0.3)',
  },
  gpsBtnSuccess: {
    backgroundColor: 'rgba(46,204,113,0.1)',
    borderColor: 'rgba(46,204,113,0.3)',
  },
  gpsBtnText: {
    fontSize: FontSize.sm, color: Colors.gold, fontWeight: FontWeight.medium, flex: 1, textAlign: 'right',
  },
  priceRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  priceInput: { flex: 1, paddingVertical: 14 },
  priceSep: { color: Colors.textMuted, fontSize: FontSize.lg, fontWeight: FontWeight.bold },
});
