import React, { useEffect, useRef } from 'react';
import {
  View, Text, StyleSheet, Animated, Pressable, Dimensions, ActivityIndicator,
} from 'react-native';
import { useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import { Colors, FontSize, FontWeight, Radius, Spacing } from '@/constants/theme';
import { useAuth } from '@/template';

const { width, height } = Dimensions.get('window');

export default function SplashScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { user, loading } = useAuth();

  const logoAnim = useRef(new Animated.Value(0)).current;
  const titleAnim = useRef(new Animated.Value(0)).current;
  const subtitleAnim = useRef(new Animated.Value(0)).current;
  const btnAnim = useRef(new Animated.Value(0)).current;
  const pulseAnim = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, { toValue: 1.08, duration: 1500, useNativeDriver: true }),
        Animated.timing(pulseAnim, { toValue: 1, duration: 1500, useNativeDriver: true }),
      ])
    ).start();

    Animated.stagger(200, [
      Animated.timing(logoAnim, { toValue: 1, duration: 700, useNativeDriver: true }),
      Animated.timing(titleAnim, { toValue: 1, duration: 600, useNativeDriver: true }),
      Animated.timing(subtitleAnim, { toValue: 1, duration: 600, useNativeDriver: true }),
      Animated.timing(btnAnim, { toValue: 1, duration: 700, useNativeDriver: true }),
    ]).start();
  }, []);

  // Auto-redirect when auth state is known
  useEffect(() => {
    if (!loading && user) {
      router.replace('/(tabs)');
    }
  }, [loading, user]);

  const handleEnter = () => {
    if (user) {
      router.replace('/(tabs)');
    } else {
      router.push('/auth/login');
    }
  };

  const handleGuest = () => {
    router.replace('/(tabs)');
  };

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <StatusBar style="light" />
      <View style={styles.bgCircle1} />
      <View style={styles.bgCircle2} />
      <View style={styles.bgCircle3} />
      <Image
        source={require('@/assets/images/splash-hero.png')}
        style={styles.heroBg}
        contentFit="cover"
      />
      <View style={styles.overlay} />

      <View style={styles.content}>
        <Animated.View style={[styles.logoContainer, {
          opacity: logoAnim,
          transform: [
            { translateY: logoAnim.interpolate({ inputRange: [0, 1], outputRange: [-40, 0] }) },
            { scale: pulseAnim },
          ],
        }]}>
          <View style={styles.logoCircle}>
            <MaterialIcons name="home-repair-service" size={52} color={Colors.gold} />
          </View>
          <View style={styles.logoGlow} />
        </Animated.View>

        <Animated.View style={{ opacity: titleAnim, transform: [{ translateY: titleAnim.interpolate({ inputRange: [0, 1], outputRange: [20, 0] }) }] }}>
          <Text style={styles.appName}>معلم</Text>
        </Animated.View>

        <Animated.View style={{ opacity: subtitleAnim, transform: [{ translateY: subtitleAnim.interpolate({ inputRange: [0, 1], outputRange: [20, 0] }) }] }}>
          <Text style={styles.tagline}>الحرفي الموثوق… أقرب إليك</Text>
          <View style={styles.divider} />
          <Text style={styles.subtitle}>اعثر على أفضل الحرفيين والفنيين{'\n'}في مدينتك بكل سهولة</Text>
        </Animated.View>

        <Animated.View style={[styles.statsRow, { opacity: subtitleAnim }]}>
          {[
            { num: '500+', label: 'حرفي' },
            { num: '5000+', label: 'عميل' },
            { num: '4.9', label: 'تقييم' },
          ].map((s, i) => (
            <View key={i} style={styles.statItem}>
              <Text style={styles.statNum}>{s.num}</Text>
              <Text style={styles.statLabel}>{s.label}</Text>
            </View>
          ))}
        </Animated.View>
      </View>

      <Animated.View style={[styles.btnContainer, {
        opacity: btnAnim,
        paddingBottom: insets.bottom + 24,
        transform: [{ translateY: btnAnim.interpolate({ inputRange: [0, 1], outputRange: [40, 0] }) }],
      }]}>
        {loading ? (
          <View style={styles.loadingRow}>
            <ActivityIndicator color={Colors.gold} size="small" />
            <Text style={styles.loadingText}>جاري التحقق من الجلسة...</Text>
          </View>
        ) : (
          <>
            <Pressable style={styles.primaryBtn} onPress={handleEnter}>
              {({ pressed }) => (
                <View style={[styles.primaryBtnInner, pressed && styles.pressed]}>
                  <Text style={styles.primaryBtnText}>
                    {user ? 'متابعة' : 'ابدأ الآن'}
                  </Text>
                  <MaterialIcons name="arrow-back" size={20} color={Colors.primary} />
                </View>
              )}
            </Pressable>
            {!user && (
              <Pressable style={styles.secondaryBtn} onPress={handleGuest}>
                {({ pressed }) => (
                  <Text style={[styles.secondaryBtnText, pressed && { opacity: 0.7 }]}>
                    تصفح كضيف
                  </Text>
                )}
              </Pressable>
            )}
          </>
        )}
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  heroBg: { position: 'absolute', width: '100%', height: '100%', opacity: 0.25 },
  overlay: { position: 'absolute', width: '100%', height: '100%', backgroundColor: 'rgba(8, 15, 32, 0.75)' },
  bgCircle1: { position: 'absolute', width: 300, height: 300, borderRadius: 150, backgroundColor: 'rgba(212, 160, 23, 0.06)', top: -50, right: -80 },
  bgCircle2: { position: 'absolute', width: 250, height: 250, borderRadius: 125, backgroundColor: 'rgba(13, 27, 62, 0.8)', bottom: 100, left: -60 },
  bgCircle3: { position: 'absolute', width: 150, height: 150, borderRadius: 75, backgroundColor: 'rgba(212, 160, 23, 0.04)', top: '45%', right: 30 },
  content: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: Spacing.xl },
  logoContainer: { alignItems: 'center', marginBottom: Spacing.lg },
  logoCircle: { width: 110, height: 110, borderRadius: 55, backgroundColor: 'rgba(212,160,23,0.12)', borderWidth: 2, borderColor: 'rgba(212,160,23,0.5)', alignItems: 'center', justifyContent: 'center', zIndex: 1 },
  logoGlow: { position: 'absolute', width: 130, height: 130, borderRadius: 65, backgroundColor: 'rgba(212,160,23,0.08)', zIndex: 0 },
  appName: { fontSize: 62, fontWeight: FontWeight.extrabold, color: Colors.gold, textAlign: 'center', letterSpacing: 2, marginBottom: Spacing.sm, writingDirection: 'rtl' },
  tagline: { fontSize: FontSize.lg, color: Colors.goldLight, textAlign: 'center', fontWeight: FontWeight.semibold, marginBottom: Spacing.md, writingDirection: 'rtl' },
  divider: { width: 60, height: 2, backgroundColor: Colors.gold, alignSelf: 'center', marginBottom: Spacing.md, borderRadius: 1, opacity: 0.6 },
  subtitle: { fontSize: FontSize.base, color: Colors.textMuted, textAlign: 'center', lineHeight: 26, writingDirection: 'rtl' },
  statsRow: { flexDirection: 'row', marginTop: Spacing.xl, backgroundColor: 'rgba(255,255,255,0.05)', borderRadius: Radius.xl, borderWidth: 1, borderColor: Colors.glassBorder, paddingVertical: Spacing.md, paddingHorizontal: Spacing.lg, gap: Spacing.xl },
  statItem: { alignItems: 'center' },
  statNum: { fontSize: FontSize.xl, fontWeight: FontWeight.bold, color: Colors.gold, textAlign: 'center' },
  statLabel: { fontSize: FontSize.xs, color: Colors.textMuted, textAlign: 'center', marginTop: 2 },
  btnContainer: { paddingHorizontal: Spacing.lg, gap: Spacing.md },
  loadingRow: { alignItems: 'center', paddingVertical: Spacing.lg },
  loadingText: { color: Colors.textMuted, fontSize: FontSize.base },
  primaryBtn: { borderRadius: Radius.lg, overflow: 'hidden' },
  primaryBtnInner: { backgroundColor: Colors.gold, borderRadius: Radius.lg, paddingVertical: 17, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: Spacing.sm },
  pressed: { opacity: 0.85 },
  primaryBtnText: { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: Colors.primary, textAlign: 'center' },
  secondaryBtn: { paddingVertical: 14, alignItems: 'center' },
  secondaryBtnText: { fontSize: FontSize.base, color: Colors.textMuted, textAlign: 'center', fontWeight: FontWeight.medium, textDecorationLine: 'underline' },
});
