import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, Pressable, TextInput,
  KeyboardAvoidingView, Platform, ActivityIndicator, Linking,
} from 'react-native';
import { useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';
import { Colors, FontSize, FontWeight, Radius, Spacing, Shadow } from '@/constants/theme';
import { getSupabaseClient, useAuth, useAlert } from '@/template';

const CONTACT_TYPES = [
  { key: 'support', label: 'دعم فني', icon: 'support-agent', color: Colors.info },
  { key: 'complaint', label: 'شكوى', icon: 'report-problem', color: Colors.error },
  { key: 'suggestion', label: 'اقتراح', icon: 'lightbulb', color: Colors.gold },
  { key: 'other', label: 'أخرى', icon: 'more-horiz', color: Colors.textMuted },
];

const FAQ = [
  { q: 'كيف أطلب خدمة؟', a: 'اضغط على "طلب خدمة" من الشاشة الرئيسية واتبع الخطوات البسيطة لاختيار الخدمة وتحديد الموقع.' },
  { q: 'كيف أتواصل مع الحرفي؟', a: 'بعد إرسال الطلب يمكنك التواصل مع الحرفي مباشرةً عبر نظام المحادثة داخل التطبيق.' },
  { q: 'كيف أصبح حرفياً معتمداً؟', a: 'اضغط على "سجّل كحرفي" من الصفحة الرئيسية وأكمل نموذج التسجيل. سيراجع الفريق طلبك خلال 24-48 ساعة.' },
  { q: 'هل خدماتكم متاحة طوال اليوم؟', a: 'نعم، يمكنك طلب الخدمات على مدار الساعة. يُحدد الحرفي المتاح وفق جدوله وموقعك.' },
  { q: 'كيف تُحسب أسعار الخدمات؟', a: 'يحدد كل حرفي نطاق سعره. يتم الاتفاق على السعر النهائي بعد تقييم المشكلة.' },
];

export default function ContactScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const { showAlert } = useAlert();
  const supabase = getSupabaseClient();

  const [type, setType] = useState('support');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [sending, setSending] = useState(false);
  const [expandedFaq, setExpandedFaq] = useState<number | null>(null);

  const handleSend = async () => {
    if (!subject.trim()) { showAlert('تنبيه', 'يرجى إدخال موضوع الرسالة'); return; }
    if (message.trim().length < 20) { showAlert('تنبيه', 'يرجى كتابة رسالة مفصلة (20 حرف على الأقل)'); return; }

    setSending(true);
    try {
      // Store as notification record (using notifications table as contact form storage)
      if (user) {
        await supabase.from('notifications').insert({
          user_id: user.id,
          title: `رسالة تواصل: ${subject.trim()}`,
          body: `النوع: ${CONTACT_TYPES.find(t => t.key === type)?.label}\n${message.trim()}`,
          type: 'system',
          is_read: false,
        });
      }

      await new Promise(res => setTimeout(res, 800)); // Simulate sending
      showAlert('تم الإرسال', 'شكراً لتواصلك! سيرد فريقنا خلال 24 ساعة', [
        { text: 'حسناً', onPress: () => { setSubject(''); setMessage(''); router.back(); } },
      ]);
    } catch {
      showAlert('خطأ', 'لم يتم الإرسال، حاول مرة أخرى');
    } finally {
      setSending(false);
    }
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <View style={[styles.container, { paddingTop: insets.top }]}>
        <StatusBar style="light" />

        <View style={styles.header}>
          <View style={{ width: 44 }} />
          <Text style={styles.headerTitle}>تواصل معنا</Text>
          <Pressable style={styles.backBtn} onPress={() => router.back()}>
            <MaterialIcons name="arrow-forward" size={22} color={Colors.text} />
          </Pressable>
        </View>

        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={[styles.content, { paddingBottom: insets.bottom + 30 }]}
          keyboardShouldPersistTaps="handled"
        >
          {/* Hero */}
          <View style={styles.hero}>
            <View style={styles.heroIcon}>
              <MaterialIcons name="support-agent" size={40} color={Colors.gold} />
            </View>
            <Text style={styles.heroTitle}>كيف يمكننا مساعدتك؟</Text>
            <Text style={styles.heroText}>فريقنا جاهز للإجابة على جميع استفساراتك</Text>
          </View>

          {/* Quick Contact Channels */}
          <View style={styles.channelsSection}>
            <Text style={styles.sectionTitle}>قنوات التواصل السريع</Text>
            <View style={styles.channelsGrid}>
              {[
                { icon: 'phone', label: 'اتصل بنا', sub: '00963993226521', color: Colors.success, onPress: () => Linking.openURL('tel:00963993226521') },
                { icon: 'whatsapp', label: 'واتساب', sub: '00963993226521', color: '#25D366', onPress: () => Linking.openURL('https://wa.me/963993226521') },
                { icon: 'email', label: 'البريد', sub: 'support@muallim.sa', color: Colors.info, onPress: () => Linking.openURL('mailto:support@muallim.sa') },
                { icon: 'language', label: 'الموقع', sub: 'muallim.sa', color: Colors.gold, onPress: () => Linking.openURL('https://muallim.sa') },
              ].map((ch, i) => (
                <Pressable key={i} style={styles.channelCard} onPress={ch.onPress}>
                  {({ pressed }) => (
                    <View style={[styles.channelCardInner, pressed && { opacity: 0.85 }]}>
                      <MaterialIcons name={ch.icon as any} size={26} color={ch.color} />
                      <Text style={styles.channelLabel}>{ch.label}</Text>
                      <Text style={styles.channelSub}>{ch.sub}</Text>
                    </View>
                  )}
                </Pressable>
              ))}
            </View>
          </View>

          {/* Contact Form */}
          <View style={styles.formSection}>
            <Text style={styles.sectionTitle}>أرسل رسالة</Text>

            {/* Type selector */}
            <View style={styles.typeRow}>
              {CONTACT_TYPES.map(ct => (
                <Pressable
                  key={ct.key}
                  style={[styles.typeChip, type === ct.key && styles.typeChipActive]}
                  onPress={() => setType(ct.key)}
                >
                  <MaterialIcons
                    name={ct.icon as any}
                    size={14}
                    color={type === ct.key ? Colors.primary : ct.color}
                  />
                  <Text style={[styles.typeChipText, type === ct.key && styles.typeChipTextActive]}>
                    {ct.label}
                  </Text>
                </Pressable>
              ))}
            </View>

            {/* User info (if logged in) */}
            {user && (
              <View style={styles.userInfoCard}>
                <MaterialIcons name="person" size={16} color={Colors.gold} />
                <Text style={styles.userInfoText}>
                  سيتم إرسال الرد إلى: <Text style={{ color: Colors.text, fontWeight: FontWeight.semibold }}>{user.email}</Text>
                </Text>
              </View>
            )}

            {/* Subject */}
            <View style={styles.inputGroup}>
              <Text style={styles.label}>الموضوع *</Text>
              <View style={styles.inputRow}>
                <TextInput
                  style={styles.input}
                  value={subject}
                  onChangeText={setSubject}
                  placeholder="موضوع رسالتك..."
                  placeholderTextColor={Colors.textMuted}
                  textAlign="right"
                />
                <MaterialIcons name="subject" size={20} color={Colors.textMuted} />
              </View>
            </View>

            {/* Message */}
            <View style={styles.inputGroup}>
              <Text style={styles.label}>الرسالة * (20 حرف على الأقل)</Text>
              <TextInput
                style={styles.textArea}
                value={message}
                onChangeText={setMessage}
                placeholder="اكتب رسالتك هنا بالتفصيل..."
                placeholderTextColor={Colors.textMuted}
                textAlign="right"
                multiline
                numberOfLines={5}
                textAlignVertical="top"
              />
              <Text style={[styles.charCount, message.length < 20 && message.length > 0 && { color: Colors.error }]}>
                {message.length} / 500
              </Text>
            </View>

            {/* Send button */}
            <Pressable
              style={[styles.sendBtn, sending && { opacity: 0.7 }]}
              onPress={handleSend}
              disabled={sending}
            >
              {sending ? (
                <ActivityIndicator color={Colors.primary} />
              ) : (
                <>
                  <MaterialIcons name="send" size={20} color={Colors.primary} />
                  <Text style={styles.sendBtnText}>إرسال الرسالة</Text>
                </>
              )}
            </Pressable>

            <Text style={styles.replyTime}>
              <MaterialIcons name="access-time" size={13} color={Colors.textMuted} /> عادةً نرد خلال 24 ساعة
            </Text>
          </View>

          {/* FAQ */}
          <View style={styles.faqSection}>
            <Text style={styles.sectionTitle}>الأسئلة الشائعة</Text>
            {FAQ.map((item, i) => (
              <Pressable
                key={i}
                style={styles.faqItem}
                onPress={() => setExpandedFaq(expandedFaq === i ? null : i)}
              >
                <View style={styles.faqHeader}>
                  <MaterialIcons
                    name={expandedFaq === i ? 'expand-less' : 'expand-more'}
                    size={22}
                    color={expandedFaq === i ? Colors.gold : Colors.textMuted}
                  />
                  <Text style={[styles.faqQ, expandedFaq === i && { color: Colors.gold }]}>
                    {item.q}
                  </Text>
                  <MaterialIcons name="help-outline" size={16} color={Colors.gold} />
                </View>
                {expandedFaq === i && (
                  <Text style={styles.faqA}>{item.a}</Text>
                )}
              </Pressable>
            ))}
          </View>
        </ScrollView>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },

  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: Spacing.md, paddingVertical: Spacing.md,
    borderBottomWidth: 1, borderBottomColor: Colors.divider,
  },
  backBtn: {
    width: 44, height: 44, borderRadius: Radius.md,
    backgroundColor: Colors.surface, alignItems: 'center', justifyContent: 'center',
  },
  headerTitle: { fontSize: FontSize.xl, fontWeight: FontWeight.bold, color: Colors.text },

  content: { paddingHorizontal: Spacing.lg, paddingTop: Spacing.lg, gap: Spacing.xl },

  // Hero
  hero: { alignItems: 'center', gap: Spacing.sm },
  heroIcon: {
    width: 80, height: 80, borderRadius: 40,
    backgroundColor: Colors.goldSoft, borderWidth: 1.5, borderColor: 'rgba(212,160,23,0.3)',
    alignItems: 'center', justifyContent: 'center',
  },
  heroTitle: { fontSize: FontSize.xl, fontWeight: FontWeight.bold, color: Colors.text },
  heroText: { fontSize: FontSize.base, color: Colors.textMuted, textAlign: 'center' },

  sectionTitle: {
    fontSize: FontSize.base, fontWeight: FontWeight.bold, color: Colors.text,
    textAlign: 'right', marginBottom: Spacing.sm,
  },

  // Channels
  channelsSection: { gap: Spacing.sm },
  channelsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm },
  channelCard: { width: '47%' },
  channelCardInner: {
    backgroundColor: Colors.surface, borderRadius: Radius.xl,
    borderWidth: 1, borderColor: Colors.border,
    padding: Spacing.md, alignItems: 'center', gap: Spacing.sm,
    ...Shadow.sm,
  },
  channelLabel: { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: Colors.text },
  channelSub: { fontSize: FontSize.xs, color: Colors.textMuted, textAlign: 'center' },

  // Form
  formSection: { gap: Spacing.md },
  typeRow: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm, justifyContent: 'flex-end' },
  typeChip: {
    flexDirection: 'row', alignItems: 'center', gap: 5,
    paddingHorizontal: 12, paddingVertical: 8,
    backgroundColor: Colors.surface, borderRadius: Radius.full,
    borderWidth: 1, borderColor: Colors.border,
  },
  typeChipActive: { backgroundColor: Colors.gold, borderColor: Colors.gold },
  typeChipText: { fontSize: FontSize.xs, color: Colors.textMuted, fontWeight: FontWeight.medium },
  typeChipTextActive: { color: Colors.primary, fontWeight: FontWeight.bold },

  userInfoCard: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, justifyContent: 'flex-end',
    backgroundColor: Colors.goldSoft, borderRadius: Radius.lg,
    paddingHorizontal: Spacing.md, paddingVertical: 10,
    borderWidth: 1, borderColor: 'rgba(212,160,23,0.25)',
  },
  userInfoText: { fontSize: FontSize.xs, color: Colors.textMuted, flex: 1, textAlign: 'right' },

  inputGroup: { gap: Spacing.sm },
  label: { fontSize: FontSize.sm, color: Colors.textMuted, textAlign: 'right', fontWeight: FontWeight.medium },
  inputRow: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.sm,
    backgroundColor: Colors.surface, borderRadius: Radius.md,
    borderWidth: 1, borderColor: Colors.border,
    paddingHorizontal: Spacing.md, paddingVertical: 14,
  },
  input: { flex: 1, color: Colors.text, fontSize: FontSize.base },
  textArea: {
    backgroundColor: Colors.surface, borderRadius: Radius.md,
    borderWidth: 1, borderColor: Colors.border,
    paddingHorizontal: Spacing.md, paddingVertical: 13,
    color: Colors.text, fontSize: FontSize.base, minHeight: 130,
  },
  charCount: { fontSize: FontSize.xs, color: Colors.textMuted, textAlign: 'left' },

  sendBtn: {
    backgroundColor: Colors.gold, borderRadius: Radius.lg,
    paddingVertical: 15, flexDirection: 'row', alignItems: 'center',
    justifyContent: 'center', gap: Spacing.sm, ...Shadow.gold,
  },
  sendBtnText: { fontSize: FontSize.base, fontWeight: FontWeight.bold, color: Colors.primary },
  replyTime: { fontSize: FontSize.xs, color: Colors.textMuted, textAlign: 'center' },

  // FAQ
  faqSection: { gap: Spacing.sm },
  faqItem: {
    backgroundColor: Colors.surface, borderRadius: Radius.xl,
    borderWidth: 1, borderColor: Colors.border, overflow: 'hidden',
  },
  faqHeader: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.sm,
    padding: Spacing.md,
  },
  faqQ: { flex: 1, fontSize: FontSize.base, fontWeight: FontWeight.semibold, color: Colors.text, textAlign: 'right' },
  faqA: {
    fontSize: FontSize.sm, color: Colors.textMuted, textAlign: 'right', lineHeight: 22,
    paddingHorizontal: Spacing.md, paddingBottom: Spacing.md,
    borderTopWidth: 1, borderTopColor: Colors.divider, paddingTop: Spacing.sm,
  },
});
