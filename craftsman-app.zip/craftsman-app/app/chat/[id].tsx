/**
 * Chat Screen
 * Route: /chat/[id]
 *
 * The `id` param is the craftsmen.id (not user_id).
 * Works for both:
 *   - Customer messaging craftsman: sender = customer, receiver = craftsman's user_id
 *   - Craftsman viewing their own conversations: id = their own craftsmen.id,
 *     we detect this and flip the receiver to the order's customer user_id.
 *
 * When a craftsman opens this from an order, pass ?orderId=xxx so we can
 * look up the customer's user_id for the receiver field.
 */
import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  View, Text, StyleSheet, FlatList, TextInput,
  Pressable, KeyboardAvoidingView, Platform, ActivityIndicator, Alert, Linking,
} from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import * as ImagePicker from 'expo-image-picker';
import { Colors, FontSize, FontWeight, Radius, Spacing } from '@/constants/theme';
import { getSupabaseClient, useAuth } from '@/template';
import { useApp } from '@/hooks/useApp';

// ─── Types ────────────────────────────────────────────────────────────────────
interface Message {
  id: string;
  content: string;
  senderId: string;
  messageType: 'text' | 'image';
  imageUrl?: string;
  isRead: boolean;
  createdAt: string;
  isMine: boolean;
}

interface PeerInfo {
  id: string;         // craftsmen.id
  name: string;
  specialty: string;
  image: string;
  available: boolean;
  phone: string;
  userId: string | null; // craftsmen.user_id
}

const POLLING_MS = 3000;

function mapMessage(row: any, myId: string): Message {
  return {
    id: row.id,
    content: row.content,
    senderId: row.sender_id,
    messageType: row.message_type ?? 'text',
    imageUrl: row.image_url,
    isRead: row.is_read ?? false,
    createdAt: row.created_at,
    isMine: row.sender_id === myId,
  };
}

function formatTime(iso: string) {
  return new Date(iso).toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' });
}

function formatDate(iso: string) {
  const d = new Date(iso);
  const today = new Date();
  const yesterday = new Date();
  yesterday.setDate(today.getDate() - 1);
  if (d.toDateString() === today.toDateString()) return 'اليوم';
  if (d.toDateString() === yesterday.toDateString()) return 'أمس';
  return d.toLocaleDateString('ar-SA', { day: 'numeric', month: 'long' });
}

// ─── Main Component ───────────────────────────────────────────────────────────
export default function ChatScreen() {
  const { id: craftsmanId, orderId } = useLocalSearchParams<{ id: string; orderId?: string }>();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const { userRole, craftsmanProfileId } = useApp();
  const supabase = getSupabaseClient();
  const listRef = useRef<FlatList>(null);
  const pollingRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const lastMsgIdRef = useRef<string | null>(null);

  const [messages, setMessages] = useState<Message[]>([]);
  const [peer, setPeer] = useState<PeerInfo | null>(null);
  const [input, setInput] = useState('');
  const [sending, setSending] = useState(false);
  const [loading, setLoading] = useState(true);
  const [receiverId, setReceiverId] = useState<string | null>(null);

  // ── Resolve peer and receiver ───────────────────────────────────────────
  const resolvePeer = useCallback(async () => {
    if (!craftsmanId || !user) return;

    // Fetch craftsman row
    const { data: craftsmanRow } = await supabase
      .from('craftsmen')
      .select('id, name, specialty, image_url, available, phone, user_id')
      .eq('id', craftsmanId)
      .single();

    if (!craftsmanRow) return;

    setPeer({
      id: craftsmanRow.id,
      name: craftsmanRow.name,
      specialty: craftsmanRow.specialty,
      image: craftsmanRow.image_url ?? 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400',
      available: craftsmanRow.available ?? false,
      phone: craftsmanRow.phone ?? '',
      userId: craftsmanRow.user_id,
    });

    // Determine receiver:
    // - If current user IS the craftsman (same user_id), we need the customer's user_id
    // - Otherwise receiver = craftsman's user_id
    if (craftsmanRow.user_id === user.id) {
      // This user is the craftsman — look up customer from orderId or most recent order
      let customerUserId: string | null = null;
      if (orderId) {
        const { data: orderRow } = await supabase
          .from('orders')
          .select('user_id')
          .eq('id', orderId)
          .single();
        customerUserId = orderRow?.user_id ?? null;
      } else {
        // Find the most recent order assigned to this craftsman
        const { data: recentOrder } = await supabase
          .from('orders')
          .select('user_id')
          .eq('craftsman_id', craftsmanId)
          .order('created_at', { ascending: false })
          .limit(1)
          .single();
        customerUserId = recentOrder?.user_id ?? null;
      }
      setReceiverId(customerUserId);
    } else {
      setReceiverId(craftsmanRow.user_id);
    }
  }, [craftsmanId, user, orderId]);

  // ── Fetch messages ─────────────────────────────────────────────────────
  const fetchMessages = useCallback(async (isPolling = false) => {
    if (!user || !craftsmanId) return;

    const { data, error } = await supabase
      .from('messages')
      .select('*')
      .eq('craftsman_id', craftsmanId)
      .or(`sender_id.eq.${user.id},receiver_id.eq.${user.id}`)
      .order('created_at', { ascending: true });

    if (!error && data) {
      const mapped = data.map((r: any) => mapMessage(r, user.id));

      if (isPolling) {
        const latestId = mapped.length > 0 ? mapped[mapped.length - 1].id : null;
        if (latestId !== lastMsgIdRef.current) {
          lastMsgIdRef.current = latestId;
          setMessages(mapped);
          setTimeout(() => listRef.current?.scrollToEnd({ animated: true }), 100);
        }
      } else {
        setMessages(mapped);
        lastMsgIdRef.current = mapped.length > 0 ? mapped[mapped.length - 1].id : null;
        setLoading(false);
        setTimeout(() => listRef.current?.scrollToEnd({ animated: false }), 100);
      }

      // Mark received as read
      const unreadIds = data
        .filter((r: any) => r.receiver_id === user.id && !r.is_read)
        .map((r: any) => r.id);
      if (unreadIds.length > 0) {
        await supabase.from('messages').update({ is_read: true }).in('id', unreadIds);
      }
    } else if (!isPolling) {
      setLoading(false);
    }
  }, [user, craftsmanId]);

  useEffect(() => {
    resolvePeer();
    fetchMessages(false);
  }, [resolvePeer, fetchMessages]);

  useEffect(() => {
    pollingRef.current = setInterval(() => fetchMessages(true), POLLING_MS);
    return () => { if (pollingRef.current) clearInterval(pollingRef.current); };
  }, [fetchMessages]);

  // ── Send text message ──────────────────────────────────────────────────
  const sendMessage = async () => {
    if (!input.trim() || !user || !craftsmanId) return;
    const targetReceiverId = receiverId ?? user.id;
    const text = input.trim();
    setInput('');
    setSending(true);

    const optimistic: Message = {
      id: `temp-${Date.now()}`,
      content: text,
      senderId: user.id,
      messageType: 'text',
      isRead: false,
      createdAt: new Date().toISOString(),
      isMine: true,
    };
    setMessages(prev => [...prev, optimistic]);
    setTimeout(() => listRef.current?.scrollToEnd({ animated: true }), 80);

    const { data, error } = await supabase
      .from('messages')
      .insert({
        craftsman_id: craftsmanId,
        sender_id: user.id,
        receiver_id: targetReceiverId,
        content: text,
        message_type: 'text',
      })
      .select()
      .single();

    setSending(false);
    if (!error && data) {
      setMessages(prev => prev.map(m => m.id === optimistic.id ? mapMessage(data, user.id) : m));
      lastMsgIdRef.current = data.id;
    } else {
      setMessages(prev => prev.filter(m => m.id !== optimistic.id));
      setInput(text);
    }
  };

  // ── Send image ────────────────────────────────────────────────────────
  const handleImagePick = async (source: 'camera' | 'gallery') => {
    if (!user || !craftsmanId) return;
    let result: ImagePicker.ImagePickerResult;

    if (source === 'camera') {
      const { status } = await ImagePicker.requestCameraPermissionsAsync();
      if (status !== 'granted') { Alert.alert('الكاميرا', 'يرجى السماح بالوصول إلى الكاميرا'); return; }
      result = await ImagePicker.launchCameraAsync({ mediaTypes: 'images', quality: 0.7, allowsEditing: true, aspect: [4, 3] });
    } else {
      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== 'granted') { Alert.alert('المعرض', 'يرجى السماح بالوصول إلى المعرض'); return; }
      result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: 'images', quality: 0.7, allowsEditing: true });
    }
    if (result.canceled || !result.assets?.[0]) return;

    const asset = result.assets[0];
    const targetReceiverId = receiverId ?? user.id;

    const optimistic: Message = {
      id: `temp-img-${Date.now()}`,
      content: '📷 صورة',
      senderId: user.id,
      messageType: 'image',
      imageUrl: asset.uri,
      isRead: false,
      createdAt: new Date().toISOString(),
      isMine: true,
    };
    setMessages(prev => [...prev, optimistic]);
    setTimeout(() => listRef.current?.scrollToEnd({ animated: true }), 80);

    try {
      const ext = asset.uri.split('.').pop() ?? 'jpg';
      const fileName = `chat/${user.id}/${Date.now()}.${ext}`;
      const response = await fetch(asset.uri);
      const blob = await response.blob();
      const arrayBuffer = await new Response(blob).arrayBuffer();
      const { error: uploadError } = await supabase.storage
        .from('chat-images').upload(fileName, arrayBuffer, { contentType: `image/${ext}`, upsert: true });
      if (uploadError) throw new Error(uploadError.message);
      const { data: { publicUrl } } = supabase.storage.from('chat-images').getPublicUrl(fileName);
      const { data, error } = await supabase.from('messages').insert({
        craftsman_id: craftsmanId,
        sender_id: user.id,
        receiver_id: targetReceiverId,
        content: '📷 صورة',
        message_type: 'image',
        image_url: publicUrl,
      }).select().single();
      if (!error && data) {
        setMessages(prev => prev.map(m => m.id === optimistic.id ? mapMessage(data, user.id) : m));
        lastMsgIdRef.current = data.id;
      } else {
        setMessages(prev => prev.filter(m => m.id !== optimistic.id));
      }
    } catch {
      setMessages(prev => prev.filter(m => m.id !== optimistic.id));
      Alert.alert('خطأ', 'لم يتم إرسال الصورة');
    }
  };

  // ── Group by date ─────────────────────────────────────────────────────
  type ListItem = Message | { type: 'date-separator'; date: string; key: string };
  const listData: ListItem[] = [];
  let lastDate = '';
  for (const msg of messages) {
    const dateLabel = formatDate(msg.createdAt);
    if (dateLabel !== lastDate) {
      listData.push({ type: 'date-separator', date: dateLabel, key: `sep-${msg.id}` });
      lastDate = dateLabel;
    }
    listData.push(msg);
  }

  // ── Render item ───────────────────────────────────────────────────────
  const renderItem = ({ item }: { item: ListItem }) => {
    if ('type' in item && item.type === 'date-separator') {
      return (
        <View style={styles.dateSeparator}>
          <View style={styles.dateLine} />
          <Text style={styles.dateLabel}>{item.date}</Text>
          <View style={styles.dateLine} />
        </View>
      );
    }
    const msg = item as Message;
    return (
      <View style={[styles.messageRow, msg.isMine ? styles.userRow : styles.craftsmanRow]}>
        {!msg.isMine && peer && (
          <Image source={{ uri: peer.image }} style={styles.msgAvatar} contentFit="cover" />
        )}
        <View style={[styles.bubble, msg.isMine ? styles.userBubble : styles.craftsmanBubble]}>
          {msg.messageType === 'image' && msg.imageUrl ? (
            <Image source={{ uri: msg.imageUrl }} style={styles.msgImage} contentFit="cover" />
          ) : (
            <Text style={[styles.bubbleText, msg.isMine ? styles.userText : styles.craftsmanText]}>
              {msg.content}
            </Text>
          )}
          <View style={styles.msgMeta}>
            {msg.isMine && (
              <MaterialIcons
                name={msg.isRead ? 'done-all' : 'check'}
                size={12}
                color={msg.isRead ? Colors.info : 'rgba(13,27,62,0.5)'}
              />
            )}
            <Text style={[styles.msgTime, msg.isMine ? styles.userTime : styles.craftsmanTime]}>
              {formatTime(msg.createdAt)}
            </Text>
          </View>
        </View>
      </View>
    );
  };

  // ── Guest ──────────────────────────────────────────────────────────────
  if (!user) {
    return (
      <View style={[styles.container, styles.centered, { paddingTop: insets.top }]}>
        <StatusBar style="light" />
        <MaterialIcons name="lock" size={52} color={Colors.textMuted} />
        <Text style={styles.emptyTitle}>تسجيل الدخول مطلوب</Text>
        <Pressable style={styles.loginBtn} onPress={() => router.push('/auth/login')}>
          <Text style={styles.loginBtnText}>تسجيل الدخول</Text>
        </Pressable>
      </View>
    );
  }

  const peerName = peer?.name?.split(' ').slice(0, 2).join(' ') ?? '...';

  return (
    <KeyboardAvoidingView
      style={{ flex: 1 }}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      keyboardVerticalOffset={0}
    >
      <View style={[styles.container, { paddingTop: insets.top }]}>
        <StatusBar style="light" />

        {/* ── Header ── */}
        <View style={styles.header}>
          <View style={styles.headerActions}>
            {peer?.phone ? (
              <Pressable
                style={styles.headerBtn}
                onPress={() => Linking.openURL(`tel:${peer.phone}`)}
              >
                <MaterialIcons name="call" size={20} color={Colors.gold} />
              </Pressable>
            ) : null}
            <Pressable
              style={styles.headerBtn}
              onPress={() => craftsmanId && router.push(`/craftsmen/${craftsmanId}` as any)}
            >
              <MaterialIcons name="person" size={20} color={Colors.gold} />
            </Pressable>
          </View>

          <Pressable
            style={styles.headerInfo}
            onPress={() => craftsmanId && router.push(`/craftsmen/${craftsmanId}` as any)}
          >
            {peer ? (
              <>
                <View style={styles.headerTextBlock}>
                  <Text style={styles.craftsmanName} numberOfLines={1}>{peerName}</Text>
                  <Text style={[styles.onlineStatus, { color: peer.available ? Colors.success : Colors.textMuted }]}>
                    {peer.available ? 'متاح الآن' : 'غير متاح'}
                  </Text>
                </View>
                <View style={styles.avatarWrapper}>
                  <Image source={{ uri: peer.image }} style={styles.headerAvatar} contentFit="cover" />
                  <View style={[styles.onlineDot, { backgroundColor: peer.available ? Colors.success : Colors.textMuted }]} />
                </View>
              </>
            ) : (
              <View style={styles.headerSkeleton} />
            )}
          </Pressable>

          <Pressable style={styles.backBtn} onPress={() => router.back()}>
            <MaterialIcons name="arrow-forward" size={22} color={Colors.text} />
          </Pressable>
        </View>

        {/* ── Messages ── */}
        {loading ? (
          <View style={styles.centered}>
            <ActivityIndicator size="large" color={Colors.gold} />
            <Text style={styles.loadingText}>جاري تحميل المحادثة...</Text>
          </View>
        ) : messages.length === 0 ? (
          <View style={styles.emptyChatContainer}>
            <View style={styles.emptyChatIcon}>
              <MaterialIcons name="chat-bubble-outline" size={48} color={Colors.textMuted} />
            </View>
            <Text style={styles.emptyTitle}>ابدأ المحادثة</Text>
            <Text style={styles.emptyText}>
              {peer ? `تحدث مع ${peer.name.split(' ')[0]} مباشرةً` : 'أرسل رسالة لبدء المحادثة'}
            </Text>
            <View style={styles.quickReplies}>
              {['مرحباً، هل أنت متاح؟', 'كم تكلفة الخدمة؟', 'متى يمكنك الحضور؟'].map((qr, i) => (
                <Pressable key={i} style={styles.quickReply} onPress={() => setInput(qr)}>
                  <Text style={styles.quickReplyText}>{qr}</Text>
                </Pressable>
              ))}
            </View>
          </View>
        ) : (
          <FlatList
            ref={listRef}
            data={listData}
            keyExtractor={item => ('id' in item ? item.id : item.key)}
            renderItem={renderItem}
            contentContainerStyle={styles.messagesList}
            showsVerticalScrollIndicator={false}
            onContentSizeChange={() => {
              if (messages.length > 0) listRef.current?.scrollToEnd({ animated: false });
            }}
          />
        )}

        {/* ── Input ── */}
        <View style={[styles.inputArea, { paddingBottom: insets.bottom + Spacing.sm }]}>
          <View style={styles.attachActions}>
            <Pressable style={styles.attachBtn} onPress={() => handleImagePick('camera')}>
              <MaterialIcons name="photo-camera" size={22} color={Colors.gold} />
            </Pressable>
            <Pressable style={styles.attachBtn} onPress={() => handleImagePick('gallery')}>
              <MaterialIcons name="photo-library" size={22} color={Colors.textMuted} />
            </Pressable>
          </View>
          <TextInput
            style={styles.input}
            value={input}
            onChangeText={setInput}
            placeholder="اكتب رسالة..."
            placeholderTextColor={Colors.textMuted}
            textAlign="right"
            multiline
            maxLength={1000}
            onSubmitEditing={Platform.OS === 'web' ? sendMessage : undefined}
          />
          <Pressable
            style={[styles.sendBtn, (!input.trim() || sending) && styles.sendBtnDisabled]}
            onPress={sendMessage}
            disabled={!input.trim() || sending}
          >
            {sending
              ? <ActivityIndicator size="small" color={Colors.textMuted} />
              : <MaterialIcons name="send" size={20} color={input.trim() ? Colors.primary : Colors.textMuted} />
            }
          </Pressable>
        </View>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  centered: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: Spacing.md },
  loadingText: { color: Colors.textMuted, fontSize: FontSize.base },

  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: Spacing.md, paddingVertical: Spacing.sm,
    backgroundColor: Colors.surface, borderBottomWidth: 1, borderBottomColor: Colors.divider,
    gap: Spacing.sm,
  },
  backBtn: {
    width: 40, height: 40, borderRadius: 20,
    backgroundColor: Colors.primarySurface, alignItems: 'center', justifyContent: 'center',
    flexShrink: 0,
  },
  headerInfo: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.sm,
    flex: 1, justifyContent: 'flex-end',
  },
  headerTextBlock: { alignItems: 'flex-end', gap: 2 },
  avatarWrapper: { position: 'relative' },
  headerAvatar: { width: 44, height: 44, borderRadius: 22, borderWidth: 2, borderColor: Colors.gold },
  onlineDot: { position: 'absolute', bottom: 1, right: 1, width: 12, height: 12, borderRadius: 6, borderWidth: 2, borderColor: Colors.surface },
  craftsmanName: { fontSize: FontSize.base, fontWeight: FontWeight.bold, color: Colors.text, textAlign: 'right', maxWidth: 140 },
  onlineStatus: { fontSize: FontSize.xs, textAlign: 'right' },
  headerActions: { flexDirection: 'row', gap: Spacing.xs, flexShrink: 0 },
  headerBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: Colors.primarySurface, alignItems: 'center', justifyContent: 'center' },
  headerSkeleton: { width: 120, height: 40, borderRadius: Radius.md, backgroundColor: Colors.surface2 },

  messagesList: { padding: Spacing.md, gap: Spacing.xs, paddingBottom: Spacing.lg },

  dateSeparator: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, marginVertical: Spacing.md },
  dateLine: { flex: 1, height: 1, backgroundColor: Colors.divider },
  dateLabel: { fontSize: FontSize.xs, color: Colors.textMuted, backgroundColor: Colors.surface, paddingHorizontal: 10, paddingVertical: 3, borderRadius: Radius.full, borderWidth: 1, borderColor: Colors.border },

  messageRow: { flexDirection: 'row', alignItems: 'flex-end', gap: Spacing.sm, marginBottom: Spacing.xs },
  userRow: { flexDirection: 'row-reverse' },
  craftsmanRow: {},
  msgAvatar: { width: 30, height: 30, borderRadius: 15, flexShrink: 0 },
  bubble: { maxWidth: '75%', borderRadius: Radius.xl, paddingHorizontal: 14, paddingVertical: 9, gap: 3 },
  userBubble: { backgroundColor: Colors.gold, borderBottomRightRadius: 4 },
  craftsmanBubble: { backgroundColor: Colors.surface, borderWidth: 1, borderColor: Colors.border, borderBottomLeftRadius: 4 },
  bubbleText: { fontSize: FontSize.base, lineHeight: 22 },
  userText: { color: Colors.primary },
  craftsmanText: { color: Colors.text },
  msgMeta: { flexDirection: 'row', alignItems: 'center', gap: 3, justifyContent: 'flex-end' },
  msgImage: { width: 200, height: 150, borderRadius: Radius.md },
  msgTime: { fontSize: 10 },
  userTime: { color: 'rgba(13,27,62,0.55)', textAlign: 'left' },
  craftsmanTime: { color: Colors.textMuted, textAlign: 'right' },

  emptyChatContainer: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: Spacing.xl, gap: Spacing.md },
  emptyChatIcon: { width: 90, height: 90, borderRadius: 45, backgroundColor: Colors.surface, borderWidth: 1, borderColor: Colors.border, alignItems: 'center', justifyContent: 'center' },
  emptyTitle: { fontSize: FontSize.xl, fontWeight: FontWeight.bold, color: Colors.text },
  emptyText: { fontSize: FontSize.sm, color: Colors.textMuted, textAlign: 'center', lineHeight: 22 },
  quickReplies: { gap: Spacing.sm, width: '100%', marginTop: Spacing.sm },
  quickReply: { backgroundColor: Colors.surface, borderRadius: Radius.lg, borderWidth: 1, borderColor: Colors.glassBorder, paddingVertical: 11, paddingHorizontal: Spacing.md, alignItems: 'center' },
  quickReplyText: { fontSize: FontSize.sm, color: Colors.gold, fontWeight: FontWeight.medium },

  loginBtn: { backgroundColor: Colors.gold, borderRadius: Radius.lg, paddingVertical: 13, paddingHorizontal: Spacing.xl },
  loginBtnText: { color: Colors.primary, fontWeight: FontWeight.bold, fontSize: FontSize.base },

  inputArea: {
    flexDirection: 'row', alignItems: 'flex-end', gap: Spacing.sm,
    paddingHorizontal: Spacing.md, paddingTop: Spacing.sm,
    backgroundColor: Colors.surface, borderTopWidth: 1, borderTopColor: Colors.divider,
  },
  attachActions: { flexDirection: 'row', gap: 2, paddingBottom: 2 },
  attachBtn: { width: 36, height: 36, borderRadius: 18, alignItems: 'center', justifyContent: 'center' },
  input: {
    flex: 1, backgroundColor: Colors.primarySurface,
    borderRadius: Radius.xl, paddingHorizontal: Spacing.md,
    paddingVertical: 10, color: Colors.text, fontSize: FontSize.base,
    maxHeight: 100, borderWidth: 1, borderColor: Colors.border, minHeight: 42,
  },
  sendBtn: { width: 42, height: 42, borderRadius: 21, backgroundColor: Colors.gold, alignItems: 'center', justifyContent: 'center', flexShrink: 0 },
  sendBtnDisabled: { backgroundColor: Colors.surface },
});
