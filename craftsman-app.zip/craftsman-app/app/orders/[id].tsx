import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  View, Text, StyleSheet, ScrollView, Pressable, ActivityIndicator, Linking,
} from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import * as Location from 'expo-location';
import { MapViewComponent, Marker, PROVIDER_DEFAULT } from '@/components/MapWrapper';
import type { Region } from '@/components/MapWrapper';
import { Colors, FontSize, FontWeight, Radius, Spacing, Shadow } from '@/constants/theme';
import { getSupabaseClient, useAuth } from '@/template';

interface OrderDetail {
  id: string;
  serviceType: string;
  description: string;
  status: string;
  price: string;
  address: string;
  scheduledAt: string | null;
  createdAt: string;
  craftsmanId: string | null;
  craftsmanName: string;
  craftsmanImage: string;
}

interface CraftsmanInfo {
  id: string;
  name: string;
  specialty: string;
  phone: string;
  image: string;
  rating: number;
  city: string;
}

const STATUS_CONFIG: Record<string, { color: string; label: string; icon: string; bg: string; step: number }> = {
  pending:     { color: Colors.warning,  label: 'قيد الانتظار',        icon: 'hourglass-empty',      bg: 'rgba(243,156,18,0.12)',  step: 0 },
  assigned:    { color: Colors.gold,     label: 'تم التعيين تلقائياً', icon: 'auto-fix-high',        bg: 'rgba(212,160,23,0.12)', step: 1 },
  accepted:    { color: Colors.info,     label: 'تم القبول',           icon: 'check-circle-outline', bg: 'rgba(52,152,219,0.12)', step: 1 },
  on_the_way:  { color: '#9B59B6',       label: 'الحرفي في الطريق',   icon: 'directions-car',       bg: 'rgba(155,89,182,0.12)', step: 2 },
  in_progress: { color: Colors.info,     label: 'جاري التنفيذ',        icon: 'engineering',          bg: 'rgba(52,152,219,0.12)', step: 2 },
  completed:   { color: Colors.success,  label: 'مكتمل',               icon: 'check-circle',         bg: 'rgba(46,204,113,0.12)', step: 3 },
  cancelled:   { color: Colors.error,    label: 'ملغي',                icon: 'cancel',               bg: 'rgba(231,76,60,0.12)',  step: -1 },
};

const TIMELINE_STEPS = [
  { key: 'pending',     label: 'تم إرسال الطلب',    icon: 'send',                 sub: 'تم استلام طلبك بنجاح' },
  { key: 'accepted',   label: 'تم قبول الطلب',      icon: 'check-circle-outline', sub: 'قبل الحرفي طلبك' },
  { key: 'on_the_way', label: 'الحرفي في الطريق',   icon: 'directions-car',       sub: 'يتجه الحرفي نحوك' },
  { key: 'completed',  label: 'اكتملت الخدمة',      icon: 'check-circle',         sub: 'تم إنجاز الطلب بنجاح' },
];

const DEFAULT_LAT = 24.7136;
const DEFAULT_LNG = 46.6753;

function getSimulatedCraftsmanCoord(lat: number, lng: number) {
  const angle = Math.random() * Math.PI * 2;
  const dist = 0.015 + Math.random() * 0.025;
  return { latitude: lat + Math.cos(angle) * dist, longitude: lng + Math.sin(angle) * dist };
}

export default function OrderDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const supabase = getSupabaseClient();
  const mapRef = useRef<any>(null);

  const [order, setOrder] = useState<OrderDetail | null>(null);
  const [craftsman, setCraftsman] = useState<CraftsmanInfo | null>(null);
  const [loading, setLoading] = useState(true);

  const [clientCoord, setClientCoord] = useState({ latitude: DEFAULT_LAT, longitude: DEFAULT_LNG });
  const [craftsmanCoord, setCraftsmanCoord] = useState<{ latitude: number; longitude: number } | null>(null);
  const [mapRegion, setMapRegion] = useState<Region>({
    latitude: DEFAULT_LAT, longitude: DEFAULT_LNG,
    latitudeDelta: 0.07, longitudeDelta: 0.07,
  });
  const [locationLoading, setLocationLoading] = useState(false);
  const [etaMinutes] = useState(Math.floor(Math.random() * 12) + 8);
  const [etaKm] = useState((Math.random() * 3 + 1).toFixed(1));

  const fetchOrder = useCallback(async () => {
    if (!id) return;
    const { data, error } = await supabase.from('orders').select('*').eq('id', id).single();
    if (!error && data) {
      const o: OrderDetail = {
        id: data.id,
        serviceType: data.service_type,
        description: data.description ?? '',
        status: data.status ?? 'pending',
        price: data.price ?? 'سيتم التحديد',
        address: data.address ?? '',
        scheduledAt: data.scheduled_at,
        createdAt: data.created_at,
        craftsmanId: data.craftsman_id ?? null,
        craftsmanName: data.craftsman_name ?? 'قيد التعيين',
        craftsmanImage: data.craftsman_image ?? 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400',
      };
      setOrder(o);

      if (data.craftsman_id) {
        const { data: cd } = await supabase
          .from('craftsmen')
          .select('id, name, specialty, phone, image_url, rating, city')
          .eq('id', data.craftsman_id)
          .single();
        if (cd) {
          setCraftsman({
            id: cd.id, name: cd.name, specialty: cd.specialty,
            phone: cd.phone ?? '', rating: cd.rating ?? 0,
            image: cd.image_url ?? 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400',
            city: cd.city ?? 'الرياض',
          });
        }
      }
    }
    setLoading(false);
  }, [id]);

  const initLocation = useCallback(async () => {
    setLocationLoading(true);
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      let lat = DEFAULT_LAT, lng = DEFAULT_LNG;
      if (status === 'granted') {
        const pos = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
        lat = pos.coords.latitude;
        lng = pos.coords.longitude;
      }
      setClientCoord({ latitude: lat, longitude: lng });
      const cr = getSimulatedCraftsmanCoord(lat, lng);
      setCraftsmanCoord(cr);
      const midLat = (lat + cr.latitude) / 2;
      const midLng = (lng + cr.longitude) / 2;
      const dLat = Math.max(Math.abs(lat - cr.latitude) * 2.2, 0.025);
      const dLng = Math.max(Math.abs(lng - cr.longitude) * 2.2, 0.025);
      const region: Region = { latitude: midLat, longitude: midLng, latitudeDelta: dLat, longitudeDelta: dLng };
      setMapRegion(region);
      setTimeout(() => mapRef.current?.animateToRegion?.(region, 800), 400);
    } catch {
      setCraftsmanCoord(getSimulatedCraftsmanCoord(DEFAULT_LAT, DEFAULT_LNG));
    } finally {
      setLocationLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchOrder();
    initLocation();
    const interval = setInterval(fetchOrder, 15000);
    return () => clearInterval(interval);
  }, [fetchOrder, initLocation]);

  if (loading) {
    return (
      <View style={[styles.container, styles.centered, { paddingTop: insets.top }]}>
        <StatusBar style="light" />
        <ActivityIndicator size="large" color={Colors.gold} />
        <Text style={styles.loadingText}>جاري تحميل تفاصيل الطلب...</Text>
      </View>
    );
  }

  if (!order) {
    return (
      <View style={[styles.container, styles.centered, { paddingTop: insets.top }]}>
        <StatusBar style="light" />
        <MaterialIcons name="error-outline" size={52} color={Colors.textMuted} />
        <Text style={styles.emptyTitle}>لم يتم العثور على الطلب</Text>
        <Pressable style={styles.backBigBtn} onPress={() => router.back()}>
          <Text style={styles.backBigBtnText}>العودة</Text>
        </Pressable>
      </View>
    );
  }

  const sc = STATUS_CONFIG[order.status] ?? STATUS_CONFIG.pending;
  const currentStep = sc.step;
  const showMap = ['pending', 'assigned', 'accepted', 'on_the_way', 'in_progress'].includes(order.status);

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <StatusBar style="light" />

      <View style={styles.header}>
        <View style={[styles.statusBadgeHeader, { backgroundColor: sc.bg }]}>
          <MaterialIcons name={sc.icon as any} size={14} color={sc.color} />
          <Text style={[styles.statusTextHeader, { color: sc.color }]}>{sc.label}</Text>
        </View>
        <Text style={styles.headerTitle}>تتبع الطلب</Text>
        <Pressable style={styles.backBtn} onPress={() => router.back()}>
          <MaterialIcons name="arrow-forward" size={22} color={Colors.text} />
        </Pressable>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: insets.bottom + 32 }}>

        {showMap && (
          <View style={styles.mapSection}>
            <View style={styles.mapHeaderRow}>
              <View style={styles.mapLiveBadge}>
                <View style={styles.livePulse} />
                <Text style={styles.liveText}>تتبع مباشر</Text>
              </View>
              <Text style={styles.mapTitle}>خريطة التتبع</Text>
            </View>

            <View style={styles.mapContainer}>
              {locationLoading && (
                <View style={styles.mapLoadingOverlay}>
                  <ActivityIndicator color={Colors.gold} size="large" />
                  <Text style={styles.mapLoadingText}>جاري تحديد الموقع...</Text>
                </View>
              )}
              <MapViewComponent
                ref={mapRef}
                style={styles.map}
                provider={PROVIDER_DEFAULT}
                initialRegion={mapRegion}
                region={mapRegion}
                onRegionChangeComplete={setMapRegion}
                showsUserLocation={false}
              >
                <Marker coordinate={clientCoord} title="موقعك" pinColor={Colors.info} />
                {craftsmanCoord && (
                  <Marker coordinate={craftsmanCoord} title={craftsman?.name ?? 'الحرفي'} pinColor={Colors.gold} />
                )}
              </MapViewComponent>

              <View style={styles.mapLegend}>
                {craftsman && (
                  <View style={styles.legendItem}>
                    <View style={[styles.legendDot, { backgroundColor: Colors.gold }]} />
                    <Text style={styles.legendText}>{craftsman.name.split(' ')[0]}</Text>
                  </View>
                )}
                <View style={styles.legendItem}>
                  <View style={[styles.legendDot, { backgroundColor: Colors.info }]} />
                  <Text style={styles.legendText}>موقعك</Text>
                </View>
              </View>

              <Pressable style={styles.recenterBtn} onPress={() => mapRef.current?.animateToRegion?.(mapRegion, 500)}>
                <MaterialIcons name="my-location" size={20} color={Colors.gold} />
              </Pressable>
            </View>

            <View style={styles.etaCard}>
              <View style={styles.etaItem}>
                <MaterialIcons name="directions-car" size={22} color={Colors.gold} />
                <Text style={styles.etaValue}>~{etaMinutes} دقيقة</Text>
                <Text style={styles.etaLabel}>وقت الوصال</Text>
              </View>
              <View style={styles.etaDivider} />
              <View style={styles.etaItem}>
                <MaterialIcons name="straighten" size={22} color={Colors.gold} />
                <Text style={styles.etaValue}>{etaKm} كم</Text>
                <Text style={styles.etaLabel}>المسافة</Text>
              </View>
              <View style={styles.etaDivider} />
              <View style={styles.etaItem}>
                <MaterialIcons name={sc.icon as any} size={22} color={sc.color} />
                <Text style={[styles.etaValue, { color: sc.color }]}>{sc.label}</Text>
                <Text style={styles.etaLabel}>الحالة</Text>
              </View>
            </View>
          </View>
        )}

        {/* Timeline */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>مراحل الطلب</Text>
          <View style={styles.timelineCard}>
            {TIMELINE_STEPS.map((ts, i) => {
              const isDone = i <= currentStep;
              const isCurrent = i === currentStep;
              const isUpcoming = i > currentStep;
              return (
                <View key={ts.key} style={[styles.timelineStep, i === TIMELINE_STEPS.length - 1 && styles.timelineStepLast]}>
                  <View style={styles.timelineTrack}>
                    <View style={[
                      styles.timelineDot,
                      isDone && !isCurrent && styles.timelineDotDone,
                      isCurrent && styles.timelineDotCurrent,
                      isUpcoming && styles.timelineDotUpcoming,
                    ]}>
                      {isDone && !isCurrent
                        ? <MaterialIcons name="check" size={14} color={Colors.primary} />
                        : isCurrent
                        ? <MaterialIcons name={ts.icon as any} size={14} color={Colors.text} />
                        : <Text style={styles.timelineNum}>{i + 1}</Text>
                      }
                    </View>
                    {i < TIMELINE_STEPS.length - 1 && (
                      <View style={[styles.timelineConnector, isDone && i < currentStep && styles.timelineConnectorDone]} />
                    )}
                  </View>
                  <View style={styles.timelineContent}>
                    <Text style={[
                      styles.timelineLabel,
                      isDone && styles.timelineLabelDone,
                      isCurrent && styles.timelineLabelCurrent,
                      isUpcoming && styles.timelineLabelUpcoming,
                    ]}>{ts.label}</Text>
                    <Text style={[styles.timelineSub, isCurrent && { color: Colors.info }]}>
                      {isCurrent ? 'الحالة الحالية' : isDone ? ts.sub : 'قادماً...'}
                    </Text>
                  </View>
                  {isCurrent && (
                    <View style={styles.currentPill}>
                      <Text style={styles.currentPillText}>الآن</Text>
                    </View>
                  )}
                </View>
              );
            })}
          </View>
        </View>

        {/* Craftsman Card */}
        {craftsman ? (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>الحرفي المعيّن</Text>
            <View style={styles.craftsmanCard}>
              <View style={styles.craftsmanRow}>
                <Image source={{ uri: craftsman.image }} style={styles.craftsmanImg} contentFit="cover" />
                <View style={styles.craftsmanInfo}>
                  <Text style={styles.craftsmanName}>{craftsman.name}</Text>
                  <Text style={styles.craftsmanSpec}>{craftsman.specialty}</Text>
                  <View style={styles.craftsmanMeta}>
                    <View style={styles.metaChip}>
                      <MaterialIcons name="star" size={12} color={Colors.gold} />
                      <Text style={styles.metaText}>{craftsman.rating.toFixed(1)}</Text>
                    </View>
                    <View style={styles.metaChip}>
                      <MaterialIcons name="location-on" size={12} color={Colors.textMuted} />
                      <Text style={styles.metaText}>{craftsman.city}</Text>
                    </View>
                  </View>
                </View>
              </View>

              <View style={styles.craftsmanActions}>
                <Pressable
                  style={styles.chatBtn}
                  onPress={() => router.push(`/chat/${craftsman.id}?orderId=${order.id}` as any)}
                >
                  <MaterialIcons name="chat" size={17} color={Colors.primary} />
                  <Text style={styles.chatBtnText}>مراسلة</Text>
                </Pressable>
                {craftsman.phone ? (
                  <Pressable
                    style={styles.callBtn}
                    onPress={() => Linking.openURL(`tel:${craftsman.phone}`)}
                  >
                    <MaterialIcons name="call" size={17} color={Colors.info} />
                    <Text style={styles.callBtnText}>اتصال</Text>
                  </Pressable>
                ) : null}
                <Pressable
                  style={styles.profileBtn}
                  onPress={() => router.push(`/craftsmen/${craftsman.id}` as any)}
                >
                  <MaterialIcons name="person" size={17} color={Colors.gold} />
                  <Text style={styles.profileBtnText}>الملف</Text>
                </Pressable>
              </View>
            </View>
          </View>
        ) : (
          <View style={styles.section}>
            <View style={styles.noCraftsmanCard}>
              <ActivityIndicator color={Colors.gold} size="small" />
              <Text style={styles.noCraftsmanText}>يتم البحث عن أقرب حرفي متاح...</Text>
            </View>
          </View>
        )}

        {/* Order Details */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>تفاصيل الطلب</Text>
          <View style={styles.detailsCard}>
            {[
              { icon: 'home-repair-service', label: 'الخدمة',    value: order.serviceType },
              { icon: 'location-on',         label: 'الموقع',    value: order.address || 'غير محدد' },
              { icon: 'attach-money',        label: 'السعر',     value: order.price },
              {
                icon: 'event', label: 'الموعد',
                value: order.scheduledAt
                  ? new Date(order.scheduledAt).toLocaleDateString('ar-SA', { day: 'numeric', month: 'long' })
                  : 'فوري',
              },
              {
                icon: 'calendar-today', label: 'تاريخ الطلب',
                value: new Date(order.createdAt).toLocaleDateString('ar-SA', { day: 'numeric', month: 'long', year: 'numeric' }),
              },
            ].map((d, i) => (
              <View key={i} style={[styles.detailRow, i > 0 && styles.detailRowBorder]}>
                <Text style={styles.detailValue}>{d.value}</Text>
                <View style={styles.detailLabel}>
                  <Text style={styles.detailLabelText}>{d.label}</Text>
                  <MaterialIcons name={d.icon as any} size={16} color={Colors.gold} />
                </View>
              </View>
            ))}
            {order.description ? (
              <View style={[styles.detailRow, styles.detailRowBorder]}>
                <Text style={[styles.detailValue, { textAlign: 'right', lineHeight: 22 }]}>{order.description}</Text>
                <View style={styles.detailLabel}>
                  <Text style={styles.detailLabelText}>الوصف</Text>
                  <MaterialIcons name="description" size={16} color={Colors.gold} />
                </View>
              </View>
            ) : null}
          </View>
        </View>

        {(order.status === 'pending' || order.status === 'assigned') && (
          <View style={styles.section}>
            {order.status === 'assigned' && (
              <View style={styles.assignedInfoCard}>
                <MaterialIcons name="auto-fix-high" size={18} color={Colors.gold} />
                <Text style={styles.assignedInfoText}>
                  تم تعيين الحرفي تلقائياً بناءً على موقعك وتخصص الخدمة
                </Text>
              </View>
            )}
            <Pressable
              style={styles.cancelBtn}
              onPress={async () => {
                const { error } = await supabase
                  .from('orders')
                  .update({ status: 'cancelled', updated_at: new Date().toISOString() })
                  .eq('id', order.id);
                if (!error) {
                  setOrder(prev => prev ? { ...prev, status: 'cancelled' } : prev);
                  // Release craftsman busy status if assigned
                  if (order.craftsmanId) {
                    await supabase
                      .from('craftsmen')
                      .update({ is_busy: false })
                      .eq('id', order.craftsmanId);
                  }
                }
                router.back();
              }}
            >
              <MaterialIcons name="cancel" size={18} color={Colors.error} />
              <Text style={styles.cancelBtnText}>إلغاء الطلب</Text>
            </Pressable>
          </View>
        )}

        {order.status === 'completed' && (
          <View style={styles.section}>
            <Pressable
              style={styles.reviewBtn}
              onPress={() => craftsman && router.push(`/craftsmen/${craftsman.id}` as any)}
            >
              <MaterialIcons name="star" size={18} color={Colors.primary} />
              <Text style={styles.reviewBtnText}>تقييم الحرفي</Text>
            </Pressable>
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  centered: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: Spacing.md },
  loadingText: { color: Colors.textMuted, fontSize: FontSize.base },

  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: Spacing.md, paddingVertical: Spacing.md,
    borderBottomWidth: 1, borderBottomColor: Colors.divider,
  },
  headerTitle: { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: Colors.text },
  backBtn: { width: 40, height: 40, borderRadius: 20, backgroundColor: Colors.surface, alignItems: 'center', justifyContent: 'center' },
  statusBadgeHeader: { flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 10, paddingVertical: 6, borderRadius: Radius.full },
  statusTextHeader: { fontSize: FontSize.xs, fontWeight: FontWeight.bold },

  mapSection: { paddingHorizontal: Spacing.lg, paddingTop: Spacing.lg, gap: Spacing.md },
  mapHeaderRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  mapTitle: { fontSize: FontSize.base, fontWeight: FontWeight.bold, color: Colors.text },
  mapLiveBadge: { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: 'rgba(46,204,113,0.1)', borderRadius: Radius.full, paddingHorizontal: 11, paddingVertical: 5, borderWidth: 1, borderColor: 'rgba(46,204,113,0.3)' },
  livePulse: { width: 8, height: 8, borderRadius: 4, backgroundColor: Colors.success },
  liveText: { fontSize: FontSize.xs, color: Colors.success, fontWeight: FontWeight.bold },
  mapContainer: { height: 260, borderRadius: Radius.xl, overflow: 'hidden', borderWidth: 1, borderColor: Colors.border, position: 'relative', backgroundColor: Colors.surface },
  map: { flex: 1 },
  mapLoadingOverlay: { position: 'absolute', inset: 0, zIndex: 10, backgroundColor: 'rgba(13,27,62,0.75)', alignItems: 'center', justifyContent: 'center', gap: Spacing.sm },
  mapLoadingText: { color: Colors.text, fontSize: FontSize.sm },
  mapLegend: { position: 'absolute', bottom: 12, right: 12, backgroundColor: 'rgba(13,27,62,0.88)', borderRadius: Radius.md, paddingHorizontal: 10, paddingVertical: 8, gap: 6, borderWidth: 1, borderColor: Colors.glassBorder },
  legendItem: { flexDirection: 'row', alignItems: 'center', gap: 7 },
  legendDot: { width: 10, height: 10, borderRadius: 5 },
  legendText: { fontSize: 11, color: Colors.text, fontWeight: FontWeight.medium },
  recenterBtn: { position: 'absolute', bottom: 12, left: 12, width: 40, height: 40, borderRadius: 20, backgroundColor: 'rgba(13,27,62,0.88)', alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: Colors.glassBorder },

  etaCard: { flexDirection: 'row', backgroundColor: Colors.surface, borderRadius: Radius.xl, borderWidth: 1, borderColor: Colors.border, paddingVertical: Spacing.md, ...Shadow.sm },
  etaItem: { flex: 1, alignItems: 'center', gap: 5 },
  etaValue: { fontSize: FontSize.base, fontWeight: FontWeight.bold, color: Colors.text },
  etaLabel: { fontSize: 10, color: Colors.textMuted },
  etaDivider: { width: 1, backgroundColor: Colors.divider, marginVertical: 6 },

  section: { paddingHorizontal: Spacing.lg, paddingTop: Spacing.lg, gap: Spacing.sm },
  sectionTitle: { fontSize: FontSize.base, fontWeight: FontWeight.bold, color: Colors.text, textAlign: 'right' },

  timelineCard: { backgroundColor: Colors.surface, borderRadius: Radius.xl, borderWidth: 1, borderColor: Colors.border, padding: Spacing.md },
  timelineStep: { flexDirection: 'row', alignItems: 'flex-start', gap: Spacing.md, paddingBottom: Spacing.lg },
  timelineStepLast: { paddingBottom: 0 },
  timelineTrack: { alignItems: 'center', width: 32 },
  timelineDot: { width: 32, height: 32, borderRadius: 16, backgroundColor: Colors.surface2, borderWidth: 1.5, borderColor: Colors.border, alignItems: 'center', justifyContent: 'center', zIndex: 1 },
  timelineDotDone: { backgroundColor: Colors.success, borderColor: Colors.success },
  timelineDotCurrent: { backgroundColor: Colors.info, borderColor: Colors.info },
  timelineDotUpcoming: { backgroundColor: Colors.surface2, borderColor: Colors.divider },
  timelineNum: { fontSize: FontSize.xs, color: Colors.textMuted, fontWeight: FontWeight.bold },
  timelineConnector: { width: 2, flex: 1, backgroundColor: Colors.divider, marginVertical: 2, minHeight: Spacing.lg },
  timelineConnectorDone: { backgroundColor: Colors.success },
  timelineContent: { flex: 1, paddingTop: 5, gap: 3, alignItems: 'flex-end' },
  timelineLabel: { fontSize: FontSize.sm, color: Colors.textMuted, textAlign: 'right', fontWeight: FontWeight.medium },
  timelineLabelDone: { color: Colors.text, fontWeight: FontWeight.semibold },
  timelineLabelCurrent: { color: Colors.text, fontWeight: FontWeight.bold, fontSize: FontSize.base },
  timelineLabelUpcoming: { color: Colors.textMuted },
  timelineSub: { fontSize: FontSize.xs, color: Colors.textMuted, textAlign: 'right' },
  currentPill: { backgroundColor: Colors.info, borderRadius: Radius.full, paddingHorizontal: 8, paddingVertical: 3, alignSelf: 'center' },
  currentPillText: { fontSize: 10, color: Colors.text, fontWeight: FontWeight.bold },

  craftsmanCard: { backgroundColor: Colors.surface, borderRadius: Radius.xl, borderWidth: 1, borderColor: 'rgba(212,160,23,0.3)', overflow: 'hidden', ...Shadow.sm },
  craftsmanRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md, padding: Spacing.md },
  craftsmanImg: { width: 72, height: 72, borderRadius: 36, borderWidth: 2.5, borderColor: Colors.gold },
  craftsmanInfo: { flex: 1, alignItems: 'flex-end', gap: 5 },
  craftsmanName: { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: Colors.text, textAlign: 'right' },
  craftsmanSpec: { fontSize: FontSize.sm, color: Colors.gold, textAlign: 'right' },
  craftsmanMeta: { flexDirection: 'row', gap: Spacing.sm },
  metaChip: { flexDirection: 'row', alignItems: 'center', gap: 3, backgroundColor: Colors.surface2, borderRadius: Radius.full, paddingHorizontal: 8, paddingVertical: 3 },
  metaText: { fontSize: FontSize.xs, color: Colors.textMuted },
  craftsmanActions: { flexDirection: 'row', gap: Spacing.sm, padding: Spacing.md, borderTopWidth: 1, borderTopColor: Colors.divider },
  chatBtn: { flex: 1.5, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 5, backgroundColor: Colors.gold, borderRadius: Radius.md, paddingVertical: 11, ...Shadow.gold },
  chatBtnText: { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: Colors.primary },
  callBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 5, backgroundColor: 'rgba(52,152,219,0.1)', borderRadius: Radius.md, paddingVertical: 11, borderWidth: 1, borderColor: 'rgba(52,152,219,0.3)' },
  callBtnText: { fontSize: FontSize.sm, fontWeight: FontWeight.medium, color: Colors.info },
  profileBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 5, backgroundColor: Colors.goldSoft, borderRadius: Radius.md, paddingVertical: 11, borderWidth: 1, borderColor: 'rgba(212,160,23,0.25)' },
  profileBtnText: { fontSize: FontSize.sm, fontWeight: FontWeight.medium, color: Colors.gold },

  noCraftsmanCard: { backgroundColor: Colors.surface, borderRadius: Radius.xl, borderWidth: 1, borderColor: Colors.border, padding: Spacing.xl, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: Spacing.md },
  noCraftsmanText: { fontSize: FontSize.sm, color: Colors.textMuted },

  detailsCard: { backgroundColor: Colors.surface, borderRadius: Radius.xl, borderWidth: 1, borderColor: Colors.border, overflow: 'hidden' },
  detailRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: Spacing.md, paddingVertical: 13, gap: Spacing.md },
  detailRowBorder: { borderTopWidth: 1, borderTopColor: Colors.divider },
  detailLabel: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, minWidth: 80 },
  detailLabelText: { fontSize: FontSize.sm, color: Colors.textMuted },
  detailValue: { fontSize: FontSize.sm, color: Colors.text, fontWeight: FontWeight.semibold, flex: 1, textAlign: 'right' },

  assignedInfoCard: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, backgroundColor: 'rgba(212,160,23,0.08)', borderRadius: Radius.lg, padding: Spacing.md, borderWidth: 1, borderColor: 'rgba(212,160,23,0.3)' },
  assignedInfoText: { flex: 1, fontSize: FontSize.sm, color: Colors.text, textAlign: 'right', lineHeight: 20 },
  cancelBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: Spacing.sm, borderRadius: Radius.lg, paddingVertical: 14, backgroundColor: 'rgba(231,76,60,0.08)', borderWidth: 1, borderColor: Colors.error },
  cancelBtnText: { fontSize: FontSize.base, fontWeight: FontWeight.bold, color: Colors.error },
  reviewBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: Spacing.sm, backgroundColor: Colors.gold, borderRadius: Radius.lg, paddingVertical: 14, ...Shadow.gold },
  reviewBtnText: { fontSize: FontSize.base, fontWeight: FontWeight.bold, color: Colors.primary },

  emptyTitle: { fontSize: FontSize.xl, fontWeight: FontWeight.bold, color: Colors.text },
  backBigBtn: { backgroundColor: Colors.gold, borderRadius: Radius.lg, paddingVertical: 13, paddingHorizontal: Spacing.xl },
  backBigBtnText: { color: Colors.primary, fontWeight: FontWeight.bold },
});
