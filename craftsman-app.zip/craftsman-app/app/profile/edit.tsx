import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, ScrollView, Pressable, TextInput,
  KeyboardAvoidingView, Platform, ActivityIndicator, Alert,
} from 'react-native';
import { useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import * as ImagePicker from 'expo-image-picker';
import { Colors, FontSize, FontWeight, Radius, Spacing, Shadow } from '@/constants/theme';
import { getSupabaseClient, useAuth, useAlert } from '@/template';

export default function EditProfileScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const { showAlert } = useAlert();
  const supabase = getSupabaseClient();

  const [username, setUsername] = useState('');
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);
  const [photoUri, setPhotoUri] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [uploadingPhoto, setUploadingPhoto] = useState(false);

  useEffect(() => {
    const fetch = async () => {
      if (!user) return;
      const { data } = await supabase
        .from('user_profiles')
        .select('username, avatar_url')
        .eq('id', user.id)
        .single();
      if (data) {
        setUsername(data.username ?? '');
        setAvatarUrl(data.avatar_url ?? null);
      }
      setLoading(false);
    };
    fetch();
  }, [user]);

  const pickPhoto = async (source: 'camera' | 'gallery') => {
    let result: ImagePicker.ImagePickerResult;
    if (source === 'camera') {
      const { status } = await ImagePicker.requestCameraPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('الكاميرا', 'يرجى السماح للتطبيق باستخدام الكاميرا');
        return;
      }
      result = await ImagePicker.launchCameraAsync({
        mediaTypes: 'images', quality: 0.75, allowsEditing: true, aspect: [1, 1],
      });
    } else {
      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('المعرض', 'يرجى السماح للتطبيق بالوصول إلى المعرض');
        return;
      }
      result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: 'images', quality: 0.75, allowsEditing: true, aspect: [1, 1],
      });
    }
    if (result.canceled || !result.assets?.[0]) return;
    setPhotoUri(result.assets[0].uri);
  };

  const showPhotoOptions = () => {
    Alert.alert('تغيير الصورة', 'اختر المصدر', [
      { text: 'الكاميرا', onPress: () => pickPhoto('camera') },
      { text: 'المعرض', onPress: () => pickPhoto('gallery') },
      { text: 'إلغاء', style: 'cancel' },
    ]);
  };

  const uploadPhoto = async (): Promise<string | null> => {
    if (!photoUri || !user) return avatarUrl;
    setUploadingPhoto(true);
    try {
      const ext = photoUri.split('.').pop() ?? 'jpg';
      const fileName = `avatars/${user.id}.${ext}`;
      const response = await fetch(photoUri);
      const blob = await response.blob();
      const arrayBuffer = await new Response(blob).arrayBuffer();
      const { error: uploadError } = await supabase.storage
        .from('profile-images')
        .upload(fileName, arrayBuffer, { contentType: `image/${ext}`, upsert: true });
      if (uploadError) return avatarUrl;
      const { data: { publicUrl } } = supabase.storage
        .from('profile-images').getPublicUrl(fileName);
      return `${publicUrl}?t=${Date.now()}`;
    } catch {
      return avatarUrl;
    } finally {
      setUploadingPhoto(false);
    }
  };

  const handleSave = async () => {
    if (!user) return;
    if (!username.trim()) {
      showAlert('تنبيه', 'يرجى إدخال الاسم');
      return;
    }
    setSaving(true);
    const newAvatarUrl = await uploadPhoto();
    const { error } = await supabase
      .from('user_profiles')
      .update({ username: username.trim(), avatar_url: newAvatarUrl })
      .eq('id', user.id);
    setSaving(false);
    if (error) {
      showAlert('خطأ', 'لم يتم الحفظ، حاول مرة أخرى');
      return;
    }
    showAlert('تم الحفظ', 'تم تحديث ملفك الشخصي بنجاح', [
      { text: 'حسناً', onPress: () => router.back() },
    ]);
  };

  const displayAvatar = photoUri ?? avatarUrl ?? `https://ui-avatars.com/api/?name=${encodeURIComponent(username || 'User')}&background=D4A017&color=0D1B3E&size=200`;

  if (loading) {
    return (
      <View style={[styles.container, styles.centered, { paddingTop: insets.top }]}>
        <ActivityIndicator size="large" color={Colors.gold} />
      </View>
    );
  }

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <View style={[styles.container, { paddingTop: insets.top }]}>
        <StatusBar style="light" />

        <View style={styles.header}>
          <Pressable style={styles.saveBtn} onPress={handleSave} disabled={saving || uploadingPhoto}>
            {saving || uploadingPhoto ? (
              <ActivityIndicator size="small" color={Colors.primary} />
            ) : (
              <Text style={styles.saveBtnText}>حفظ</Text>
            )}
          </Pressable>
          <Text style={styles.headerTitle}>تعديل الملف الشخصي</Text>
          <Pressable style={styles.backBtn} onPress={() => router.back()}>
            <MaterialIcons name="arrow-forward" size={22} color={Colors.text} />
          </Pressable>
        </View>

        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: insets.bottom + 30 }}>
          {/* Avatar */}
          <View style={styles.avatarSection}>
            <Pressable style={styles.avatarWrapper} onPress={showPhotoOptions}>
              <Image source={{ uri: displayAvatar }} style={styles.avatar} contentFit="cover" transition={200} />
              <View style={styles.cameraOverlay}>
                <MaterialIcons name="photo-camera" size={18} color={Colors.text} />
              </View>
            </Pressable>
            <Pressable style={styles.changePhotoBtn} onPress={showPhotoOptions}>
              <MaterialIcons name="edit" size={14} color={Colors.gold} />
              <Text style={styles.changePhotoText}>تغيير الصورة الشخصية</Text>
            </Pressable>
            {photoUri && (
              <Text style={styles.photoSelected}>✓ تم اختيار صورة جديدة</Text>
            )}
          </View>

          {/* Form */}
          <View style={styles.form}>
            <Text style={styles.sectionTitle}>المعلومات الأساسية</Text>
            <View style={styles.formGroup}>
              <View style={styles.inputContainer}>
                <View style={styles.inputRow}>
                  <TextInput
                    style={styles.input}
                    value={username}
                    onChangeText={setUsername}
                    placeholder="اسمك الكامل"
                    placeholderTextColor={Colors.textMuted}
                    textAlign="right"
                    autoCapitalize="words"
                  />
                  <MaterialIcons name="person" size={20} color={Colors.textMuted} />
                </View>
                <Text style={styles.inputLabel}>الاسم</Text>
              </View>

              <View style={styles.inputContainer}>
                <View style={[styles.inputRow, styles.inputDisabled]}>
                  <Text style={styles.inputValueDisabled}>{user?.email}</Text>
                  <MaterialIcons name="email" size={20} color={Colors.textMuted} />
                </View>
                <Text style={styles.inputLabel}>البريد الإلكتروني (لا يمكن تغييره)</Text>
              </View>
            </View>

            <Text style={styles.sectionTitle}>الأمان</Text>
            <View style={styles.formGroup}>
              <Pressable style={styles.securityItem} onPress={() => showAlert('تغيير كلمة المرور', 'سيتم إرسال رابط تغيير كلمة المرور إلى بريدك الإلكتروني')}>
                <MaterialIcons name="chevron-left" size={22} color={Colors.textMuted} />
                <View style={styles.securityInfo}>
                  <Text style={styles.securityLabel}>تغيير كلمة المرور</Text>
                  <Text style={styles.securitySub}>عبر البريد الإلكتروني</Text>
                </View>
                <View style={styles.securityIcon}>
                  <MaterialIcons name="lock" size={20} color={Colors.gold} />
                </View>
              </Pressable>
            </View>
          </View>
        </ScrollView>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  centered: { flex: 1, alignItems: 'center', justifyContent: 'center' },

  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: Spacing.md, paddingVertical: Spacing.md,
    borderBottomWidth: 1, borderBottomColor: Colors.divider,
  },
  backBtn: {
    width: 44, height: 44, borderRadius: Radius.md,
    backgroundColor: Colors.surface, alignItems: 'center', justifyContent: 'center',
  },
  headerTitle: { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: Colors.text },
  saveBtn: {
    backgroundColor: Colors.gold, borderRadius: Radius.lg,
    paddingVertical: 9, paddingHorizontal: 20, minWidth: 60, alignItems: 'center',
  },
  saveBtnText: { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: Colors.primary },

  avatarSection: { alignItems: 'center', paddingVertical: Spacing.xl, gap: Spacing.sm },
  avatarWrapper: { position: 'relative' },
  avatar: {
    width: 110, height: 110, borderRadius: 55,
    borderWidth: 3, borderColor: Colors.gold,
  },
  cameraOverlay: {
    position: 'absolute', bottom: 4, right: 4,
    width: 34, height: 34, borderRadius: 17,
    backgroundColor: Colors.gold, alignItems: 'center', justifyContent: 'center',
    borderWidth: 2, borderColor: Colors.background,
  },
  changePhotoBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    backgroundColor: Colors.goldSoft, borderRadius: Radius.full,
    paddingHorizontal: 14, paddingVertical: 8,
    borderWidth: 1, borderColor: 'rgba(212,160,23,0.25)',
  },
  changePhotoText: { fontSize: FontSize.xs, color: Colors.gold, fontWeight: FontWeight.semibold },
  photoSelected: { fontSize: FontSize.xs, color: Colors.success, fontWeight: FontWeight.medium },

  form: { paddingHorizontal: Spacing.lg, gap: Spacing.sm },
  sectionTitle: {
    fontSize: FontSize.sm, color: Colors.textMuted,
    fontWeight: FontWeight.semibold, textAlign: 'right',
    marginTop: Spacing.md, marginBottom: 4,
  },
  formGroup: {
    backgroundColor: Colors.surface, borderRadius: Radius.xl,
    borderWidth: 1, borderColor: Colors.border, overflow: 'hidden',
  },
  inputContainer: {
    paddingHorizontal: Spacing.md, paddingVertical: 10,
    borderBottomWidth: 1, borderBottomColor: Colors.divider,
  },
  inputRow: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.sm,
    paddingVertical: 6,
  },
  inputDisabled: { opacity: 0.5 },
  input: { flex: 1, color: Colors.text, fontSize: FontSize.base, paddingVertical: 0 },
  inputValueDisabled: { flex: 1, color: Colors.textMuted, fontSize: FontSize.base, textAlign: 'right' },
  inputLabel: {
    fontSize: FontSize.xs, color: Colors.textMuted, textAlign: 'right', marginTop: 2,
  },

  securityItem: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.md,
    paddingHorizontal: Spacing.md, paddingVertical: Spacing.md,
  },
  securityIcon: {
    width: 38, height: 38, borderRadius: Radius.sm,
    backgroundColor: Colors.goldSoft, alignItems: 'center', justifyContent: 'center',
  },
  securityInfo: { flex: 1, alignItems: 'flex-end' },
  securityLabel: { fontSize: FontSize.base, color: Colors.text, fontWeight: FontWeight.medium },
  securitySub: { fontSize: FontSize.xs, color: Colors.textMuted, marginTop: 2 },
});
