/**
 * OrderNotificationContext
 *
 * Polls the `orders` table every 12 seconds and detects when any order
 * transitions from `pending` → `in_progress`.
 *
 * On detection it:
 *   1. Inserts a record into the `notifications` table (badge update)
 *   2. Triggers haptic feedback
 *   3. Shows an in-app banner via InAppNotificationBanner
 */
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
  ReactNode,
} from 'react';
import * as Haptics from 'expo-haptics';
import { useRouter } from 'expo-router';
import { getSupabaseClient, useAuth } from '@/template';
import InAppNotificationBanner, { InAppNotif } from '@/components/InAppNotificationBanner';

// ─── Context type ─────────────────────────────────────────────────────────────
interface OrderNotifContextType {
  triggerManual: (notif: InAppNotif, targetRoute?: string) => void;
}

const OrderNotifContext = createContext<OrderNotifContextType>({
  triggerManual: () => {},
});

export const useOrderNotification = () => useContext(OrderNotifContext);

const POLL_INTERVAL_MS = 12_000; // 12 seconds

// ─── Provider ─────────────────────────────────────────────────────────────────
export function OrderNotificationProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const supabase = getSupabaseClient();
  const router = useRouter();

  // Map of orderId → last known status (used to detect transitions)
  const prevStatusMap = useRef<Record<string, string>>({});
  const isFirstLoad = useRef(true);
  const routeRef = useRef<string | null>(null);

  // In-app banner state
  const [activeNotif, setActiveNotif] = useState<InAppNotif | null>(null);

  // ── Show banner ──────────────────────────────────────────────────────────
  const showBanner = useCallback((notif: InAppNotif, route?: string) => {
    routeRef.current = route ?? null;
    setActiveNotif(notif);
    // Haptic: medium impact for order updates
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => {});
  }, []);

  const dismissBanner = useCallback(() => {
    setActiveNotif(null);
    routeRef.current = null;
  }, []);

  const handleBannerPress = useCallback(() => {
    if (routeRef.current) {
      router.push(routeRef.current as any);
    }
  }, [router]);

  // ── Insert notification into DB ──────────────────────────────────────────
  const insertDbNotification = useCallback(async (
    orderId: string,
    serviceType: string,
    craftsmanName: string,
    title?: string,
    body?: string,
  ) => {
    if (!user) return;
    await supabase.from('notifications').insert({
      user_id: user.id,
      title: title ?? 'تحديث على طلبك',
      body: body ?? `${craftsmanName} قبل طلب "${serviceType}"`,
      type: 'order',
      is_read: false,
      related_id: orderId,
    });
  }, [user]);

  // ── Poll orders ───────────────────────────────────────────────────────────
  const pollOrders = useCallback(async () => {
    if (!user) return;

    const { data, error } = await supabase
      .from('orders')
      .select('id, status, service_type, craftsman_name')
      .eq('user_id', user.id)
      .in('status', ['pending', 'accepted', 'on_the_way', 'in_progress', 'assigned']);

    if (error || !data) return;

    if (isFirstLoad.current) {
      // Seed the map without firing notifications on first load
      data.forEach(row => {
        prevStatusMap.current[row.id] = row.status;
      });
      isFirstLoad.current = false;
      return;
    }

    for (const row of data) {
      const prev = prevStatusMap.current[row.id];
      const curr = row.status;

      // Detect status transitions that need notification
      if (
        (curr === 'in_progress' || curr === 'accepted' || curr === 'on_the_way') &&
        prev !== undefined && prev !== curr &&
        (prev === 'pending' || prev === 'assigned')
      ) {
        const craftsmanName = row.craftsman_name ?? 'الحرفي';
        const serviceType   = row.service_type  ?? 'الخدمة';

        // Determine notification text based on new status
        let notifTitle = 'تحديث على طلبك';
        let notifBody = `${craftsmanName} قبل طلب "${serviceType}"`;
        let notifIcon = 'check-circle';
        if (curr === 'on_the_way') {
          notifTitle = 'الحرفي في الطريق إليك 🚗';
          notifBody = `${craftsmanName} يتجه نحوك لتنفيذ طلب "${serviceType}"`;
          notifIcon = 'directions-car';
        } else if (curr === 'in_progress') {
          notifTitle = 'بدأ تنفيذ طلبك 🔧';
          notifBody = `${craftsmanName} بدأ تنفيذ طلب "${serviceType}" الآن`;
          notifIcon = 'engineering';
        } else if (curr === 'accepted') {
          notifTitle = 'تم قبول طلبك ✅';
          notifBody = `${craftsmanName} قبل طلب "${serviceType}" وسيتوجه إليك قريباً`;
          notifIcon = 'check-circle-outline';
        }

        // 1. DB notification
        await insertDbNotification(row.id, serviceType, craftsmanName, notifTitle, notifBody);

        // 2. In-app banner
        showBanner(
          {
            id: `order-${row.id}-${Date.now()}`,
            title: notifTitle,
            body: notifBody,
            type: 'order',
            icon: notifIcon,
          },
          `/orders/${row.id}`,
        );
      }

      // Update map
      prevStatusMap.current[row.id] = curr;
    }
  }, [user, insertDbNotification, showBanner]);

  // ── Reset map when user changes ───────────────────────────────────────────
  useEffect(() => {
    prevStatusMap.current = {};
    isFirstLoad.current = true;
  }, [user?.id]);

  // ── Start polling ─────────────────────────────────────────────────────────
  useEffect(() => {
    if (!user) return;

    pollOrders(); // immediate first poll
    const interval = setInterval(pollOrders, POLL_INTERVAL_MS);
    return () => clearInterval(interval);
  }, [user, pollOrders]);

  // ── Manual trigger (for testing or other use cases) ─────────────────────
  const triggerManual = useCallback((notif: InAppNotif, targetRoute?: string) => {
    showBanner(notif, targetRoute);
  }, [showBanner]);

  return (
    <OrderNotifContext.Provider value={{ triggerManual }}>
      {children}

      {/* Global in-app banner — rendered here so it overlays everything */}
      <InAppNotificationBanner
        notification={activeNotif}
        onDismiss={dismissBanner}
        onPress={handleBannerPress}
      />
    </OrderNotifContext.Provider>
  );
}
